package com.convert.ipados;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

/** Horizontal home-screen pager that snaps to pages. */
class Pager extends HorizontalScrollView {
    interface Listener { void onScroll(float pos); }

    final LinearLayout strip;
    int pageW = 1, count = 1;
    Listener listener;
    private boolean flung;

    Pager(Context c) {
        super(c);
        strip = new LinearLayout(c);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        addView(strip, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setHorizontalScrollBarEnabled(false);
        setOverScrollMode(OVER_SCROLL_NEVER);
    }

    void setPages(int n, int w) { count = Math.max(1, n); pageW = Math.max(1, w); }

    int page() { return Math.max(0, Math.min(count - 1, Math.round(getScrollX() / (float) pageW))); }

    void goTo(int p, boolean smooth) {
        int x = Math.max(0, Math.min(count - 1, p)) * pageW;
        if (smooth) smoothScrollTo(x, 0); else scrollTo(x, 0);
    }

    @Override
    public void fling(int v) {
        flung = true;
        float pos = getScrollX() / (float) pageW;
        int t = v > 600 ? (int) Math.floor(pos) + 1 : v < -600 ? (int) Math.ceil(pos) - 1 : page();
        smoothScrollTo(Math.max(0, Math.min(count - 1, t)) * pageW, 0);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) flung = false;
        boolean r = super.onTouchEvent(e);
        if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) && !flung)
            smoothScrollTo(page() * pageW, 0);
        return r;
    }

    @Override
    protected void onScrollChanged(int l, int t, int ol, int ot) {
        super.onScrollChanged(l, t, ol, ot);
        if (listener != null) listener.onScroll(l / (float) pageW);
    }
}
