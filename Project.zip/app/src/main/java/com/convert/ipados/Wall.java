package com.convert.ipados;

import android.Manifest;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;

import java.io.InputStream;

/** Loads the wallpaper once and keeps a sharp copy plus a blurred copy (for the dock). */
final class Wall {
    static Bitmap full, blur, soft;

    static final String[] NAMES = {"iPadOS 16", "Night", "Sunrise", "Ocean", "Graphite"};
    static final int[][] PRESETS = {
        {0xFF1E6FE0, 0xFF3DBFAF, 0xFFF6A53A, 0xFFCDEBDD},
        {0xFF0F0C29, 0xFF302B63, 0xFF6A3FA0, 0xFF24243E},
        {0xFFFF5F6D, 0xFFFFC371, 0xFFFF8A5B, 0xFFFFE9B8},
        {0xFF2C3E50, 0xFF4CA1AF, 0xFF2980B9, 0xFFBFE9F0},
        {0xFF232526, 0xFF414345, 0xFF6B6B6B, 0xFF8E8E8E}
    };

    static boolean hasStoragePermission(Context c) {
        return c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    static void load(Context c, int sw, int sh) {
        Bitmap src = null;
        int mode = Prefs.i("wall_src");
        try {
            if (mode == 0 && hasStoragePermission(c)) {
                Drawable d = WallpaperManager.getInstance(c).getDrawable();
                if (d != null) src = toBitmap(d);
            } else if (mode == 2) {
                String u = Prefs.s("wall_uri");
                if (u.length() > 0) src = decode(c, Uri.parse(u));
            }
        } catch (Throwable t) {
            src = null;
        }
        float f = Math.min(1f, 1080f / sw);
        int w = Math.max(1, Math.round(sw * f)), h = Math.max(1, Math.round(sh * f));
        Bitmap nf = src != null ? crop(src, w, h) : builtin(Prefs.i("wall_preset"), w, h);
        Bitmap small = Bitmap.createScaledBitmap(nf, Math.max(1, w / 6), Math.max(1, h / 6), true);
        blur = U.blur(small, Prefs.i("dock_blur"));
        soft = U.blur(small, Math.max(1, Math.round(Prefs.i("dock_blur") * 0.45f)));
        full = nf;
    }

    private static Bitmap toBitmap(Drawable d) {
        if (d instanceof BitmapDrawable && ((BitmapDrawable) d).getBitmap() != null)
            return ((BitmapDrawable) d).getBitmap();
        int w = Math.max(1, Math.min(2048, d.getIntrinsicWidth()));
        int h = Math.max(1, Math.min(2048, d.getIntrinsicHeight()));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, w, h);
        d.draw(c);
        return b;
    }

    private static Bitmap decode(Context c, Uri u) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream is = c.getContentResolver().openInputStream(u)) {
            BitmapFactory.decodeStream(is, null, o);
        }
        int s = 1;
        while (o.outWidth / s > 2400 || o.outHeight / s > 2400) s *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = s;
        try (InputStream is = c.getContentResolver().openInputStream(u)) {
            return BitmapFactory.decodeStream(is, null, o);
        }
    }

    private static Bitmap crop(Bitmap src, int w, int h) {
        float s = Math.max(w / (float) src.getWidth(), h / (float) src.getHeight());
        Bitmap o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Matrix m = new Matrix();
        m.postScale(s, s);
        m.postTranslate((w - src.getWidth() * s) / 2f, (h - src.getHeight() * s) / 2f);
        new Canvas(o).drawBitmap(src, m, new Paint(Paint.FILTER_BITMAP_FLAG));
        return o;
    }

    /** Procedural wallpaper in the spirit of the iPadOS 16 default. */
    static Bitmap builtin(int idx, int w, int h) {
        int[] p = PRESETS[Math.max(0, Math.min(idx, PRESETS.length - 1))];
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setShader(new LinearGradient(0, 0, w, h, p[0], p[1], Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, pt);
        float m = Math.max(w, h);
        pt.setShader(new RadialGradient(w * 0.15f, h * 0.95f, m * 0.8f, p[2], p[2] & 0x00FFFFFF,
                Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, pt);
        pt.setShader(new RadialGradient(w * 0.9f, h * 0.05f, m * 0.6f, (p[3] & 0x00FFFFFF) | 0xA0000000,
                p[3] & 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, pt);
        Path sw = new Path();
        sw.moveTo(0, h * 0.55f);
        sw.cubicTo(w * 0.35f, h * 0.30f, w * 0.7f, h * 0.9f, w, h * 0.5f);
        sw.lineTo(w, h * 0.64f);
        sw.cubicTo(w * 0.7f, h * 1.02f, w * 0.35f, h * 0.48f, 0, h * 0.7f);
        sw.close();
        pt.setShader(null);
        pt.setColor(0x26FFFFFF);
        c.drawPath(sw, pt);
        return b;
    }
}
