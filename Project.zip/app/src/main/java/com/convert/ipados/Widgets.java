package com.convert.ipados;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/** Base card: rounded translucent rectangle, light or dark. */
abstract class BaseWidget extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final RectF r = new RectF();
    final float d;
    boolean dark;
    float rad;

    BaseWidget(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    int fg() { return dark ? 0xFFFFFFFF : 0xFF000000; }
    int fg2() { return dark ? 0xFF9A9AA0 : 0xFF8E8E93; }

    @Override
    protected void onDraw(Canvas c) {
        dark = Prefs.i("w_dark") == 1;
        rad = U.dp(getContext(), Prefs.i("w_radius"));
        r.set(0, 0, getWidth(), getHeight());
        drawBg(c);
        drawContent(c, getWidth(), getHeight());
    }

    void drawBg(Canvas c) {
        int a = Math.round(Prefs.i("w_alpha") * 2.55f);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor((a << 24) | (dark ? 0x1C1C1E : 0xFFFFFF));
        c.drawRoundRect(r, rad, rad, p);
    }

    Paint text(int color, float sizeDp, boolean bold, Paint.Align al) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setTextSize(sizeDp * d);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        p.setTextAlign(al);
        return p;
    }

    abstract void drawContent(Canvas c, int w, int h);
}

class ClockWidget extends BaseWidget {
    private final Runnable tick = new Runnable() {
        public void run() { invalidate(); postDelayed(this, 1000); }
    };

    ClockWidget(Context c) { super(c); }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); post(tick); }
    @Override protected void onDetachedFromWindow() { super.onDetachedFromWindow(); removeCallbacks(tick); }

    private void hand(Canvas c, float cx, float cy, float deg, float len, float wd, int col) {
        c.save();
        c.rotate(deg, cx, cy);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(col);
        c.drawRoundRect(cx - wd / 2, cy - len, cx + wd / 2, cy + len * 0.14f, wd / 2, wd / 2, p);
        c.restore();
    }

    @Override
    void drawContent(Canvas c, int w, int h) {
        Calendar cal = Calendar.getInstance();
        if (Prefs.b("w_digital")) {
            String t = new SimpleDateFormat("h:mm", Locale.getDefault()).format(cal.getTime());
            c.drawText(t, w / 2f, h / 2f + 14 * d, text(fg(), 44, false, Paint.Align.CENTER));
            String dt = new SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(cal.getTime());
            c.drawText(dt, w / 2f, h / 2f + 38 * d, text(fg2(), 13, false, Paint.Align.CENTER));
            return;
        }
        float cx = w / 2f, cy = h / 2f, R = Math.min(w, h) / 2f - 12 * d;
        p.setStyle(Paint.Style.FILL);
        p.setColor(dark ? 0xFF2C2C2E : 0xFFFFFFFF);
        c.drawCircle(cx, cy, R, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f * d);
        p.setColor(dark ? 0xFF48484A : 0xFFD1D1D6);
        c.drawCircle(cx, cy, R, p);
        for (int i = 1; i <= 12; i++) {
            double a = Math.toRadians(i * 30 - 90);
            float tx = cx + (float) Math.cos(a) * R * 0.78f;
            float ty = cy + (float) Math.sin(a) * R * 0.78f;
            Paint tp = text(fg(), R / d * 0.2f, true, Paint.Align.CENTER);
            c.drawText(String.valueOf(i), tx, ty - (tp.ascent() + tp.descent()) / 2f, tp);
        }
        float sec = cal.get(Calendar.SECOND), min = cal.get(Calendar.MINUTE) + sec / 60f;
        float hr = (cal.get(Calendar.HOUR) % 12) + min / 60f;
        hand(c, cx, cy, hr / 12f * 360f, R * 0.5f, 4.5f * d, fg());
        hand(c, cx, cy, min / 60f * 360f, R * 0.75f, 3.2f * d, fg());
        hand(c, cx, cy, sec / 60f * 360f, R * 0.82f, 1.2f * d, 0xFFFF9500);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFF9500);
        c.drawCircle(cx, cy, 3.5f * d, p);
    }
}

class CalendarWidget extends BaseWidget {
    CalendarWidget(Context c) { super(c); }

    @Override
    void drawContent(Canvas c, int w, int h) {
        Calendar cal = Calendar.getInstance();
        boolean wide = w > h * 1.25f;
        float pad = 14 * d;
        float gx = wide ? w * 0.46f : pad, gw = wide ? w - gx - pad : w - 2 * pad;
        if (wide) {
            String day = new SimpleDateFormat("EEEE", Locale.getDefault()).format(cal.getTime()).toUpperCase();
            c.drawText(day, pad, pad + 11 * d, text(0xFFFF3B30, 11, true, Paint.Align.LEFT));
            c.drawText(String.valueOf(cal.get(Calendar.DAY_OF_MONTH)), pad, pad + 56 * d,
                    text(fg(), 46, false, Paint.Align.LEFT));
            c.drawText("No events today", pad, h - pad, text(fg2(), 12, false, Paint.Align.LEFT));
        }
        float top = pad;
        String mon = new SimpleDateFormat("MMMM", Locale.getDefault()).format(cal.getTime()).toUpperCase();
        c.drawText(mon, gx, top + 11 * d, text(0xFFFF3B30, 11, true, Paint.Align.LEFT));
        top += 18 * d;
        Calendar m = (Calendar) cal.clone();
        m.set(Calendar.DAY_OF_MONTH, 1);
        int off = m.get(Calendar.DAY_OF_WEEK) - 1, dim = m.getActualMaximum(Calendar.DAY_OF_MONTH);
        float cw = gw / 7f, ch = (h - top - pad) / 7f;
        String hdr = "SMTWTFS";
        for (int i = 0; i < 7; i++)
            c.drawText(String.valueOf(hdr.charAt(i)), gx + cw * i + cw / 2, top + ch * 0.7f,
                    text(fg2(), 9, true, Paint.Align.CENTER));
        int today = cal.get(Calendar.DAY_OF_MONTH);
        for (int day = 1; day <= dim; day++) {
            int idx = off + day - 1;
            float x = gx + cw * (idx % 7) + cw / 2, y = top + ch * (1 + idx / 7) + ch * 0.7f;
            if (day == today) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFFF3B30);
                c.drawCircle(x, y - ch * 0.3f, Math.min(cw, ch) * 0.5f, p);
            }
            Paint tp = text(day == today ? 0xFFFFFFFF : fg(), 9.5f, day == today, Paint.Align.CENTER);
            c.drawText(String.valueOf(day), x, y - (day == today ? 0 : 0), tp);
        }
    }
}

class WeatherWidget extends BaseWidget {
    WeatherWidget(Context c) { super(c); }

    @Override
    void drawBg(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, getHeight(), 0xFF4FA3F7, 0xFF2467C9, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
    }

    @Override
    void drawContent(Canvas c, int w, int h) {
        float pad = 14 * d;
        int t = Prefs.i("w_temp");
        String unit = Prefs.i("w_units") == 1 ? "°F" : "°C";
        c.drawText(Prefs.s("w_city"), pad, pad + 13 * d, text(0xFFFFFFFF, 14, true, Paint.Align.LEFT));
        c.drawText(t + "°", pad, pad + 58 * d, text(0xFFFFFFFF, 46, false, Paint.Align.LEFT));
        // sun
        float sx = w - pad - 16 * d, sy = pad + 14 * d;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFD60A);
        c.drawCircle(sx, sy, 8 * d, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 8; i++) {
            double a = Math.toRadians(i * 45);
            c.drawLine(sx + (float) Math.cos(a) * 12 * d, sy + (float) Math.sin(a) * 12 * d,
                    sx + (float) Math.cos(a) * 16 * d, sy + (float) Math.sin(a) * 16 * d, p);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
        c.drawText("Mostly Sunny", pad, h - pad - 16 * d, text(0xFFFFFFFF, 13, true, Paint.Align.LEFT));
        c.drawText("H:" + (t + 4) + "°  L:" + (t - 6) + "°  " + unit, pad, h - pad,
                text(0xDDFFFFFF, 12, false, Paint.Align.LEFT));
    }
}

class NotesWidget extends BaseWidget {
    NotesWidget(Context c) {
        super(c);
        setOnClickListener(v -> edit());
    }

    private void edit() {
        final EditText et = new EditText(getContext());
        et.setText(Prefs.s("notes_text"));
        et.setMinLines(4);
        et.setGravity(android.view.Gravity.TOP);
        new AlertDialog.Builder(getContext(), android.R.style.Theme_Material_Light_Dialog_Alert)
                .setTitle("Notes").setView(et)
                .setPositiveButton("Save", (dl, w) -> { Prefs.setQuiet("notes_text", et.getText().toString()); invalidate(); })
                .setNegativeButton("Cancel", null).show();
    }

    @Override
    void drawContent(Canvas c, int w, int h) {
        float pad = 14 * d;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFCC00);
        c.drawRoundRect(pad, pad, pad + 18 * d, pad + 18 * d, 5 * d, 5 * d, p);
        c.drawText("Notes", pad + 26 * d, pad + 14 * d, text(fg(), 15, true, Paint.Align.LEFT));
        String s = Prefs.s("notes_text");
        boolean empty = s.trim().isEmpty();
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTextSize(13 * d);
        tp.setColor(empty ? fg2() : fg());
        StaticLayout sl = StaticLayout.Builder.obtain(empty ? "No Notes" : s, 0, (empty ? "No Notes" : s).length(),
                tp, (int) (w - 2 * pad)).setMaxLines(Math.max(1, (int) ((h - 60 * d) / (16 * d))))
                .setEllipsize(TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_NORMAL).build();
        c.save();
        c.translate(pad, pad + 32 * d);
        sl.draw(c);
        c.restore();
    }
}

/** "Siri Suggestions"-style card with four quick shortcuts. */
class ShortcutsWidget extends BaseWidget {
    private final String[] titles = {"Create a new calendar event", "Send a message", "Start a timer", "Search the web"};
    private final String[] subs = {"Calendar", "Messages", "Clock", "Browser"};
    private final Intent[] intents = new Intent[4];
    private final Drawable[] icons = new Drawable[4];
    private float lastY;

    ShortcutsWidget(Context c) {
        super(c);
        intents[0] = new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI);
        intents[1] = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"));
        intents[2] = new Intent(AlarmClock.ACTION_SET_TIMER);
        intents[3] = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
        setOnClickListener(v -> tap(lastY));
        PackageManager pm = c.getPackageManager();
        for (int i = 0; i < 4; i++) {
            try {
                ResolveInfo ri = pm.resolveActivity(intents[i], PackageManager.MATCH_DEFAULT_ONLY);
                if (ri != null && ri.activityInfo != null && !"android".equals(ri.activityInfo.packageName)) {
                    icons[i] = ri.loadIcon(pm);
                    subs[i] = String.valueOf(ri.loadLabel(pm));
                }
            } catch (Exception ignored) { }
        }
    }

    @Override
    void drawContent(Canvas c, int w, int h) {
        float pad = 12 * d, rowH = (h - 2 * pad) / 4f, ic = Math.min(rowH * 0.7f, 30 * d);
        for (int i = 0; i < 4; i++) {
            float cy = pad + rowH * i + rowH / 2f;
            if (icons[i] != null) {
                icons[i].setBounds((int) pad, (int) (cy - ic / 2), (int) (pad + ic), (int) (cy + ic / 2));
                icons[i].draw(c);
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFF8E8E93);
                c.drawRoundRect(pad, cy - ic / 2, pad + ic, cy + ic / 2, 7 * d, 7 * d, p);
            }
            float tx = pad + ic + 10 * d;
            Paint tp = text(fg(), 12, true, Paint.Align.LEFT);
            c.drawText(TextUtils.ellipsize(titles[i], new TextPaint(tp), w - tx - pad, TextUtils.TruncateAt.END)
                    .toString(), tx, cy - 1 * d, tp);
            c.drawText(subs[i], tx, cy + 12 * d, text(fg2(), 10.5f, false, Paint.Align.LEFT));
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_UP) lastY = e.getY();
        return super.onTouchEvent(e);
    }

    private void tap(float y) {
        float pad = 12 * d, rowH = (getHeight() - 2 * pad) / 4f;
        int i = (int) ((y - pad) / rowH);
        if (i >= 0 && i < 4) {
            try {
                getContext().startActivity(new Intent(intents[i]).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ex) {
                Toast.makeText(getContext(), "No app found", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
