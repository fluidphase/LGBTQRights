package com.convert.ipados;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The saved home-screen arrangement: an ordered list of apps and folders. The grid simply flows
 * this list into pages, so removing or moving an entry closes the gap automatically.
 */
final class HomeLayout {
    private static final String SEP = "\u001f";

    static final class Entry {
        String id;              // app key, or folder id
        boolean folder;
        String name = "Folder";
        final List<String> keys = new ArrayList<>(); // apps inside a folder

        static Entry app(String key) { Entry e = new Entry(); e.id = key; return e; }
    }

    static String newId() {
        return Long.toString(System.currentTimeMillis(), 36) + Integer.toString((int) (Math.random() * 1296), 36);
    }

    static String clean(String n) {
        String s = n == null ? "" : n.replace("\n", " ").replace(SEP, " ").trim();
        return s.isEmpty() ? "Folder" : s;
    }

    static List<Entry> load() {
        List<Entry> out = new ArrayList<>();
        for (String line : Prefs.list("home_layout")) {
            String[] p = line.split(SEP, -1);
            if (p.length < 2) continue;
            if (p[0].equals("A")) {
                out.add(Entry.app(p[1]));
            } else if (p[0].equals("F") && p.length >= 3) {
                Entry e = new Entry();
                e.folder = true;
                e.id = p[1];
                e.name = p[2];
                for (int i = 3; i < p.length; i++) if (!p[i].isEmpty()) e.keys.add(p[i]);
                out.add(e);
            }
        }
        return out;
    }

    static void save(List<Entry> l) {
        List<String> lines = new ArrayList<>();
        for (Entry e : l) {
            if (!e.folder) {
                lines.add("A" + SEP + e.id);
            } else {
                StringBuilder sb = new StringBuilder("F" + SEP + e.id + SEP + clean(e.name));
                for (String k : e.keys) sb.append(SEP).append(k);
                lines.add(sb.toString());
            }
        }
        Prefs.setList("home_layout", lines, true);
    }

    /**
     * Saved layout repaired against the apps that really exist: uninstalled / hidden apps vanish,
     * one-app folders dissolve, and new apps are appended in the normal sort order.
     */
    static List<Entry> reconcile(List<AppInfo> visible) {
        Map<String, AppInfo> map = new HashMap<>();
        for (AppInfo a : visible) map.put(a.key(), a);
        Set<String> used = new HashSet<>();
        List<Entry> out = new ArrayList<>();
        for (Entry e : load()) {
            if (!e.folder) {
                if (map.containsKey(e.id) && used.add(e.id)) out.add(e);
            } else {
                List<String> ok = new ArrayList<>();
                for (String k : e.keys) if (map.containsKey(k) && used.add(k)) ok.add(k);
                if (ok.isEmpty()) continue;
                if (ok.size() == 1) {
                    out.add(Entry.app(ok.get(0)));
                } else {
                    e.keys.clear();
                    e.keys.addAll(ok);
                    out.add(e);
                }
            }
        }
        for (AppInfo a : visible) if (!used.contains(a.key())) out.add(Entry.app(a.key()));
        return out;
    }
}
