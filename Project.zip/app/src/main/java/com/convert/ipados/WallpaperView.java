package com.convert.ipados;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

class WallpaperView extends View {
    private final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Rect dst = new Rect();

    WallpaperView(Context c) { super(c); }

    @Override
    protected void onDraw(Canvas c) {
        dst.set(0, 0, getWidth(), getHeight());
        if (Wall.full != null) c.drawBitmap(Wall.full, null, dst, p);
        if (Theme.dark(getContext())) c.drawColor(0x40000000); // iPadOS dims the wallpaper in Dark appearance
        int dim = Prefs.i("wall_dim");
        if (dim > 0) c.drawColor(Math.round(dim * 2.55f) << 24);
    }
}
