package com.convert.ipados;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.PathInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** An open folder: blurred screen, an editable title, and a frosted panel of apps that springs out of the folder icon. */
class FolderView extends FrameLayout {
    interface Callback {
        void launch(AppInfo a, RectF from);
        void appMenu(AppInfo a, View icon);
        void renamed(String folderId, String name);
    }

    private static class MaxScroll extends ScrollView {
        private final int maxH;
        MaxScroll(Context c, int maxH) { super(c); this.maxH = maxH; }
        @Override
        protected void onMeasure(int w, int h) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST));
        }
    }

    private class Panel extends LinearLayout {
        Panel(Context c) {
            super(c);
            setOrientation(VERTICAL);
            setWillNotDraw(false);
            setClickable(true);
            final float rad = U.dp(c, 34);
            setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rad);
                }
            });
            setClipToOutline(true);
        }

        @Override
        protected void onDraw(Canvas c) {
            frost.draw(c, this, wall, U.dp(getContext(), 34), 0x59FFFFFF, 0x40FFFFFF, U.dp(getContext(), 0.75f));
        }
    }

    private final Callback cb;
    private final View wall;
    private final Frost frost = new Frost();
    private LinearLayout box, rows;
    private EditText title;
    private Panel panel;
    private final Paint bgp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint scrim = new Paint();
    private final Matrix m = new Matrix();
    private BitmapShader sh;
    private Bitmap shBmp;
    private ValueAnimator anim;
    private float t;
    private boolean open;
    private String folderId = "", origName = "";

    FolderView(Context c, View wall, Callback cb) {
        super(c);
        this.wall = wall;
        this.cb = cb;
        setWillNotDraw(false);
        setVisibility(GONE);
        setClickable(true);
        setOnClickListener(v -> close());

        box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        addView(box, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        title = new EditText(c);
        title.setBackground(null);
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        title.setImeOptions(EditorInfo.IME_ACTION_DONE);
        title.setShadowLayer(U.dp(c, 4), 0, U.dp(c, 1), 0x66000000);
        title.setMinWidth(U.dpi(c, 220));
        title.setOnEditorActionListener((tv, id, ev) -> {
            hideKeyboard();
            title.clearFocus();
            return true;
        });
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.bottomMargin = U.dpi(c, 14);
        box.addView(title, tl);

        panel = new Panel(c);
        MaxScroll sv = new MaxScroll(c, Math.round(c.getResources().getDisplayMetrics().heightPixels * 0.62f));
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(OVER_SCROLL_NEVER);
        rows = new LinearLayout(c);
        rows.setOrientation(LinearLayout.VERTICAL);
        int p = U.dpi(c, 14);
        rows.setPadding(p, p, p, p);
        sv.addView(rows, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        box.addView(panel, new LinearLayout.LayoutParams(-2, -2));
    }

    boolean isOpen() { return open; }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(title.getWindowToken(), 0);
    }

    /** Focus the title so the user can type a new name. */
    void startRename() {
        title.requestFocus();
        title.selectAll();
        final InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        title.postDelayed(() -> { if (open) im.showSoftInput(title, 0); }, 260);
    }

    void open(String id, String name, List<AppInfo> apps, RectF from) {
        Context c = getContext();
        folderId = id;
        origName = name;
        title.setText(name);
        title.clearFocus();
        rows.removeAllViews();
        int cols = apps.size() <= 3 ? 3 : 4;
        int cellW = U.dpi(c, 92);
        int maxW = Math.round(c.getResources().getDisplayMetrics().widthPixels * 0.9f);
        while (cols > 2 && cols * cellW + U.dpi(c, 28) > maxW) cols--;
        int icon = U.dpi(c, 60);
        for (int i = 0; i < apps.size(); i += cols) {
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int k = 0; k < cols; k++) {
                if (i + k >= apps.size()) {
                    row.addView(new View(c), new LinearLayout.LayoutParams(cellW, 1));
                    continue;
                }
                final AppInfo a = apps.get(i + k);
                LinearLayout cell = new LinearLayout(c);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setPadding(0, U.dpi(c, 8), 0, U.dpi(c, 8));
                final ImageView iv = new ImageView(c);
                iv.setImageBitmap(Icons.get(c, a, U.dpi(c, Prefs.i("icon_size"))));
                cell.addView(iv, new LinearLayout.LayoutParams(icon, icon));
                TextView tv = new TextView(c);
                tv.setText(a.label);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(12);
                tv.setSingleLine(true);
                tv.setEllipsize(TextUtils.TruncateAt.END);
                tv.setGravity(Gravity.CENTER);
                tv.setShadowLayer(U.dp(c, 2), 0, U.dp(c, 1), 0x88000000);
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(cellW - U.dpi(c, 8), -2);
                tl.topMargin = U.dpi(c, 5);
                cell.addView(tv, tl);
                cell.setOnClickListener(v -> cb.launch(a, rectOf(iv)));
                cell.setOnLongClickListener(v -> { cb.appMenu(a, iv); return true; });
                row.addView(cell, new LinearLayout.LayoutParams(cellW, -2));
            }
            rows.addView(row);
        }

        open = true;
        if (anim != null) anim.cancel();
        setVisibility(VISIBLE);
        box.setAlpha(0f);
        apply(0f);
        final RectF f = new RectF(from);
        post(() -> {
            if (!open) return;
            int[] l = new int[2];
            getLocationOnScreen(l);
            box.setPivotX(f.centerX() - l[0] - box.getX());
            box.setPivotY(f.centerY() - l[1] - box.getY());
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(380);
            anim.setInterpolator(new PathInterpolator(0.2f, 1.15f, 0.35f, 1f));
            anim.addUpdateListener(an -> apply((Float) an.getAnimatedValue()));
            anim.start();
        });
    }

    private RectF rectOf(View v) {
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        return new RectF(l[0], l[1], l[0] + v.getWidth(), l[1] + v.getHeight());
    }

    /** Close with the shrink-back animation (and save a changed name). */
    void close() {
        if (!open) return;
        open = false;
        hideKeyboard();
        String n = HomeLayout.clean(title.getText().toString());
        if (!n.equals(origName)) cb.renamed(folderId, n);
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(Math.min(t, 1f), 0f);
        anim.setDuration(240);
        anim.setInterpolator(new DecelerateInterpolator(1.4f));
        anim.addUpdateListener(an -> apply((Float) an.getAnimatedValue()));
        anim.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;
            @Override public void onAnimationCancel(Animator a) { cancelled = true; }
            @Override public void onAnimationEnd(Animator a) { if (!cancelled && !open) setVisibility(GONE); }
        });
        anim.start();
    }

    /** Hide immediately, no animation, no rename (used before launching an app or rebuilding). */
    void closeNow() {
        if (anim != null) anim.cancel();
        open = false;
        hideKeyboard();
        setVisibility(GONE);
    }

    private void apply(float p) {
        t = p;
        box.setAlpha(U.clamp(p * 2f, 0f, 1f));
        float s = U.lerp(0.2f, 1f, p);
        box.setScaleX(s);
        box.setScaleY(s);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float a = U.clamp(t, 0f, 1f);
        if (a <= 0f) return;
        if (Wall.blur != null) {
            if (sh == null || shBmp != Wall.blur) {
                shBmp = Wall.blur;
                sh = new BitmapShader(shBmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            }
            m.reset();
            m.setScale(getWidth() / (float) shBmp.getWidth(), getHeight() / (float) shBmp.getHeight());
            sh.setLocalMatrix(m);
            bgp.setShader(sh);
            bgp.setAlpha(Math.round(215 * a));
            c.drawRect(0, 0, getWidth(), getHeight(), bgp);
        }
        scrim.setColor(Math.round(70 * a) << 24);
        c.drawRect(0, 0, getWidth(), getHeight(), scrim);
    }
}
