package com.convert.ipados;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.RectF;

final class U {
    static float dp(Context c, float v) { return v * c.getResources().getDisplayMetrics().density; }
    static int dpi(Context c, float v) { return Math.round(dp(c, v)); }
    static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    /** 0 = iOS squircle, 1 = rounded square, 2 = circle, 3 = square. */
    static Path shape(RectF r, int shape, float radFrac) {
        Path p = new Path();
        float w = r.width(), h = r.height();
        switch (shape) {
            case 0: {
                int n = 96;
                double e = 5.0;
                float cx = r.centerX(), cy = r.centerY(), a = w / 2f, b = h / 2f;
                for (int i = 0; i < n; i++) {
                    double t = 2 * Math.PI * i / n;
                    double c = Math.cos(t), s = Math.sin(t);
                    float x = (float) (cx + a * Math.signum(c) * Math.pow(Math.abs(c), 2.0 / e));
                    float y = (float) (cy + b * Math.signum(s) * Math.pow(Math.abs(s), 2.0 / e));
                    if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
                }
                p.close();
                break;
            }
            case 1: {
                float rad = radFrac * Math.min(w, h);
                p.addRoundRect(r, rad, rad, Path.Direction.CW);
                break;
            }
            case 2:
                p.addOval(r, Path.Direction.CW);
                break;
            default:
                p.addRect(r, Path.Direction.CW);
        }
        return p;
    }

    static int avgColor(Bitmap b) {
        Bitmap s = Bitmap.createScaledBitmap(b, 1, 1, true);
        return s.getPixel(0, 0) | 0xFF000000;
    }

    /** Fast 3-pass box blur (approximates a gaussian). */
    static Bitmap blur(Bitmap src, int radius) {
        Bitmap b = src.copy(Bitmap.Config.ARGB_8888, true);
        if (radius < 1) return b;
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h], tmp = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        for (int k = 0; k < 3; k++) {
            pass(px, tmp, w, h, radius, true);
            pass(tmp, px, w, h, radius, false);
        }
        b.setPixels(px, 0, w, 0, 0, w, h);
        return b;
    }

    private static void pass(int[] s, int[] d, int w, int h, int r, boolean hor) {
        int len = hor ? w : h, lines = hor ? h : w, div = 2 * r + 1;
        for (int l = 0; l < lines; l++) {
            int sa = 0, sr = 0, sg = 0, sb = 0;
            for (int k = -r; k <= r; k++) {
                int i = Math.min(Math.max(k, 0), len - 1);
                int p = s[hor ? l * w + i : i * w + l];
                sa += p >>> 24; sr += (p >> 16) & 255; sg += (p >> 8) & 255; sb += p & 255;
            }
            for (int i = 0; i < len; i++) {
                d[hor ? l * w + i : i * w + l] =
                        ((sa / div) << 24) | ((sr / div) << 16) | ((sg / div) << 8) | (sb / div);
                int ai = Math.min(i + r + 1, len - 1), ri = Math.max(i - r, 0);
                int a = s[hor ? l * w + ai : ai * w + l];
                int b = s[hor ? l * w + ri : ri * w + l];
                sa += (a >>> 24) - (b >>> 24);
                sr += ((a >> 16) & 255) - ((b >> 16) & 255);
                sg += ((a >> 8) & 255) - ((b >> 8) & 255);
                sb += (a & 255) - (b & 255);
            }
        }
    }
}
