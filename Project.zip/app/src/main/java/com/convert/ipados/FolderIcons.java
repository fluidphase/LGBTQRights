package com.convert.ipados;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import java.util.List;

/** Draws the folder icon: a translucent rounded square with up to nine mini app icons (3 x 3). */
final class FolderIcons {
    static Bitmap render(List<Bitmap> minis, int px) {
        Bitmap out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        float rad = px * 0.225f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x80E6E6EE);
        c.drawRoundRect(0, 0, px, px, rad, rad, p);
        float sw = Math.max(1f, px * 0.012f);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(sw);
        p.setColor(0x44FFFFFF);
        c.drawRoundRect(sw / 2, sw / 2, px - sw / 2, px - sw / 2, rad, rad, p);
        p.setStyle(Paint.Style.FILL);
        float pad = px * 0.13f, gap = px * 0.045f, sz = (px - 2 * pad - 2 * gap) / 3f;
        for (int i = 0; i < minis.size() && i < 9; i++) {
            float x = pad + (i % 3) * (sz + gap), y = pad + (i / 3) * (sz + gap);
            c.drawBitmap(minis.get(i), null, new RectF(x, y, x + sz, y + sz), p);
        }
        return out;
    }
}
