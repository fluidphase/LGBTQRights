package com.convert.ipados;

import android.content.Context;
import android.content.res.Configuration;

/** Light / dark appearance (Settings > General > Appearance: Automatic follows the system). */
final class Theme {
    static boolean dark(Context c) {
        int m = Prefs.i("appearance");
        if (m == 1) return false;
        if (m == 2) return true;
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    static int text(Context c) { return dark(c) ? 0xFFFFFFFF : 0xFF1C1C1E; }
    static int sub(Context c) { return dark(c) ? 0xFF98989F : 0xFF6E6E73; }
    static int hair(Context c) { return dark(c) ? 0x33FFFFFF : 0x26000000; }
    static int press(Context c) { return dark(c) ? 0x33FFFFFF : 0x1F000000; }
}
