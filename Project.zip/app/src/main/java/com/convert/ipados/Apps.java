package com.convert.ipados;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class Apps {
    static List<AppInfo> load(Context c) {
        PackageManager pm = c.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<AppInfo> out = new ArrayList<>();
        for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
            if (ri.activityInfo.packageName.equals(c.getPackageName())) continue;
            AppInfo a = new AppInfo();
            a.ri = ri;
            a.cn = new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name);
            a.label = String.valueOf(ri.loadLabel(pm));
            try {
                a.installTime = pm.getPackageInfo(a.cn.getPackageName(), 0).firstInstallTime;
            } catch (Exception ignored) { }
            out.add(a);
        }
        sort(out);
        return out;
    }

    static void sort(List<AppInfo> l) {
        if (Prefs.i("sort") == 1) {
            Collections.sort(l, (x, y) -> Long.compare(y.installTime, x.installTime));
        } else {
            Collections.sort(l, (x, y) -> x.label.compareToIgnoreCase(y.label));
        }
    }
}
