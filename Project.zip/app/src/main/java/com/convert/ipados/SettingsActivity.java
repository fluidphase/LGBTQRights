package com.convert.ipados;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** iPadOS-flavoured settings. Every launcher option is reachable from here. */
public class SettingsActivity extends Activity {
    interface Builder { List<Row> build(); }

    static final int HEADER = 0, TOGGLE = 1, SLIDER = 2, CHOICE = 3, ACTION = 4, NAV = 5, NOTE = 6, TEXT = 7, FTOGGLE = 8;

    static class Row {
        int type, min, max;
        String title, key, sub, unit = "";
        boolean autoZero;
        String[] opts;
        Runnable act;
        Builder nav;
        BooleanSupplier get;
        Consumer<Boolean> set;

        static Row mk(int t, String title) { Row r = new Row(); r.type = t; r.title = title; return r; }
        static Row header(String t) { return mk(HEADER, t); }
        static Row note(String t) { return mk(NOTE, t); }
        static Row toggle(String t, String k) { Row r = mk(TOGGLE, t); r.key = k; return r; }
        static Row slider(String t, String k, int min, int max, String unit) {
            Row r = mk(SLIDER, t); r.key = k; r.min = min; r.max = max; r.unit = unit; return r;
        }
        static Row autoSlider(String t, String k, int min, int max, String unit) {
            Row r = slider(t, k, min, max, unit); r.autoZero = true; return r;
        }
        static Row choice(String t, String k, String... opts) { Row r = mk(CHOICE, t); r.key = k; r.opts = opts; return r; }
        static Row text(String t, String k) { Row r = mk(TEXT, t); r.key = k; return r; }
        static Row action(String t, String sub, Runnable a) { Row r = mk(ACTION, t); r.sub = sub; r.act = a; return r; }
        static Row nav(String t, Builder b) { Row r = mk(NAV, t); r.nav = b; return r; }
        static Row ftoggle(String t, BooleanSupplier g, Consumer<Boolean> s) {
            Row r = mk(FTOGGLE, t); r.get = g; r.set = s; return r;
        }
    }

    private final Deque<Object[]> stack = new ArrayDeque<>();
    private LinearLayout content;
    private ScrollView scroll;
    private TextView titleView, backView;

    private int dpi(float v) { return U.dpi(this, v); }


    private AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(this, android.R.style.Theme_Material_Light_Dialog_Alert);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.init(this);
        LinearLayout rootV = new LinearLayout(this);
        rootV.setOrientation(LinearLayout.VERTICAL);
        rootV.setBackgroundColor(0xFFF2F2F7);

        FrameLayout bar = new FrameLayout(this);
        backView = new TextView(this);
        backView.setText("‹ Back");
        backView.setTextColor(0xFF007AFF);
        backView.setTextSize(17);
        backView.setPadding(dpi(16), 0, dpi(16), 0);
        backView.setGravity(Gravity.CENTER_VERTICAL);
        backView.setOnClickListener(v -> onBackPressed());
        bar.addView(backView, new FrameLayout.LayoutParams(-2, -1, Gravity.START));
        titleView = new TextView(this);
        titleView.setTextSize(17);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextColor(Color.BLACK);
        bar.addView(titleView, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        rootV.addView(bar, new LinearLayout.LayoutParams(-1, dpi(52)));

        scroll = new ScrollView(this);
        FrameLayout wrap = new FrameLayout(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int w = Math.min(getResources().getDisplayMetrics().widthPixels, dpi(640));
        wrap.addView(content, new FrameLayout.LayoutParams(w, -2, Gravity.CENTER_HORIZONTAL));
        scroll.addView(wrap, new FrameLayout.LayoutParams(-1, -2));
        rootV.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(rootV);

        push("Settings", this::mainPage);
        String page = getIntent().getStringExtra("page");
        if ("wallpaper".equals(page)) push("Wallpaper", this::wallpaperPage);
        else if ("widgets".equals(page)) push("Widgets", this::widgetsPage);
    }

    private void push(String title, Builder b) {
        stack.push(new Object[]{title, b});
        render();
    }

    @Override
    public void onBackPressed() {
        if (stack.size() > 1) {
            stack.pop();
            render();
        } else {
            finish();
        }
    }

    // ------------------------------------------------------------------ rendering

    private void render() {
        Object[] top = stack.peek();
        titleView.setText((String) top[0]);
        backView.setText(stack.size() > 1 ? "‹ Back" : "‹ Home");
        int y = scroll.getScrollY();
        content.removeAllViews();
        LinearLayout group = null;
        for (Row r : ((Builder) top[1]).build()) {
            if (r.type == HEADER) {
                group = null;
                content.addView(label(r.title.toUpperCase(), 13, 0xFF6D6D72, dpi(32), dpi(22), dpi(16), dpi(6)));
            } else if (r.type == NOTE) {
                group = null;
                content.addView(label(r.title, 13, 0xFF6D6D72, dpi(32), dpi(8), dpi(16), dpi(8)));
            } else {
                if (group == null) {
                    group = new LinearLayout(this);
                    group.setOrientation(LinearLayout.VERTICAL);
                    GradientDrawable bg = new GradientDrawable();
                    bg.setColor(Color.WHITE);
                    bg.setCornerRadius(U.dp(this, 12));
                    group.setBackground(bg);
                    group.setClipToOutline(true);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                    lp.setMargins(dpi(16), 0, dpi(16), 0);
                    content.addView(group, lp);
                } else {
                    View div = new View(this);
                    div.setBackgroundColor(0xFFE5E5EA);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 2);
                    lp.leftMargin = dpi(16);
                    group.addView(div, lp);
                }
                group.addView(rowView(r));
            }
        }
        content.addView(new View(this), new LinearLayout.LayoutParams(-1, dpi(40)));
        scroll.post(() -> scroll.scrollTo(0, y));
    }

    private TextView label(String t, float sp, int color, int l, int tp, int r, int b) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setPadding(l, tp, r, b);
        return v;
    }

    private String fmt(Row r, int v) { return (r.autoZero && v == 0) ? "Auto" : v + r.unit; }

    private View rowView(final Row r) {
        if (r.type == SLIDER) return sliderView(r);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dpi(50));
        row.setPadding(dpi(16), dpi(10), dpi(16), dpi(10));
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(label(r.title, 17, Color.BLACK, 0, 0, 0, 0));
        if (r.sub != null && !r.sub.isEmpty()) left.addView(label(r.sub, 13, 0xFF8E8E93, 0, 0, 0, 0));
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));

        switch (r.type) {
            case TOGGLE:
            case FTOGGLE: {
                final Switch sw = new Switch(this);
                sw.setChecked(r.type == TOGGLE ? Prefs.b(r.key) : r.get.getAsBoolean());
                sw.setOnCheckedChangeListener((cb, v) -> {
                    if (r.type == TOGGLE) Prefs.set(r.key, v); else r.set.accept(v);
                });
                row.addView(sw);
                row.setOnClickListener(v -> sw.toggle());
                break;
            }
            case CHOICE: {
                final int cur = Math.max(0, Math.min(r.opts.length - 1, Prefs.i(r.key)));
                row.addView(label(r.opts[cur] + "  ›", 17, 0xFF8E8E93, 0, 0, 0, 0));
                row.setOnClickListener(v -> dlg().setTitle(r.title)
                        .setSingleChoiceItems(r.opts, cur, (d, which) -> {
                            Prefs.set(r.key, which);
                            d.dismiss();
                            render();
                        }).show());
                break;
            }
            case TEXT: {
                String s = Prefs.s(r.key);
                row.addView(label((s.isEmpty() ? "—" : s) + "  ›", 17, 0xFF8E8E93, 0, 0, 0, 0));
                row.setOnClickListener(v -> {
                    final EditText et = new EditText(this);
                    et.setText(Prefs.s(r.key));
                    dlg().setTitle(r.title).setView(et)
                            .setPositiveButton("Save", (d, w) -> { Prefs.set(r.key, et.getText().toString()); render(); })
                            .setNegativeButton("Cancel", null).show();
                });
                break;
            }
            case NAV:
                row.addView(label("›", 22, 0xFFC7C7CC, 0, 0, 0, 0));
                row.setOnClickListener(v -> push(r.title, r.nav));
                break;
            default: // ACTION
                row.setOnClickListener(v -> r.act.run());
        }
        return row;
    }

    private View sliderView(final Row r) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dpi(16), dpi(10), dpi(16), dpi(6));
        LinearLayout top = new LinearLayout(this);
        top.addView(label(r.title, 17, Color.BLACK, 0, 0, 0, 0), new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = label(fmt(r, Prefs.i(r.key)), 17, 0xFF8E8E93, 0, 0, 0, 0);
        top.addView(val);
        box.addView(top);
        SeekBar sb = new SeekBar(this);
        sb.setMax(r.max - r.min);
        sb.setProgress(Math.max(0, Prefs.i(r.key) - r.min));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) { val.setText(fmt(r, p + r.min)); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { Prefs.set(r.key, s.getProgress() + r.min); }
        });
        box.addView(sb);
        return box;
    }

    // ------------------------------------------------------------------ pages

    private List<Row> mainPage() {
        List<Row> l = new ArrayList<>();
        l.add(Row.header("Customize"));
        l.add(Row.nav("Home Screen", this::homePage));
        l.add(Row.nav("Dock", this::dockPage));
        l.add(Row.nav("Widgets", this::widgetsPage));
        l.add(Row.nav("Wallpaper", this::wallpaperPage));
        l.add(Row.nav("Animations", this::animPage));
        l.add(Row.nav("Icon Packs", this::packsPage));
        l.add(Row.nav("Search", this::searchPage));
        l.add(Row.nav("General", this::generalPage));
        return l;
    }

    private List<Row> homePage() {
        List<Row> l = new ArrayList<>();
        l.add(Row.header("Layout"));
        l.add(Row.autoSlider("Columns", "cols", 0, 8, ""));
        l.add(Row.autoSlider("Rows per page", "rows", 0, 10, ""));
        l.add(Row.slider("Side margin", "side_margin", 0, 80, " dp"));
        l.add(Row.slider("Row spacing", "icon_gapv", 0, 60, " dp"));
        l.add(Row.header("Icons"));
        l.add(Row.slider("Icon size", "icon_size", 36, 96, " dp"));
        l.add(Row.choice("Icon shape", "icon_shape", "Squircle (iOS)", "Rounded square", "Circle", "Square"));
        l.add(Row.slider("Rounded square radius", "icon_radius", 0, 50, " %"));
        l.add(Row.choice("Background for non-adaptive icons", "legacy_bg", "White", "Light gray", "Black"));
        l.add(Row.header("Labels"));
        l.add(Row.toggle("Show labels", "show_labels"));
        l.add(Row.slider("Label size", "label_size", 8, 16, " sp"));
        l.add(Row.choice("Label colour", "label_color", "White", "Black"));
        l.add(Row.toggle("Label shadow", "label_shadow"));
        l.add(Row.header("Pages"));
        l.add(Row.toggle("Page dots", "page_dots"));
        l.add(Row.choice("Sort apps", "sort", "A to Z", "Newest first"));
        l.add(Row.header("Apps"));
        l.add(Row.nav("Hidden Apps", this::hiddenPage));
        return l;
    }

    private List<Row> hiddenPage() {
        List<Row> l = new ArrayList<>();
        l.add(Row.header("Hide apps from the home screen"));
        for (final AppInfo a : Apps.load(this)) {
            final String k = a.key();
            l.add(Row.ftoggle(a.label, () -> Prefs.list("hidden").contains(k), on -> {
                List<String> h = Prefs.list("hidden");
                h.remove(k);
                if (on) h.add(k);
                Prefs.setList("hidden", h, false);
            }));
        }
        return l;
    }

    private List<Row> dockPage() {
        List<Row> l = new ArrayList<>();
        l.add(Row.header("Dock"));
        l.add(Row.toggle("Show dock", "dock_show"));
        l.add(Row.slider("Icon size", "dock_size", 36, 80, " dp"));
        l.add(Row.slider("Maximum apps", "dock_max", 1, 12, ""));
        l.add(Row.slider("Bottom margin", "dock_margin", 0, 40, " dp"));
        l.add(Row.slider("Corner radius", "dock_radius", 0, 48, " dp"));
        l.add(Row.header("Background"));
        l.add(Row.slider("Wallpaper blur", "dock_blur", 0, 30, ""));
        l.add(Row.choice("Tint", "dock_tint", "White", "Black", "Blue", "Light gray"));
        l.add(Row.slider("Tint strength", "dock_alpha", 0, 100, " %"));
        l.add(Row.toggle("Hairline border", "dock_border"));
        l.add(Row.header("Suggested & recent apps"));
        l.add(Row.toggle("Show recent apps", "dock_recents"));
        l.add(Row.slider("Recent apps", "dock_recent_count", 1, 6, ""));
        l.add(Row.note("Long-press an app icon and choose \"Add to Dock\" to pick your dock apps."));
        return l;
    }

    private List<Row> widgetsPage() {
        List<Row> l = new ArrayList<>();
        l.add(Row.header("Widgets"));
        l.add(Row.toggle("Show widgets on first page", "w_show"));
        l.add(Row.toggle("Clock", "w_clock"));
        l.add(Row.toggle("Calendar", "w_calendar"));
        l.add(Row.toggle("Weather", "w_weather"));
        l.add(Row.toggle("Siri Suggestions (shortcuts)", "w_shortcuts"));
        l.add(Row.toggle("Notes", "w_notes"));
        l.add(Row.header("Style"));
        l.add(Row.choice("Appearance", "w_dark", "Light", "Dark"));
        l.add(Row.slider("Corner radius", "w_radius", 0, 40, " dp"));
        l.add(Row.slider("Opacity", "w_alpha", 20, 100, " %"));
        l.add(Row.autoSlider("Widgets per row", "w_perrow", 0, 5, ""));
        l.add(Row.header("Clock"));
        l.add(Row.toggle("Digital clock", "w_digital"));
        l.add(Row.header("Weather (manual)"));
        l.add(Row.text("City", "w_city"));
        l.add(Row.slider("Temperature", "w_temp", -30, 50, "°"));
        l.add(Row.choice("Units", "w_units", "Celsius", "Fahrenheit"));
        l.add(Row.note("The weather widget shows the values you set here; it doesn't use the network."));
        return l;
    }

    private List<Row> wallpaperPage() {
        List<Row> l = new ArrayList<>();
        l.add(Row.header("Wallpaper"));
        l.add(Row.choice("Source", "wall_src", "System wallpaper", "Built-in", "Custom image"));
        l.add(Row.choice("Built-in style", "wall_preset", Wall.NAMES));
        l.add(Row.action("Choose image…", "Use a photo from your device as wallpaper", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*");
            startActivityForResult(i, 11);
        }));
        l.add(Row.slider("Dim", "wall_dim", 0, 70, " %"));
        l.add(Row.header("Storage permission"));
        boolean ok = Wall.hasStoragePermission(this);
        l.add(Row.action(ok ? "Storage permission granted" : "Grant storage permission",
                "Needed to read the system wallpaper and blur it behind the dock", () -> {
                    if (Wall.hasStoragePermission(this)) {
                        Toast.makeText(this, "Already granted", Toast.LENGTH_SHORT).show();
                    } else {
                        requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE}, 8);
                    }
                }));
        l.add(Row.action("Reload wallpaper and dock blur", "", () -> {
            Prefs.set("wall_src", Prefs.i("wall_src"));
            Toast.makeText(this, "Reloading when you return home", Toast.LENGTH_SHORT).show();
        }));
        return l;
    }

    private List<Row> animPage() {
        List<Row> l = new ArrayList<>();
        l.add(Row.header("App open / close"));
        l.add(Row.choice("Style", "anim_open", "iPadOS zoom", "Fade", "System default"));
        l.add(Row.choice("Window colour while opening", "anim_overlay", "Light", "Dark", "Match icon"));
        l.add(Row.slider("Speed", "anim_speed", 40, 250, " %"));
        l.add(Row.toggle("Home screen zooms and dims", "anim_home"));
        l.add(Row.header("Touch"));
        l.add(Row.toggle("Icon press shrink", "anim_press"));
        l.add(Row.toggle("Jiggle in edit mode", "anim_wiggle"));
        return l;
    }

    private List<Row> packsPage() {
        List<Row> l = new ArrayList<>();
        l.add(Row.header("Icon pack"));
        final String cur = Prefs.s("icon_pack");
        l.add(Row.action("Default (app icons)", cur.isEmpty() ? "✓ selected" : "", () -> {
            Prefs.set("icon_pack", "");
            render();
        }));
        PackageManager pm = getPackageManager();
        Map<String, String> found = new LinkedHashMap<>();
        String[] acts = {"org.adw.launcher.THEMES", "com.novalauncher.THEME",
                "com.gau.go.launcherex.theme", "com.anddoes.launcher.THEME"};
        for (String a : acts) {
            for (ResolveInfo ri : pm.queryIntentActivities(new Intent(a), 0))
                found.put(ri.activityInfo.packageName, String.valueOf(ri.loadLabel(pm)));
        }
        for (Map.Entry<String, String> e : found.entrySet()) {
            final String pkg = e.getKey();
            l.add(Row.action(e.getValue(), pkg.equals(cur) ? "✓ selected" : pkg, () -> {
                Prefs.set("icon_pack", pkg);
                render();
            }));
        }
        if (found.isEmpty()) {
            l.add(Row.note("No icon packs found. Install an ADW, Nova or Apex compatible icon pack, then come back here."));
        }
        return l;
    }

    private List<Row> searchPage() {
        List<Row> l = new ArrayList<>();
        l.add(Row.header("Spotlight"));
        l.add(Row.toggle("Swipe down to search", "search_on"));
        return l;
    }

    private List<Row> generalPage() {
        List<Row> l = new ArrayList<>();
        l.add(Row.header("System"));
        l.add(Row.toggle("Dark status bar icons", "status_dark"));
        l.add(Row.action("Set as default launcher", "Open Android's Home app settings", () -> {
            try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); }
            catch (Exception e) { Toast.makeText(this, "Open Settings > Apps > Default apps > Home", Toast.LENGTH_LONG).show(); }
        }));
        l.add(Row.header("Reset"));
        l.add(Row.action("Reset all launcher settings", "", () -> dlg().setTitle("Reset all settings?")
                .setPositiveButton("Reset", (d, w) -> { Prefs.reset(); render(); })
                .setNegativeButton("Cancel", null).show()));
        l.add(Row.note("Convert to iPadOS 1.0"));
        return l;
    }

    // ------------------------------------------------------------------ results

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 11 && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            Prefs.set("wall_uri", u.toString());
            Prefs.set("wall_src", 2);
            render();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        Prefs.set("wall_src", Prefs.i("wall_src"));
        render();
    }
}
