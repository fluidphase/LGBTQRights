package com.convert.ipados;

import android.content.Context;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;

import android.graphics.Bitmap;

/**
 * The dock. Its background is a blurred copy of the wallpaper region directly behind it
 * (the blurred bitmap is "pasted" into the dock using a shader aligned to screen coordinates),
 * plus a tint and a hairline border.
 */
class DockView extends LinearLayout {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix m = new Matrix();
    private final View wall;
    private BitmapShader sh;
    private Bitmap shBmp;
    private static final int[] TINTS = {0xFFFFFF, 0x000000, 0x2F7DFF, 0xE9E9F0};

    DockView(Context c, View wall) {
        super(c);
        this.wall = wall;
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER);
        setWillNotDraw(false);
        stroke.setStyle(Paint.Style.STROKE);
    }

    @Override
    protected void onDraw(Canvas c) {
        float rad = U.dp(getContext(), Prefs.i("dock_radius"));
        RectF r = new RectF(0, 0, getWidth(), getHeight());
        if (Wall.blur != null && wall.getWidth() > 0) {
            if (sh == null || shBmp != Wall.blur) {
                shBmp = Wall.blur;
                sh = new BitmapShader(shBmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            }
            int[] a = new int[2], b = new int[2];
            getLocationOnScreen(a);
            wall.getLocationOnScreen(b);
            m.reset();
            m.setScale(wall.getWidth() / (float) shBmp.getWidth(), wall.getHeight() / (float) shBmp.getHeight());
            m.postTranslate(b[0] - a[0], b[1] - a[1]);
            sh.setLocalMatrix(m);
            fill.setShader(sh);
            c.drawRoundRect(r, rad, rad, fill);
            fill.setShader(null);
        }
        int t = Math.max(0, Math.min(TINTS.length - 1, Prefs.i("dock_tint")));
        tint.setColor((Math.round(Prefs.i("dock_alpha") * 2.55f) << 24) | TINTS[t]);
        c.drawRoundRect(r, rad, rad, tint);
        if (Prefs.b("dock_border")) {
            float w = U.dp(getContext(), 1f);
            stroke.setStrokeWidth(w);
            stroke.setColor(0x44FFFFFF);
            RectF s = new RectF(w / 2, w / 2, getWidth() - w / 2, getHeight() - w / 2);
            c.drawRoundRect(s, rad, rad, stroke);
        }
    }
}
