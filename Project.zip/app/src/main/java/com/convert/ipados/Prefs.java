package com.convert.ipados;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** All launcher settings live here, with their defaults in one place. */
final class Prefs {
    private static SharedPreferences sp;
    private static final Map<String, Object> DEF = new HashMap<>();

    static {
        Object[][] d = {
            // home screen
            {"cols", 0}, {"rows", 0}, {"icon_size", 58}, {"icon_shape", 0}, {"icon_radius", 22},
            {"show_labels", true}, {"label_size", 11}, {"label_color", 0}, {"label_shadow", true},
            {"icon_gapv", 22}, {"page_dots", true}, {"sort", 0}, {"side_margin", 20}, {"legacy_bg", 0},
            // dock
            {"dock_show", true}, {"dock_size", 56}, {"dock_blur", 10}, {"dock_tint", 0}, {"dock_alpha", 32},
            {"dock_radius", 28}, {"dock_margin", 8}, {"dock_recents", true}, {"dock_recent_count", 3},
            {"dock_border", true}, {"dock_max", 6},
            // widgets
            {"w_show", true}, {"w_clock", true}, {"w_calendar", true}, {"w_weather", true},
            {"w_shortcuts", true}, {"w_notes", true}, {"w_radius", 22}, {"w_alpha", 94}, {"w_dark", 0},
            {"w_perrow", 0}, {"w_digital", false}, {"w_city", "Cupertino"}, {"w_temp", 19}, {"w_units", 0},
            {"notes_text", ""}, {"w_order", "clock\ncalendar\nweather\nshortcuts\nnotes"},
            // wallpaper
            {"wall_src", 0}, {"wall_preset", 0}, {"wall_uri", ""}, {"wall_dim", 0},
            // animations
            {"anim_speed", 100}, {"anim_open", 0}, {"anim_overlay", 0}, {"anim_press", true},
            {"anim_wiggle", true}, {"anim_home", true}, {"haptics", true}, {"home_layout", ""},
            // misc
            {"search_on", true}, {"status_dark", false}, {"asked_perm", false},
            {"hidden", ""}, {"dock_apps", ""}, {"recents", ""}, {"icon_pack", ""}, {"rev", 0}
        };
        for (Object[] e : d) DEF.put((String) e[0], e[1]);
    }

    static void init(Context c) {
        if (sp == null) sp = c.getApplicationContext().getSharedPreferences("ipados", Context.MODE_PRIVATE);
    }

    static int i(String k) { return sp.getInt(k, (Integer) DEF.get(k)); }
    static boolean b(String k) { return sp.getBoolean(k, (Boolean) DEF.get(k)); }
    static String s(String k) { return sp.getString(k, (String) DEF.get(k)); }

    private static void put(SharedPreferences.Editor e, String k, Object v) {
        if (v instanceof Integer) e.putInt(k, (Integer) v);
        else if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
        else e.putString(k, String.valueOf(v));
    }

    /** Save a value and tell the launcher to rebuild itself. */
    static void set(String k, Object v) {
        SharedPreferences.Editor e = sp.edit();
        put(e, k, v);
        e.putInt("rev", sp.getInt("rev", 0) + 1);
        e.apply();
    }

    /** Save a value without triggering a rebuild. */
    static void setQuiet(String k, Object v) {
        SharedPreferences.Editor e = sp.edit();
        put(e, k, v);
        e.apply();
    }

    static List<String> list(String k) {
        String s = s(k);
        List<String> l = new ArrayList<>();
        if (s.length() > 0) l.addAll(Arrays.asList(s.split("\n")));
        return l;
    }

    static void setList(String k, List<String> l, boolean quiet) {
        String v = String.join("\n", l);
        if (quiet) setQuiet(k, v); else set(k, v);
    }

    static void reset() {
        int r = i("rev");
        sp.edit().clear().putInt("rev", r + 1).apply();
    }
}
