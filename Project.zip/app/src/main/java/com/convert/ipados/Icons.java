package com.convert.ipados;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;

import java.util.HashMap;

/** Renders app icons with the chosen shape / icon pack and caches them. */
final class Icons {
    static IconPack pack;
    private static String sig = "";
    private static final HashMap<String, Bitmap> cache = new HashMap<>();

    static synchronized void configure(Context c) {
        String ps = Prefs.s("icon_pack");
        String n = ps + "|" + Prefs.i("icon_shape") + "|" + Prefs.i("icon_radius") + "|" + Prefs.i("legacy_bg");
        if (!n.equals(sig)) {
            sig = n;
            cache.clear();
            pack = ps.isEmpty() ? null : IconPack.load(c.getPackageManager(), ps);
        }
    }

    static synchronized Bitmap get(Context c, AppInfo a, int px) {
        String k = a.key() + "@" + px;
        Bitmap b = cache.get(k);
        if (b == null) {
            b = render(c, a, px);
            cache.put(k, b);
        }
        return b;
    }

    private static Bitmap render(Context c, AppInfo a, int px) {
        PackageManager pm = c.getPackageManager();
        Bitmap out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Drawable themed = pack != null ? pack.get(a.cn) : null;
        if (themed != null) {
            themed.setBounds(0, 0, px, px);
            themed.draw(cv);
            return out;
        }
        Drawable d = a.ri.loadIcon(pm);
        if (pack != null && pack.back != null) {
            pack.back.setBounds(0, 0, px, px);
            pack.back.draw(cv);
            int in = Math.round(px * (1f - pack.scale) / 2f) + Math.round(px * 0.1f);
            d.setBounds(in, in, px - in, px - in);
            d.draw(cv);
            if (pack.upon != null) {
                pack.upon.setBounds(0, 0, px, px);
                pack.upon.draw(cv);
            }
            return out;
        }
        Bitmap layer = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas lc = new Canvas(layer);
        if (d instanceof AdaptiveIconDrawable) {
            AdaptiveIconDrawable ad = (AdaptiveIconDrawable) d;
            int e = Math.round(px * 0.25f);
            Drawable bg = ad.getBackground(), fg = ad.getForeground();
            if (bg != null) {
                bg.setBounds(-e, -e, px + e, px + e);
                bg.draw(lc);
            } else {
                lc.drawColor(Color.WHITE);
            }
            if (fg != null) {
                fg.setBounds(-e, -e, px + e, px + e);
                fg.draw(lc);
            }
        } else {
            drawLegacy(lc, d, px);
        }
        Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG);
        mp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        lc.drawPath(U.shape(new RectF(0, 0, px, px), Prefs.i("icon_shape"), Prefs.i("icon_radius") / 100f), mp);
        cv.drawBitmap(layer, 0, 0, null);
        layer.recycle();
        return out;
    }

    /**
     * Non-adaptive icons: fill the whole shape instead of putting a tile + padding around them.
     * - Icons that already reach the edges are drawn full-bleed over their own edge colour,
     *   so there is no visible border and no shrinking.
     * - Icons with transparent edges (plain glyphs) are cropped to their content and scaled up,
     *   sitting on the "non-adaptive background" colour from settings.
     */
    private static void drawLegacy(Canvas lc, Drawable d, int px) {
        int S = px * 2; // render big so the crop/scale stays sharp
        Bitmap src = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        d.setBounds(0, 0, S, S);
        d.draw(new Canvas(src));
        int[] pix = new int[S * S];
        src.getPixels(pix, 0, S, 0, 0, S, S);
        src.recycle();

        int band = Math.max(1, S / 32);
        long r = 0, g = 0, b = 0;
        int solid = 0, total = 0;
        int minX = S, minY = S, maxX = -1, maxY = -1;
        for (int y = 0; y < S; y++) {
            for (int x = 0; x < S; x++) {
                int p = pix[y * S + x];
                int a = p >>> 24;
                if (a > 16) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
                if (x < band || y < band || x >= S - band || y >= S - band) {
                    total++;
                    if (a >= 230) {
                        r += (p >> 16) & 255;
                        g += (p >> 8) & 255;
                        b += p & 255;
                        solid++;
                    }
                }
            }
        }

        boolean fullBleed = total > 0 && solid >= total * 0.6f;
        Rect sr = new Rect(0, 0, S, S);
        if (fullBleed) {
            lc.drawColor(0xFF000000 | ((int) (r / solid) << 16) | ((int) (g / solid) << 8) | (int) (b / solid));
        } else {
            int[] bgc = {0xFFFFFFFF, 0xFFF2F2F7, 0xFF1C1C1E};
            lc.drawColor(bgc[Math.max(0, Math.min(2, Prefs.i("legacy_bg")))]);
            if (maxX >= 0) {
                float side = Math.max(maxX - minX + 1, maxY - minY + 1) / 0.8f;
                side = Math.max(S * 0.5f, Math.min(S, side));
                float cx = (minX + maxX + 1) / 2f, cy = (minY + maxY + 1) / 2f;
                float l = Math.max(0, Math.min(S - side, cx - side / 2f));
                float t = Math.max(0, Math.min(S - side, cy - side / 2f));
                sr.set(Math.round(l), Math.round(t), Math.round(l + side), Math.round(t + side));
            }
        }

        Bitmap full = Bitmap.createBitmap(pix, S, S, Bitmap.Config.ARGB_8888);
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        lc.drawBitmap(full, sr, new Rect(0, 0, px, px), bp);
        full.recycle();
    }
}
