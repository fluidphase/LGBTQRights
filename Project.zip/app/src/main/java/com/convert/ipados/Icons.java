package com.convert.ipados;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;

import java.util.HashMap;

/** Renders app icons with the chosen shape / icon pack and caches them. */
final class Icons {
    static IconPack pack;
    private static String sig = "";
    private static final HashMap<String, Bitmap> cache = new HashMap<>();

    static synchronized void configure(Context c) {
        String ps = Prefs.s("icon_pack");
        String n = ps + "|" + Prefs.i("icon_shape") + "|" + Prefs.i("icon_radius") + "|" + Prefs.i("legacy_bg");
        if (!n.equals(sig)) {
            sig = n;
            cache.clear();
            pack = ps.isEmpty() ? null : IconPack.load(c.getPackageManager(), ps);
        }
    }

    static synchronized Bitmap get(Context c, AppInfo a, int px) {
        String k = a.key() + "@" + px;
        Bitmap b = cache.get(k);
        if (b == null) {
            b = render(c, a, px);
            cache.put(k, b);
        }
        return b;
    }

    private static Bitmap render(Context c, AppInfo a, int px) {
        PackageManager pm = c.getPackageManager();
        Bitmap out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Drawable themed = pack != null ? pack.get(a.cn) : null;
        if (themed != null) {
            themed.setBounds(0, 0, px, px);
            themed.draw(cv);
            return out;
        }
        Drawable d = a.ri.loadIcon(pm);
        if (pack != null && pack.back != null) {
            pack.back.setBounds(0, 0, px, px);
            pack.back.draw(cv);
            int in = Math.round(px * (1f - pack.scale) / 2f) + Math.round(px * 0.1f);
            d.setBounds(in, in, px - in, px - in);
            d.draw(cv);
            if (pack.upon != null) {
                pack.upon.setBounds(0, 0, px, px);
                pack.upon.draw(cv);
            }
            return out;
        }
        Bitmap layer = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas lc = new Canvas(layer);
        if (d instanceof AdaptiveIconDrawable) {
            AdaptiveIconDrawable ad = (AdaptiveIconDrawable) d;
            int e = Math.round(px * 0.25f);
            Drawable bg = ad.getBackground(), fg = ad.getForeground();
            if (bg != null) {
                bg.setBounds(-e, -e, px + e, px + e);
                bg.draw(lc);
            } else {
                lc.drawColor(Color.WHITE);
            }
            if (fg != null) {
                fg.setBounds(-e, -e, px + e, px + e);
                fg.draw(lc);
            }
        } else {
            int[] bgc = {0xFFFFFFFF, 0xFFF2F2F7, 0xFF1C1C1E};
            lc.drawColor(bgc[Math.max(0, Math.min(2, Prefs.i("legacy_bg")))]);
            int in = Math.round(px * 0.14f);
            d.setBounds(in, in, px - in, px - in);
            d.draw(lc);
        }
        // Paint the artwork *through* the shape. (A DST_IN xfermode only affects pixels the path
        // covers, so it never cleared the corners and every icon stayed a square.)
        Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG);
        mp.setShader(new BitmapShader(layer, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        cv.drawPath(U.shape(new RectF(0, 0, px, px), Prefs.i("icon_shape"), Prefs.i("icon_radius") / 100f), mp);
        layer.recycle();
        return out;
    }
}
