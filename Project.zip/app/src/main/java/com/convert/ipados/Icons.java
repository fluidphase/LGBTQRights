package com.convert.ipados;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;

import java.util.HashMap;

/** Renders app icons with the chosen shape / icon pack and caches them. */
final class Icons {
    static IconPack pack;
    private static String sig = "";
    private static final HashMap<String, Bitmap> cache = new HashMap<>();

    static synchronized void configure(Context c) {
        String ps = Prefs.s("icon_pack");
        String n = ps + "|" + Prefs.i("icon_shape") + "|" + Prefs.i("icon_radius") + "|" + Prefs.i("legacy_bg");
        if (!n.equals(sig)) {
            sig = n;
            cache.clear();
            pack = ps.isEmpty() ? null : IconPack.load(c.getPackageManager(), ps);
        }
    }

    static synchronized Bitmap get(Context c, AppInfo a, int px) {
        String k = a.key() + "@" + px;
        Bitmap b = cache.get(k);
        if (b == null) {
            b = render(c, a, px);
            cache.put(k, b);
        }
        return b;
    }

    private static Bitmap render(Context c, AppInfo a, int px) {
        PackageManager pm = c.getPackageManager();
        Bitmap out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Drawable themed = pack != null ? pack.get(a.cn) : null;
        if (themed != null) {
            themed.setBounds(0, 0, px, px);
            themed.draw(cv);
            return out;
        }
        Drawable d = a.ri.loadIcon(pm);
        if (pack != null && pack.back != null) {
            pack.back.setBounds(0, 0, px, px);
            pack.back.draw(cv);
            int in = Math.round(px * (1f - pack.scale) / 2f) + Math.round(px * 0.1f);
            d.setBounds(in, in, px - in, px - in);
            d.draw(cv);
            if (pack.upon != null) {
                pack.upon.setBounds(0, 0, px, px);
                pack.upon.draw(cv);
            }
            return out;
        }
        Bitmap layer = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas lc = new Canvas(layer);
        if (d instanceof AdaptiveIconDrawable) {
            AdaptiveIconDrawable ad = (AdaptiveIconDrawable) d;
            int e = Math.round(px * 0.25f);
            Drawable bg = ad.getBackground(), fg = ad.getForeground();
            if (bg != null) {
                bg.setBounds(-e, -e, px + e, px + e);
                bg.draw(lc);
            } else {
                lc.drawColor(Color.WHITE);
            }
            if (fg != null) {
                fg.setBounds(-e, -e, px + e, px + e);
                fg.draw(lc);
            }
        } else {
            drawLegacy(lc, d, px);
        }
        // Paint the artwork *through* the shape. (A DST_IN xfermode only affects pixels the path
        // covers, so it never cleared the corners and every icon stayed a square.)
        Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG);
        mp.setShader(new BitmapShader(layer, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        cv.drawPath(U.shape(new RectF(0, 0, px, px), Prefs.i("icon_shape"), Prefs.i("icon_radius") / 100f), mp);
        layer.recycle();
        return out;
    }

    /**
     * Non-adaptive icons. Most of them already carry their own tile (a rounded square with the
     * artwork edge to edge), so painting them on a white square and shrinking them is what caused
     * the border / zoomed-out look. Measure the visible art instead:
     *  - mostly filled (a tile) -> crop its transparent padding and fill the whole icon, no border;
     *  - sparse (a bare glyph)  -> keep it on the chosen background, sized like an adaptive icon.
     */
    private static void drawLegacy(Canvas lc, Drawable d, int px) {
        int S = Math.max(px, 192);
        Bitmap src = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        d.setBounds(0, 0, S, S);
        d.draw(new Canvas(src));

        int[] pix = new int[S * S];
        src.getPixels(pix, 0, S, 0, 0, S, S);
        int minX = S, minY = S, maxX = -1, maxY = -1;
        for (int y = 0; y < S; y++) {
            for (int x = 0; x < S; x++) {
                if ((pix[y * S + x] >>> 24) > 40) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX < 0) { // fully transparent: nothing to measure
            lc.drawColor(legacyBg());
            src.recycle();
            return;
        }
        int bw = maxX - minX + 1, bh = maxY - minY + 1;
        long opaque = 0;
        for (int y = minY; y <= maxY; y++)
            for (int x = minX; x <= maxX; x++)
                if ((pix[y * S + x] >>> 24) > 200) opaque++;
        float fill = opaque / (float) (bw * bh);
        float side = Math.max(bw, bh);
        float cx = (minX + maxX + 1) / 2f, cy = (minY + maxY + 1) / 2f;
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        if (fill >= 0.72f) {
            // a real tile: scale its visible square to fill the whole icon
            float sc = px / side;
            lc.save();
            lc.scale(sc, sc);
            lc.translate(-(cx - side / 2f), -(cy - side / 2f));
            lc.drawBitmap(src, 0, 0, bp);
            lc.restore();
        } else {
            // a bare glyph: needs a backing, but fill the tile the way adaptive icons do
            lc.drawColor(legacyBg());
            float sc = px * 0.72f / side;
            lc.save();
            lc.translate(px / 2f, px / 2f);
            lc.scale(sc, sc);
            lc.translate(-cx, -cy);
            lc.drawBitmap(src, 0, 0, bp);
            lc.restore();
        }
        src.recycle();
    }

    private static int legacyBg() {
        int[] bgc = {0xFFFFFFFF, 0xFFF2F2F7, 0xFF1C1C1E};
        return bgc[Math.max(0, Math.min(2, Prefs.i("legacy_bg")))];
    }
}
