package com.convert.ipados;

import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Reads ADW / Nova / Apex style icon packs (appfilter.xml). */
final class IconPack {
    final Resources res;
    final String pkg;
    final Map<String, String> map = new HashMap<>();
    Drawable back, upon;
    float scale = 1f;

    private IconPack(Resources r, String p) { res = r; pkg = p; }

    static IconPack load(PackageManager pm, String pkg) {
        try {
            IconPack p = new IconPack(pm.getResourcesForApplication(pkg), pkg);
            p.parse();
            return p;
        } catch (Exception e) {
            return null;
        }
    }

    private void parse() throws Exception {
        XmlPullParser xp;
        int id = res.getIdentifier("appfilter", "xml", pkg);
        if (id != 0) {
            xp = res.getXml(id);
        } else {
            InputStream is = res.getAssets().open("appfilter.xml");
            xp = XmlPullParserFactory.newInstance().newPullParser();
            xp.setInput(is, "utf-8");
        }
        int ev;
        while ((ev = xp.next()) != XmlPullParser.END_DOCUMENT) {
            if (ev != XmlPullParser.START_TAG) continue;
            String n = xp.getName();
            if (n.equals("item")) {
                String comp = xp.getAttributeValue(null, "component");
                String dr = xp.getAttributeValue(null, "drawable");
                if (comp != null && dr != null && comp.startsWith("ComponentInfo{") && comp.endsWith("}")) {
                    map.put(comp.substring(14, comp.length() - 1), dr);
                }
            } else if (n.equals("iconback")) {
                String im = xp.getAttributeValue(null, "img1");
                if (im != null && back == null) back = drawable(im);
            } else if (n.equals("iconupon")) {
                String im = xp.getAttributeValue(null, "img1");
                if (im != null && upon == null) upon = drawable(im);
            } else if (n.equals("scale")) {
                String f = xp.getAttributeValue(null, "factor");
                if (f != null) {
                    try { scale = Float.parseFloat(f); } catch (Exception ignored) { }
                }
            }
        }
    }

    Drawable drawable(String name) {
        int id = res.getIdentifier(name, "drawable", pkg);
        if (id == 0) id = res.getIdentifier(name, "mipmap", pkg);
        if (id == 0) return null;
        try {
            return res.getDrawable(id, null);
        } catch (Exception e) {
            return null;
        }
    }

    Drawable get(ComponentName cn) {
        String n = map.get(cn.flattenToString());
        return n == null ? null : drawable(n);
    }
}
