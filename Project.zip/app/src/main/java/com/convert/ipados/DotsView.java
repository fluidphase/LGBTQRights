package com.convert.ipados;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

class DotsView extends View {
    private int n = 1;
    private float pos;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    DotsView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    void setCount(int n) { this.n = n; invalidate(); }
    void setPos(float p) { pos = p; invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        if (n < 2) return;
        float gap = 14 * d, r = 3.5f * d;
        float x0 = getWidth() / 2f - (n - 1) * gap / 2f, cy = getHeight() / 2f;
        int sel = Math.round(pos);
        for (int i = 0; i < n; i++) {
            p.setColor(i == sel ? 0xFFFFFFFF : 0x66FFFFFF);
            c.drawCircle(x0 + i * gap, cy, r, p);
        }
    }
}
