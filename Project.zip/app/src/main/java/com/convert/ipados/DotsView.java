package com.convert.ipados;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

class DotsView extends View {
    private int n = 1;
    private float pos;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    DotsView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    void setCount(int n) { this.n = n; invalidate(); }
    void setPos(float p) { pos = p; invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        if (n < 2) return;
        float gap = 14 * d, r = 3.5f * d;
        float x0 = getWidth() / 2f - (n - 1) * gap / 2f, cy = getHeight() / 2f;
        for (int i = 0; i < n; i++) {
            float f = Math.max(0f, 1f - Math.abs(i - pos)); // 1 on the current page, fades while swiping
            p.setColor(android.graphics.Color.argb(Math.round(255 * (0.4f + 0.6f * f)), 255, 255, 255));
            c.drawCircle(x0 + i * gap, cy, r * (1f + 0.18f * f), p);
        }
    }
}
