package com.convert.ipados;

import android.content.Context;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Spotlight-style search (swipe down on the home screen). */
class SpotlightView extends FrameLayout {
    interface Callback {
        void open(AppInfo a);
        void close();
    }

    private final Callback cb;
    private final EditText et;
    private final LinearLayout list;
    private final Paint bg = new Paint();
    private final Paint tint = new Paint();
    private final Matrix m = new Matrix();
    private List<AppInfo> apps = new ArrayList<>();
    private List<AppInfo> suggestions = new ArrayList<>();
    private final LinearLayout column;

    SpotlightView(Context c, Callback cb) {
        super(c);
        this.cb = cb;
        setWillNotDraw(false);
        setVisibility(GONE);
        setClickable(true);
        tint.setColor(0x66000000);
        column = new LinearLayout(c);
        column.setOrientation(LinearLayout.VERTICAL);
        int p = U.dpi(c, 16);
        column.setPadding(p, p, p, p);
        et = new EditText(c);
        et.setHint("Search");
        et.setHintTextColor(0xAAFFFFFF);
        et.setTextColor(Color.WHITE);
        et.setSingleLine(true);
        et.setTextSize(17);
        et.setPadding(U.dpi(c, 14), 0, U.dpi(c, 14), 0);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x44FFFFFF);
        g.setCornerRadius(U.dp(c, 12));
        et.setBackground(g);
        column.addView(et, new LinearLayout.LayoutParams(-1, U.dpi(c, 44)));
        ScrollView sv = new ScrollView(c);
        list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1f);
        lp.topMargin = U.dpi(c, 12);
        column.addView(sv, lp);
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(Math.min(U.dpi(c, 640),
                c.getResources().getDisplayMetrics().widthPixels), -1, Gravity.CENTER_HORIZONTAL);
        addView(column, cl);
        et.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int d) { }
            public void onTextChanged(CharSequence s, int a, int b, int d) { }
            public void afterTextChanged(Editable s) { refresh(s.toString()); }
        });
    }

    void setTopInset(int top) { column.setPadding(column.getPaddingLeft(), top + U.dpi(getContext(), 12),
            column.getPaddingRight(), column.getPaddingBottom()); }

    void setApps(List<AppInfo> all, List<AppInfo> recents) {
        apps = all;
        suggestions = recents;
        refresh(et.getText().toString());
    }

    private void refresh(String q) {
        list.removeAllViews();
        Context c = getContext();
        q = q.trim().toLowerCase(Locale.getDefault());
        List<AppInfo> res = new ArrayList<>();
        if (q.isEmpty()) {
            res.addAll(suggestions);
            if (!res.isEmpty()) header("Siri Suggestions");
        } else {
            for (AppInfo a : apps) {
                if (a.label.toLowerCase(Locale.getDefault()).contains(q)) res.add(a);
                if (res.size() >= 30) break;
            }
            if (!res.isEmpty()) header("Applications");
        }
        for (final AppInfo a : res) {
            LinearLayout row = new LinearLayout(c);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, U.dpi(c, 6), 0, U.dpi(c, 6));
            ImageView iv = new ImageView(c);
            iv.setImageBitmap(Icons.get(c, a, U.dpi(c, 44)));
            row.addView(iv, new LinearLayout.LayoutParams(U.dpi(c, 44), U.dpi(c, 44)));
            TextView tv = new TextView(c);
            tv.setText(a.label);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(17);
            tv.setPadding(U.dpi(c, 14), 0, 0, 0);
            row.addView(tv);
            row.setOnClickListener(v -> cb.open(a));
            list.addView(row);
        }
    }

    private void header(String t) {
        TextView h = new TextView(getContext());
        h.setText(t);
        h.setTextColor(0xCCFFFFFF);
        h.setTextSize(13);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setPadding(0, U.dpi(getContext(), 8), 0, U.dpi(getContext(), 4));
        list.addView(h);
    }

    void show() {
        et.setText("");
        refresh("");
        setAlpha(0f);
        setVisibility(VISIBLE);
        animate().alpha(1f).setDuration(180).start();
        et.requestFocus();
        InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        et.postDelayed(() -> im.showSoftInput(et, 0), 120);
    }

    void hide() {
        InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(et.getWindowToken(), 0);
        animate().alpha(0f).setDuration(150).withEndAction(() -> setVisibility(GONE)).start();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (Wall.blur != null) {
            BitmapShader sh = new BitmapShader(Wall.blur, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            m.reset();
            m.setScale(getWidth() / (float) Wall.blur.getWidth(), getHeight() / (float) Wall.blur.getHeight());
            sh.setLocalMatrix(m);
            bg.setShader(sh);
            c.drawRect(0, 0, getWidth(), getHeight(), bg);
        }
        c.drawRect(0, 0, getWidth(), getHeight(), tint);
    }
}
