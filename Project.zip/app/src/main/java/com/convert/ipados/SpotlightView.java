package com.convert.ipados;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.animation.PathInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * iPadOS 16 Spotlight: a floating frosted card near the top of the screen with a search field
 * (magnifier + mic), a "Siri Suggestions" row of app icons, and app results as you type.
 * The home screen stays visible behind it.
 */
class SpotlightView extends FrameLayout {
    interface Callback {
        void open(AppInfo a, RectF from);
        void web(String query);
        void close();
    }

    /** ScrollView that grows with its content up to a maximum height. */
    private static class MaxScroll extends ScrollView {
        private final int maxH;
        MaxScroll(Context c, int maxH) { super(c); this.maxH = maxH; }
        @Override
        protected void onMeasure(int w, int h) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST));
        }
    }

    private class Panel extends LinearLayout {
        Panel(Context c) {
            super(c);
            setOrientation(VERTICAL);
            setWillNotDraw(false);
            setClickable(true);
            final float rad = U.dp(c, 18);
            setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rad);
                }
            });
            setClipToOutline(true);
        }

        @Override
        protected void onDraw(Canvas c) {
            boolean dk = Theme.dark(getContext());
            // very strong white (or graphite) tint, but over a light blur so the wallpaper still shows through
            frost.draw(c, this, wall, U.dp(getContext(), 18), dk ? 0xB0262628 : 0xA6FFFFFF,
                    dk ? 0x22FFFFFF : 0x80FFFFFF, U.dp(getContext(), 0.75f));
        }
    }

    private static final int SUGGEST_COUNT = 6;

    private final Callback cb;
    private final View wall;
    private final Frost frost = new Frost(true);
    private Panel panel;
    private EditText et;
    private ImageView trail, mag;
    private View div;
    private LinearLayout list;
    private int panelW;
    private final float d;
    private List<AppInfo> apps = new ArrayList<>();
    private List<AppInfo> suggestions = new ArrayList<>();
    private boolean showing;

    SpotlightView(Context c, View wall, Callback callback) {
        super(c);
        this.cb = callback;
        this.wall = wall;
        this.d = c.getResources().getDisplayMetrics().density;
        setVisibility(GONE);
        setClickable(true);
        setWillNotDraw(false);
        setBackgroundColor(0x24000000);
        setOnClickListener(v -> cb.close());

        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        panelW = Math.min(U.dpi(c, 560), Math.round(dm.widthPixels * 0.92f));
        panel = new Panel(c);

        // ---- search field row
        LinearLayout bar = new LinearLayout(c);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(U.dpi(c, 16), 0, U.dpi(c, 14), 0);
        mag = icon(R.drawable.ic_search, 0xFF6E6E73);
        bar.addView(mag, new LinearLayout.LayoutParams(U.dpi(c, 20), U.dpi(c, 20)));
        et = new EditText(c);
        et.setBackground(null);
        et.setHint("Search");
        et.setHintTextColor(0xFF7C7C80);
        et.setTextColor(Theme.text(getContext()));
        et.setTextSize(18);
        et.setSingleLine(true);
        et.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        et.setPadding(U.dpi(c, 10), 0, U.dpi(c, 10), 0);
        bar.addView(et, new LinearLayout.LayoutParams(0, -1, 1f));
        trail = icon(R.drawable.ic_mic, 0xFF6E6E73);
        trail.setOnClickListener(v -> { if (et.length() > 0) et.setText(""); });
        bar.addView(trail, new LinearLayout.LayoutParams(U.dpi(c, 22), U.dpi(c, 22)));
        panel.addView(bar, new LinearLayout.LayoutParams(-1, U.dpi(c, 52)));

        div = new View(c);
        div.setBackgroundColor(0x26000000);
        panel.addView(div, new LinearLayout.LayoutParams(-1, 1));

        MaxScroll sv = new MaxScroll(c, Math.round(dm.heightPixels * 0.52f));
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(OVER_SCROLL_NEVER);
        list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(sv, new LinearLayout.LayoutParams(-1, -2));

        addView(panel, new FrameLayout.LayoutParams(panelW, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL));
        setTopInset(0);

        et.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int n) { }
            public void onTextChanged(CharSequence s, int a, int b, int n) { }
            public void afterTextChanged(Editable s) {
                trail.setImageResource(s.length() > 0 ? R.drawable.ic_close : R.drawable.ic_mic);
                refresh(s.toString());
            }
        });
        et.setOnEditorActionListener((tv, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_SEARCH || id == EditorInfo.IME_ACTION_DONE) { openFirst(); return true; }
            return false;
        });
    }

    boolean isShowing() { return showing; }

    private void applyTheme() {
        Context c = getContext();
        et.setTextColor(Theme.text(c));
        et.setHintTextColor(Theme.dark(c) ? 0xFF8E8E93 : 0xFF7C7C80);
        mag.setColorFilter(Theme.sub(c));
        trail.setColorFilter(Theme.sub(c));
        div.setBackgroundColor(Theme.hair(c));
        panel.invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (panel != null && showing) {
            Frost.shadow(c, panel, U.dp(getContext(), 18), U.dp(getContext(), 30), U.dp(getContext(), 10), 0x40000000);
        }
    }

    void setTopInset(int top) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) panel.getLayoutParams();
        int h = getResources().getDisplayMetrics().heightPixels;
        lp.topMargin = top + Math.round(h * 0.075f);
        panel.setLayoutParams(lp);
    }

    void setApps(List<AppInfo> all, List<AppInfo> recents) {
        apps = all;
        suggestions = recents;
        refresh(et.getText().toString());
    }

    // ------------------------------------------------------------ content

    private ImageView icon(int res, int color) {
        ImageView iv = new ImageView(getContext());
        iv.setImageResource(res);
        iv.setColorFilter(color);
        return iv;
    }

    private RippleDrawable ripple() {
        return new RippleDrawable(ColorStateList.valueOf(Theme.press(getContext())), null, new ColorDrawable(Color.BLACK));
    }

    private List<AppInfo> match(String lq) {
        List<AppInfo> res = new ArrayList<>();
        for (AppInfo a : apps) if (a.label.toLowerCase(Locale.getDefault()).startsWith(lq)) res.add(a);
        for (AppInfo a : apps) {
            if (res.size() >= 30) break;
            String l = a.label.toLowerCase(Locale.getDefault());
            if (!l.startsWith(lq) && l.contains(lq)) res.add(a);
        }
        return res;
    }

    private void refresh(String raw) {
        list.removeAllViews();
        Context c = getContext();
        final String q = raw.trim();
        String lq = q.toLowerCase(Locale.getDefault());
        list.setPadding(U.dpi(c, 8), U.dpi(c, 6), U.dpi(c, 8), U.dpi(c, 8));
        if (lq.isEmpty()) {
            suggestionBlock();
            return;
        }
        List<AppInfo> res = match(lq);
        if (!res.isEmpty()) {
            header("Applications", false);
            for (AppInfo a : res) list.addView(appRow(a));
        }
        list.addView(webRow(q));
    }

    private void header(String t, boolean chevron) {
        Context c = getContext();
        LinearLayout h = new LinearLayout(c);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(U.dpi(c, 8), U.dpi(c, 8), U.dpi(c, 8), U.dpi(c, 6));
        TextView tv = new TextView(c);
        tv.setText(t);
        tv.setTextColor(Theme.text(getContext()));
        tv.setTextSize(17);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        h.addView(tv, new LinearLayout.LayoutParams(0, -2, 1f));
        if (chevron) h.addView(icon(R.drawable.ic_chevron_right, 0xFF8E8E93), new LinearLayout.LayoutParams(U.dpi(c, 20), U.dpi(c, 20)));
        list.addView(h, new LinearLayout.LayoutParams(-1, -2));
    }

    private void suggestionBlock() {
        Context c = getContext();
        List<AppInfo> row = new ArrayList<>();
        for (AppInfo a : suggestions) if (row.size() < SUGGEST_COUNT) row.add(a);
        for (AppInfo a : apps) {
            if (row.size() >= SUGGEST_COUNT) break;
            if (!row.contains(a)) row.add(a);
        }
        if (row.isEmpty()) return;
        header("Siri Suggestions", true);
        LinearLayout cells = new LinearLayout(c);
        cells.setOrientation(LinearLayout.HORIZONTAL);
        cells.setPadding(0, 0, 0, U.dpi(c, 6));
        for (int i = 0; i < SUGGEST_COUNT; i++) {
            if (i >= row.size()) {
                cells.addView(new View(c), new LinearLayout.LayoutParams(0, 1, 1f));
                continue;
            }
            final AppInfo a = row.get(i);
            LinearLayout cell = new LinearLayout(c);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(U.dpi(c, 2), U.dpi(c, 6), U.dpi(c, 2), U.dpi(c, 6));
            cell.setBackground(ripple());
            final ImageView iv = new ImageView(c);
            iv.setImageBitmap(Icons.get(c, a, U.dpi(c, 52)));
            cell.addView(iv, new LinearLayout.LayoutParams(U.dpi(c, 52), U.dpi(c, 52)));
            TextView tv = new TextView(c);
            tv.setText(a.label);
            tv.setTextColor(Theme.text(getContext()));
            tv.setTextSize(12);
            tv.setSingleLine(true);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
            tl.topMargin = U.dpi(c, 4);
            cell.addView(tv, tl);
            cell.setOnClickListener(v -> cb.open(a, rectOf(iv)));
            cells.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        list.addView(cells, new LinearLayout.LayoutParams(-1, -2));
    }

    private View appRow(final AppInfo a) {
        Context c = getContext();
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(U.dpi(c, 8), U.dpi(c, 6), U.dpi(c, 8), U.dpi(c, 6));
        row.setBackground(ripple());
        final ImageView iv = new ImageView(c);
        iv.setImageBitmap(Icons.get(c, a, U.dpi(c, 44)));
        row.addView(iv, new LinearLayout.LayoutParams(U.dpi(c, 44), U.dpi(c, 44)));
        TextView tv = new TextView(c);
        tv.setText(a.label);
        tv.setTextColor(Theme.text(getContext()));
        tv.setTextSize(17);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setPadding(U.dpi(c, 14), 0, 0, 0);
        row.addView(tv, new LinearLayout.LayoutParams(0, -2, 1f));
        row.setOnClickListener(v -> cb.open(a, rectOf(iv)));
        return row;
    }

    private View webRow(final String q) {
        Context c = getContext();
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(U.dpi(c, 8), U.dpi(c, 6), U.dpi(c, 8), U.dpi(c, 6));
        row.setBackground(ripple());
        ImageView iv = icon(R.drawable.ic_search, Theme.text(getContext()));
        int p = U.dpi(c, 10);
        iv.setPadding(p, p, p, p);
        GradientDrawable sbg = new GradientDrawable();
        sbg.setColor(Theme.dark(c) ? 0x22FFFFFF : 0x14000000);
        sbg.setCornerRadius(U.dp(c, 10));
        iv.setBackground(sbg);
        row.addView(iv, new LinearLayout.LayoutParams(U.dpi(c, 44), U.dpi(c, 44)));
        TextView tv = new TextView(c);
        tv.setText("Search the Web for “" + q + "”");
        tv.setTextColor(Theme.text(getContext()));
        tv.setTextSize(17);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setPadding(U.dpi(c, 14), 0, 0, 0);
        row.addView(tv, new LinearLayout.LayoutParams(0, -2, 1f));
        row.setOnClickListener(v -> cb.web(q));
        return row;
    }

    private RectF rectOf(View v) {
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        return new RectF(l[0], l[1], l[0] + v.getWidth(), l[1] + v.getHeight());
    }

    private void openFirst() {
        String q = et.getText().toString().trim();
        if (q.isEmpty()) return;
        List<AppInfo> r = match(q.toLowerCase(Locale.getDefault()));
        if (r.isEmpty()) {
            cb.web(q);
        } else {
            // no icon on screen to zoom from: grow from the middle of the panel
            RectF from = rectOf(panel);
            float cx = from.centerX(), cy = from.top + U.dp(getContext(), 60), s = U.dp(getContext(), 28);
            cb.open(r.get(0), new RectF(cx - s, cy - s, cx + s, cy + s));
        }
    }

    // ------------------------------------------------------------ show / hide

    void show() {
        showing = true;
        animate().cancel();
        panel.animate().cancel();
        applyTheme();
        et.setText("");
        refresh("");
        setVisibility(VISIBLE);
        setAlpha(0f);
        panel.setPivotX(panelW / 2f);
        panel.setPivotY(0f);
        panel.setScaleX(0.9f);
        panel.setScaleY(0.9f);
        panel.setTranslationY(-U.dp(getContext(), 22));
        animate().alpha(1f).setDuration(U.ms(280)).setUpdateListener(an -> invalidate()).start();
        panel.animate().scaleX(1f).scaleY(1f).translationY(0f).setDuration(U.ms(540))
                .setInterpolator(new PathInterpolator(0.22f, 1.08f, 0.36f, 1f)).setUpdateListener(an -> invalidate()).start();
        et.requestFocus();
        final InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        et.postDelayed(() -> { if (showing) im.showSoftInput(et, 0); }, 140);
    }

    void hide() {
        if (!showing) return;
        showing = false;
        InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(et.getWindowToken(), 0);
        et.clearFocus();
        animate().alpha(0f).setDuration(U.ms(260)).setUpdateListener(an -> invalidate()).withEndAction(() -> { if (!showing) setVisibility(GONE); }).start();
        panel.animate().scaleX(0.96f).scaleY(0.96f).translationY(-U.dp(getContext(), 10)).setDuration(U.ms(260)).start();
    }
}
