package com.convert.ipados;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/**
 * The iPadOS app open / close animation: a rounded window grows out of the tapped icon
 * (with the icon ghosting out inside it) until it fills the screen. Playing it in reverse
 * shrinks the window back into the icon.
 */
class LaunchOverlay extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF from = new RectF();
    private Bitmap icon;
    private int color = 0xFFF2F2F7;
    private int style;
    float progress;

    LaunchOverlay(Context c) {
        super(c);
        setVisibility(GONE);
        setClickable(true); // swallow touches while an app is opening
    }

    void prepare(RectF iconRect, Bitmap icon, int color, int style) {
        this.icon = icon;
        this.color = color;
        this.style = style;
        setVisibility(VISIBLE);
        int[] l = new int[2];
        getLocationOnScreen(l);
        from.set(iconRect);
        from.offset(-l[0], -l[1]);
        setProgress(0f);
    }

    void setProgress(float p) {
        progress = p;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight(), e = progress;
        if (style == 1) { // fade
            fill.setColor(color);
            fill.setAlpha(Math.round(255 * U.clamp(e, 0f, 1f)));
            c.drawRect(0, 0, W, H, fill);
            return;
        }
        float l = U.lerp(from.left, 0, e), t = U.lerp(from.top, 0, e);
        float r = U.lerp(from.right, W, e), b = U.lerp(from.bottom, H, e);
        float rad = U.lerp(from.width() * 0.225f, 0f, U.clamp(e * 1.1f, 0f, 1f));
        fill.setColor(color);
        fill.setAlpha(Math.round(255 * U.clamp(e * 4f, 0f, 1f)));
        c.drawRoundRect(l, t, r, b, rad, rad, fill);
        float ia = 1f - U.clamp(e / 0.5f, 0f, 1f);
        if (icon != null && ia > 0f) {
            float s = Math.min(r - l, b - t), cx = (l + r) / 2f, cy = (t + b) / 2f;
            ip.setAlpha(Math.round(255 * ia));
            c.drawBitmap(icon, null, new RectF(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2), ip);
        }
    }
}
