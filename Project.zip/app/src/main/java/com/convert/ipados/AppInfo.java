package com.convert.ipados;

import android.content.ComponentName;
import android.content.pm.ResolveInfo;

import java.util.List;

final class AppInfo {
    ResolveInfo ri;
    ComponentName cn;
    String label;
    long installTime;
    /** Non-null when this entry is a home-screen folder rather than a real app. */
    String folderId;
    List<String> folderKeys;

    String key() { return folderId != null ? "f:" + folderId : cn.flattenToString(); }
}
