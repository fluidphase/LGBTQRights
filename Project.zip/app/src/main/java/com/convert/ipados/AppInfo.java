package com.convert.ipados;

import android.content.ComponentName;
import android.content.pm.ResolveInfo;

final class AppInfo {
    ResolveInfo ri;
    ComponentName cn;
    String label;
    long installTime;

    String key() { return cn.flattenToString(); }
}
