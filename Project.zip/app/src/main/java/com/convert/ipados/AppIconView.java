package com.convert.ipados;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;

/** One icon + label cell. Supports the press-shrink and the iPadOS "jiggle" edit mode. */
class AppIconView extends View {
    final AppInfo app;
    final Bitmap icon;
    final int iconPx;
    final boolean label;
    boolean editing;
    Runnable onBadge;

    private final Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private CharSequence text;
    private int textW = -1;
    private ObjectAnimator wig;

    AppIconView(Context c, AppInfo a, Bitmap icon, int iconPx, boolean label) {
        super(c);
        this.app = a;
        this.icon = icon;
        this.iconPx = iconPx;
        this.label = label;
        d = c.getResources().getDisplayMetrics().density;
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setTextSize(Prefs.i("label_size") * c.getResources().getDisplayMetrics().scaledDensity);
        tp.setColor(Prefs.i("label_color") == 1 ? 0xFF000000 : 0xFFFFFFFF);
        if (Prefs.b("label_shadow") && Prefs.i("label_color") == 0) tp.setShadowLayer(2 * d, 0, d, 0x88000000);
        setClickable(true);
    }

    static int labelHeight(Context c) {
        float sd = c.getResources().getDisplayMetrics().scaledDensity;
        return Math.round(Prefs.i("label_size") * sd * 1.35f) + U.dpi(c, 6);
    }

    private float top() { return label ? 0 : (getHeight() - iconPx) / 2f; }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, top = top();
        c.drawBitmap(icon, null, new RectF(cx - iconPx / 2f, top, cx + iconPx / 2f, top + iconPx), ip);
        if (label) {
            if (text == null || textW != getWidth()) {
                textW = getWidth();
                text = TextUtils.ellipsize(app.label, tp, getWidth() - 4 * d, TextUtils.TruncateAt.END);
            }
            c.drawText(text, 0, text.length(), cx, top + iconPx + 5 * d - tp.ascent(), tp);
        }
        if (editing) {
            float bx = cx - iconPx / 2f + 2 * d, by = top + 2 * d;
            bp.setStyle(Paint.Style.FILL);
            bp.setColor(0xFF8E8E93);
            c.drawCircle(bx, by, 9 * d, bp);
            bp.setColor(0xFFFFFFFF);
            c.drawRect(bx - 4.5f * d, by - 1 * d, bx + 4.5f * d, by + 1 * d, bp);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (editing && a == MotionEvent.ACTION_UP && onBadge != null) {
            float bx = getWidth() / 2f - iconPx / 2f + 2 * d, by = top() + 2 * d;
            if (Math.hypot(e.getX() - bx, e.getY() - by) < 16 * d) {
                onBadge.run();
                return true;
            }
        }
        if (Prefs.b("anim_press") && !editing) {
            if (a == MotionEvent.ACTION_DOWN) animate().scaleX(0.88f).scaleY(0.88f).setDuration(110).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                animate().scaleX(1f).scaleY(1f).setDuration(160).start();
        }
        return super.onTouchEvent(e);
    }

    void setEditing(boolean on) {
        editing = on;
        if (on && Prefs.b("anim_wiggle")) {
            if (wig == null) {
                wig = ObjectAnimator.ofFloat(this, View.ROTATION, -2.2f, 2.2f);
                wig.setDuration(110 + (long) (Math.random() * 50));
                wig.setRepeatCount(ValueAnimator.INFINITE);
                wig.setRepeatMode(ValueAnimator.REVERSE);
            }
            wig.start();
            wig.setCurrentPlayTime((long) (Math.random() * 100));
        } else {
            if (wig != null) wig.cancel();
            setRotation(0);
        }
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (wig != null) wig.cancel();
    }

    RectF iconRectOnScreen() {
        int[] l = new int[2];
        getLocationOnScreen(l);
        float cx = l[0] + getWidth() / 2f;
        float t = l[1] + top();
        return new RectF(cx - iconPx / 2f, t, cx + iconPx / 2f, t + iconPx);
    }
}
