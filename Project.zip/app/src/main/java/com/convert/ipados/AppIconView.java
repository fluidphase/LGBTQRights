package com.convert.ipados;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/** One icon + label cell. Supports the press-shrink and the iPadOS "jiggle" edit mode. */
class AppIconView extends View {
    final AppInfo app;
    final Bitmap icon;
    final int iconPx;
    final boolean label;
    boolean editing;
    Runnable onBadge;
    DragHost host;           // null = this icon can't be dragged (dock)
    boolean longFired;       // set by the long-press listener so a following move starts a drag

    /** Receives raw screen coordinates while this icon is being dragged. */
    interface DragHost {
        void dragStart(AppIconView v, float rawX, float rawY);
        void dragMove(float rawX, float rawY);
        void dragEnd(boolean cancelled);
    }

    private boolean dragging, moved, merge, noBadge;
    private float downRawX, downRawY, lastRawX, lastRawY;
    private final int slop;
    private final Runnable holdRun = () -> {
        if (editing && !moved && !dragging && host != null) beginDrag(lastRawX, lastRawY);
    };

    private final Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private CharSequence text;
    private int textW = -1;
    private ObjectAnimator wig;
    private ValueAnimator pop;
    private float badgeS = 1f;

    AppIconView(Context c, AppInfo a, Bitmap icon, int iconPx, boolean label) {
        super(c);
        this.app = a;
        this.icon = icon;
        this.iconPx = iconPx;
        this.label = label;
        d = c.getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        tp.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setTextSize(Prefs.i("label_size") * c.getResources().getDisplayMetrics().scaledDensity);
        tp.setColor(Prefs.i("label_color") == 1 ? 0xFF000000 : 0xFFFFFFFF);
        if (Prefs.b("label_shadow") && Prefs.i("label_color") == 0) tp.setShadowLayer(2 * d, 0, d, 0x88000000);
        setClickable(true);
    }

    static int labelHeight(Context c) {
        float sd = c.getResources().getDisplayMetrics().scaledDensity;
        return Math.round(Prefs.i("label_size") * sd * 1.35f) + U.dpi(c, 6);
    }

    private float top() { return label ? 0 : (getHeight() - iconPx) / 2f; }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, top = top();
        if (merge) {
            float g = 7 * d;
            bp.setStyle(Paint.Style.FILL);
            bp.setColor(0x66FFFFFF);
            c.drawRoundRect(cx - iconPx / 2f - g, top - g, cx + iconPx / 2f + g, top + iconPx + g, iconPx * 0.3f, iconPx * 0.3f, bp);
        }
        c.drawBitmap(icon, null, new RectF(cx - iconPx / 2f, top, cx + iconPx / 2f, top + iconPx), ip);
        if (label) {
            if (text == null || textW != getWidth()) {
                textW = getWidth();
                text = TextUtils.ellipsize(app.label, tp, getWidth() - 4 * d, TextUtils.TruncateAt.END);
            }
            c.drawText(text, 0, text.length(), cx, top + iconPx + 5 * d - tp.ascent(), tp);
        }
        if (editing && !noBadge) {
            float bx = cx - iconPx / 2f + 2 * d, by = top + 2 * d;
            bp.setStyle(Paint.Style.FILL);
            bp.setColor(0x33000000);
            c.drawCircle(bx, by + 1 * d, 9.5f * d * badgeS, bp);
            bp.setColor(0xFF8E8E93);
            c.drawCircle(bx, by, 9 * d * badgeS, bp);
            bp.setColor(0xFFFFFFFF);
            c.drawRoundRect(bx - 4.5f * d * badgeS, by - 1 * d, bx + 4.5f * d * badgeS, by + 1 * d, d, d, bp);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        lastRawX = e.getRawX();
        lastRawY = e.getRawY();
        if (dragging) {
            if (a == MotionEvent.ACTION_MOVE) {
                host.dragMove(lastRawX, lastRawY);
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                dragging = false;
                host.dragEnd(a == MotionEvent.ACTION_CANCEL);
            }
            return true;
        }
        if (host != null) {
            if (a == MotionEvent.ACTION_DOWN) {
                downRawX = lastRawX;
                downRawY = lastRawY;
                moved = false;
                longFired = false;
                removeCallbacks(holdRun);
                // in edit mode a short hold lifts the icon; a quick swipe still pages the home screen
                if (editing && !onBadgeArea(e.getX(), e.getY())) postDelayed(holdRun, 200);
            } else if (a == MotionEvent.ACTION_MOVE) {
                if (Math.hypot(lastRawX - downRawX, lastRawY - downRawY) > slop) {
                    moved = true;
                    removeCallbacks(holdRun);
                    if (longFired) { // long-press menu is showing and the finger keeps going: drag
                        beginDrag(lastRawX, lastRawY);
                        return true;
                    }
                }
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                removeCallbacks(holdRun);
            }
        }
        if (editing && a == MotionEvent.ACTION_UP && onBadge != null) {
            float bx = getWidth() / 2f - iconPx / 2f + 2 * d, by = top() + 2 * d;
            if (Math.hypot(e.getX() - bx, e.getY() - by) < 16 * d) {
                onBadge.run();
                return true;
            }
        }
        if (Prefs.b("anim_press") && !editing) {
            if (a == MotionEvent.ACTION_DOWN)
                animate().scaleX(0.88f).scaleY(0.88f).setDuration(U.ms(170)).setInterpolator(new DecelerateInterpolator()).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                animate().scaleX(1f).scaleY(1f).setDuration(U.ms(440)).setInterpolator(new OvershootInterpolator(2.0f)).start();
        }
        return super.onTouchEvent(e);
    }

    private boolean onBadgeArea(float x, float y) {
        float bx = getWidth() / 2f - iconPx / 2f + 2 * d, by = top() + 2 * d;
        return Math.hypot(x - bx, y - by) < 18 * d;
    }

    private void beginDrag(float rx, float ry) {
        if (host == null || dragging) return;
        dragging = true;
        setPressed(false);
        animate().cancel();
        setScaleX(1f);
        setScaleY(1f);
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        host.dragStart(this, rx, ry);
    }

    /** Picture of the icon + label without the edit badge (used for the floating drag copy). */
    Bitmap lift() {
        noBadge = true;
        Bitmap b = U.snapshot(this);
        noBadge = false;
        return b;
    }

    /** Highlight while another icon is held over this one (about to make / join a folder). */
    void setMerge(boolean on) {
        if (merge == on) return;
        merge = on;
        animate().scaleX(on ? 1.12f : 1f).scaleY(on ? 1.12f : 1f).setDuration(U.ms(280))
                .setInterpolator(new OvershootInterpolator(1.5f)).start();
        invalidate();
    }

    void setEditing(boolean on) {
        boolean was = editing;
        editing = on;
        if (pop != null) pop.cancel();
        if (on && !was) {
            badgeS = 0f;
            pop = ValueAnimator.ofFloat(0f, 1f);
            pop.setDuration(U.ms(460));
            pop.setInterpolator(new OvershootInterpolator(1.7f));
            pop.addUpdateListener(an -> { badgeS = (Float) an.getAnimatedValue(); invalidate(); });
            pop.start();
        } else {
            badgeS = 1f;
        }
        if (on && Prefs.b("anim_wiggle")) {
            if (wig == null) {
                wig = ObjectAnimator.ofFloat(this, View.ROTATION, -1.7f, 1.7f);
                wig.setDuration(U.ms(230 + (long) (Math.random() * 70)));
                wig.setRepeatCount(ValueAnimator.INFINITE);
                wig.setRepeatMode(ValueAnimator.REVERSE);
            }
            wig.start();
            wig.setCurrentPlayTime((long) (Math.random() * 200));
        } else {
            if (wig != null) wig.cancel();
            setRotation(0);
        }
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(holdRun);
        if (wig != null) wig.cancel();
        if (pop != null) pop.cancel();
    }

    RectF iconRectOnScreen() {
        int[] l = new int[2];
        getLocationOnScreen(l);
        // undo the press-shrink / overshoot scale so the rect is where the icon rests
        float cx = l[0] - getPivotX() * (1f - getScaleX()) + getWidth() / 2f;
        float t = l[1] - getPivotY() * (1f - getScaleY()) + top();
        return new RectF(cx - iconPx / 2f, t, cx + iconPx / 2f, t + iconPx);
    }
}
