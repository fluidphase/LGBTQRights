package com.convert.ipados;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * The widget area on the first home page.
 * Every widget is laid out at (0,0) and positioned with translationX/Y, so moving widgets around is
 * just animating translations. In edit mode widgets jiggle, show a minus badge, and can be dragged
 * to a different slot.
 */
class WidgetGrid extends FrameLayout {
    interface Listener {
        void onReorder(List<String> ids);
        void onRemove(String id);
        void onMenu(String id, View v);
    }

    static final class Item {
        final String id;
        final View v;
        final int span;
        int x, y, w, h;
        ObjectAnimator wig;
        Item(String id, View v, int span) { this.id = id; this.v = v; this.span = span; }
    }

    Listener listener;

    private final List<Item> items = new ArrayList<>();
    private final int per, card, gap, maxH, slop;
    private final float d;
    private final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean editing;
    private Item hit, drag;
    private boolean badgeHit;
    private float downX, downY, grabX, grabY;
    private long lastSwap;
    private int usedH;

    WidgetGrid(Context c, int per, int card, int gap, int maxH) {
        super(c);
        this.per = Math.max(1, per);
        this.card = card;
        this.gap = gap;
        this.maxH = maxH;
        this.d = c.getResources().getDisplayMetrics().density;
        this.slop = ViewConfiguration.get(c).getScaledTouchSlop();
        setWillNotDraw(false);
        setClipChildren(false);
    }

    int count() { return items.size(); }
    int usedHeight() { return usedH; }

    /** Same packing rule everywhere: left to right, wrapping when the row is full. */
    private int slots(List<Item> l, int[][] out) {
        int col = 0, y = 0, used = 0;
        for (int i = 0; i < l.size(); i++) {
            int s = Math.min(per, l.get(i).span);
            if (col + s > per) { col = 0; y += card + gap; }
            out[i] = new int[]{col * (card + gap), y, card * s + gap * (s - 1), card};
            col += s;
            used = y + card;
        }
        return used;
    }

    /** Adds a widget; returns false if there is no room left on this page. */
    boolean add(final String id, View v, int span) {
        Item it = new Item(id, v, span);
        items.add(it);
        int[][] out = new int[items.size()][];
        int used = slots(items, out);
        int[] s = out[items.size() - 1];
        if (s[1] + card > maxH && s[1] > 0) {
            items.remove(it);
            return false;
        }
        usedH = used;
        v.setOnLongClickListener(x -> {
            if (!editing && listener != null) listener.onMenu(id, x);
            return true;
        });
        addView(v, new FrameLayout.LayoutParams(s[2], s[3]));
        apply(out);
        place(false);
        return true;
    }

    private void apply(int[][] out) {
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            it.x = out[i][0];
            it.y = out[i][1];
            it.w = out[i][2];
            it.h = out[i][3];
        }
    }

    private void place(boolean animate) {
        for (Item it : items) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) it.v.getLayoutParams();
            if (lp.width != it.w || lp.height != it.h) {
                lp.width = it.w;
                lp.height = it.h;
                it.v.setLayoutParams(lp);
            }
            if (it == drag) continue;
            if (animate) {
                it.v.animate().translationX(it.x).translationY(it.y).setDuration(U.ms(360))
                        .setInterpolator(new DecelerateInterpolator(1.6f)).start();
            } else {
                it.v.setTranslationX(it.x);
                it.v.setTranslationY(it.y);
            }
        }
    }

    // ------------------------------------------------------------ edit mode

    void setEditing(boolean on) {
        if (editing == on) return;
        editing = on;
        if (!on) endDrag(false);
        for (Item it : items) {
            if (it.wig != null) { it.wig.cancel(); it.wig = null; }
            it.v.setRotation(0f);
            if (on && Prefs.b("anim_wiggle")) {
                ObjectAnimator a = ObjectAnimator.ofFloat(it.v, View.ROTATION, -0.5f, 0.5f);
                a.setDuration(U.ms(280 + (long) (Math.random() * 90)));
                a.setRepeatCount(ValueAnimator.INFINITE);
                a.setRepeatMode(ValueAnimator.REVERSE);
                a.start();
                a.setCurrentPlayTime((long) (Math.random() * 200));
                it.wig = a;
            }
        }
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        for (Item it : items) if (it.wig != null) it.wig.cancel();
    }

    private Item itemAt(float x, float y) {
        for (int i = items.size() - 1; i >= 0; i--) {
            Item it = items.get(i);
            if (x >= it.x && x <= it.x + it.w && y >= it.y && y <= it.y + it.h) return it;
        }
        return null;
    }

    private boolean inBadge(Item it, float x, float y) {
        return Math.hypot(x - (it.x + 12 * d), y - (it.y + 12 * d)) < 22 * d;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) { return editing; }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!editing) return false;
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                hit = itemAt(x, y);
                badgeHit = hit != null && inBadge(hit, x, y);
                if (hit != null && getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                return hit != null;
            case MotionEvent.ACTION_MOVE:
                if (hit == null) return false;
                if (drag == null && !badgeHit && Math.hypot(x - downX, y - downY) > slop) startDrag(hit, x, y);
                if (drag != null) moveDrag(x, y);
                return true;
            case MotionEvent.ACTION_UP:
                if (drag != null) {
                    endDrag(true);
                } else if (hit != null && badgeHit && inBadge(hit, x, y)) {
                    final Item gone = hit;
                    hit = null;
                    gone.v.animate().scaleX(0.7f).scaleY(0.7f).alpha(0f).setDuration(U.ms(260))
                            .withEndAction(() -> { if (listener != null) listener.onRemove(gone.id); }).start();
                }
                hit = null;
                return true;
            case MotionEvent.ACTION_CANCEL:
                if (drag != null) endDrag(true);
                hit = null;
                return true;
            default:
                return true;
        }
    }

    private void startDrag(Item it, float x, float y) {
        drag = it;
        if (it.wig != null) { it.wig.cancel(); it.wig = null; }
        it.v.setRotation(0f);
        it.v.animate().cancel();
        bringChildToFront(it.v);
        grabX = x - it.v.getTranslationX();
        grabY = y - it.v.getTranslationY();
        it.v.animate().scaleX(1.06f).scaleY(1.06f).alpha(0.94f).setDuration(U.ms(240))
                .setInterpolator(new OvershootInterpolator(1.4f)).start();
        if (Prefs.b("haptics")) performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        invalidate();
    }

    private void moveDrag(float x, float y) {
        drag.v.setTranslationX(x - grabX);
        drag.v.setTranslationY(y - grabY);
        long now = System.currentTimeMillis();
        if (now - lastSwap > 260) {
            float cx = x - grabX + drag.w / 2f, cy = y - grabY + drag.h / 2f;
            int cur = items.indexOf(drag), tgt = -1;
            for (int i = 0; i < items.size(); i++) {
                Item o = items.get(i);
                if (cx >= o.x && cx <= o.x + o.w && cy >= o.y && cy <= o.y + o.h) { tgt = i; break; }
            }
            if (tgt >= 0 && tgt != cur) {
                List<Item> n = new ArrayList<>(items);
                n.remove(cur);
                n.add(tgt, drag);
                int[][] out = new int[n.size()][];
                if (slots(n, out) <= usedH) {
                    items.clear();
                    items.addAll(n);
                    apply(out);
                    place(true);
                    lastSwap = now;
                    if (Prefs.b("haptics")) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                }
            }
        }
        invalidate();
    }

    private void endDrag(boolean notify) {
        if (drag == null) return;
        final Item it = drag;
        drag = null;
        it.v.animate().translationX(it.x).translationY(it.y).scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(U.ms(380)).setInterpolator(new OvershootInterpolator(0.9f)).start();
        if (editing && Prefs.b("anim_wiggle")) {
            ObjectAnimator a = ObjectAnimator.ofFloat(it.v, View.ROTATION, -0.5f, 0.5f);
            a.setDuration(U.ms(300));
            a.setRepeatCount(ValueAnimator.INFINITE);
            a.setRepeatMode(ValueAnimator.REVERSE);
            a.start();
            it.wig = a;
        }
        if (notify && listener != null) {
            List<String> ids = new ArrayList<>();
            for (Item o : items) ids.add(o.id);
            listener.onReorder(ids);
        }
        invalidate();
    }

    // ------------------------------------------------------------ badges

    @Override
    protected void dispatchDraw(Canvas c) {
        super.dispatchDraw(c);
        if (!editing) return;
        for (Item it : items) {
            float bx = it.v.getTranslationX() + 12 * d, by = it.v.getTranslationY() + 12 * d;
            bp.setStyle(Paint.Style.FILL);
            bp.setColor(0x33000000);
            c.drawCircle(bx, by + 1 * d, 11 * d, bp);
            bp.setColor(0xFF8E8E93);
            c.drawCircle(bx, by, 10 * d, bp);
            bp.setColor(0xFFFFFFFF);
            c.drawRoundRect(bx - 5 * d, by - 1.1f * d, bx + 5 * d, by + 1.1f * d, d, d, bp);
        }
    }
}
