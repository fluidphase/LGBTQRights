package com.convert.ipados;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/**
 * "Frosted glass" background: pastes the blurred wallpaper region that sits directly behind a view
 * (aligned in screen coordinates), then adds a tint and an optional hairline border.
 * {@code soft = true} uses a lighter blur so the wallpaper stays recognisable under a strong tint.
 */
final class Frost {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix m = new Matrix();
    private final RectF r = new RectF();
    private final int[] a = new int[2], b = new int[2];
    private final boolean soft;
    private BitmapShader sh;
    private Bitmap shBmp;

    Frost() { this(false); }

    Frost(boolean soft) {
        this.soft = soft;
        stroke.setStyle(Paint.Style.STROKE);
    }

    private Bitmap src() { return soft && Wall.soft != null ? Wall.soft : Wall.blur; }

    void draw(Canvas c, View v, View wall, float rad, int tintColor, int borderColor, float borderW) {
        r.set(0, 0, v.getWidth(), v.getHeight());
        Bitmap src = src();
        if (src != null && wall != null && wall.getWidth() > 0) {
            if (sh == null || shBmp != src) {
                shBmp = src;
                sh = new BitmapShader(shBmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            }
            v.getLocationOnScreen(a);
            wall.getLocationOnScreen(b);
            m.reset();
            m.setScale(wall.getWidth() / (float) shBmp.getWidth(), wall.getHeight() / (float) shBmp.getHeight());
            m.postTranslate(b[0] - a[0], b[1] - a[1]);
            sh.setLocalMatrix(m);
            fill.setShader(sh);
            c.drawRoundRect(r, rad, rad, fill);
            fill.setShader(null);
        }
        tint.setColor(tintColor);
        c.drawRoundRect(r, rad, rad, tint);
        if (borderW > 0f && (borderColor >>> 24) != 0) {
            stroke.setStrokeWidth(borderW);
            stroke.setColor(borderColor);
            r.inset(borderW / 2f, borderW / 2f);
            c.drawRoundRect(r, rad, rad, stroke);
        }
    }

    // ---- drop shadow that only appears OUTSIDE the panel
    // (a normal view elevation also darkens the inside of a translucent panel, which muddies the blur)
    private static final Paint SH = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Path SP = new Path();
    private static final RectF SR = new RectF();

    /** Call from the PARENT's onDraw, before the child is drawn. */
    static void shadow(Canvas c, View v, float rad, float blur, float dy, int color) {
        if (v.getVisibility() != View.VISIBLE || v.getWidth() == 0) return;
        float sx = v.getScaleX(), sy = v.getScaleY();
        float l = v.getLeft() + v.getTranslationX() + v.getPivotX() * (1f - sx);
        float t = v.getTop() + v.getTranslationY() + v.getPivotY() * (1f - sy);
        SR.set(l, t, l + v.getWidth() * sx, t + v.getHeight() * sy);
        int al = Math.round(Color.alpha(color) * Math.max(0f, Math.min(1f, v.getAlpha())));
        if (al <= 0) return;
        SP.reset();
        SP.addRoundRect(SR, rad * sx, rad * sy, Path.Direction.CW);
        c.save();
        c.clipOutPath(SP);
        SH.setColor(0xFF000000);
        SH.setShadowLayer(blur, 0f, dy, (al << 24) | (color & 0x00FFFFFF));
        c.drawRoundRect(SR, rad * sx, rad * sy, SH);
        c.restore();
    }
}
