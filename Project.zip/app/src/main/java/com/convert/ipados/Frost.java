package com.convert.ipados;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/**
 * "Frosted glass" background: pastes the blurred wallpaper region that sits directly behind a view
 * (aligned in screen coordinates), then adds a tint and an optional hairline border.
 * Call {@link #draw} from the view's onDraw.
 */
final class Frost {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix m = new Matrix();
    private final RectF r = new RectF();
    private final int[] a = new int[2], b = new int[2];
    private BitmapShader sh;
    private Bitmap shBmp;

    Frost() { stroke.setStyle(Paint.Style.STROKE); }

    void draw(Canvas c, View v, View wall, float rad, int tintColor, int borderColor, float borderW) {
        r.set(0, 0, v.getWidth(), v.getHeight());
        if (Wall.blur != null && wall != null && wall.getWidth() > 0) {
            if (sh == null || shBmp != Wall.blur) {
                shBmp = Wall.blur;
                sh = new BitmapShader(shBmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            }
            v.getLocationOnScreen(a);
            wall.getLocationOnScreen(b);
            m.reset();
            m.setScale(wall.getWidth() / (float) shBmp.getWidth(), wall.getHeight() / (float) shBmp.getHeight());
            m.postTranslate(b[0] - a[0], b[1] - a[1]);
            sh.setLocalMatrix(m);
            fill.setShader(sh);
            c.drawRoundRect(r, rad, rad, fill);
            fill.setShader(null);
        }
        tint.setColor(tintColor);
        c.drawRoundRect(r, rad, rad, tint);
        if (borderW > 0f && (borderColor >>> 24) != 0) {
            stroke.setStrokeWidth(borderW);
            stroke.setColor(borderColor);
            r.inset(borderW / 2f, borderW / 2f);
            c.drawRoundRect(r, rad, rad, stroke);
        }
    }
}
