package com.convert.ipados;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * iPadOS 16 style context menu: the screen blurs, the pressed icon / widget lifts up, and a frosted
 * card with title + icon rows pops out of it. Thick bands separate groups, destructive rows are red.
 */
class ContextMenuView extends FrameLayout {
    static final class Item {
        final String title;
        final int icon;
        final boolean danger;
        final Runnable action;
        Drawable iconDrawable;
        boolean gap;

        Item(String title, int icon, boolean danger, Runnable action) {
            this.title = title;
            this.icon = icon;
            this.danger = danger;
            this.action = action;
        }

        /** Start a new group (thick separator) above this row. */
        Item gap() { gap = true; return this; }
    }

    private static final float LIFT = 1.08f;

    private final View wall;
    private final Frost frost = new Frost();
    private final Panel panel;
    private final ImageView lifted;
    private final Paint bgp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint scrim = new Paint();
    private final Matrix m = new Matrix();
    private BitmapShader sh;
    private Bitmap shBmp;
    private ValueAnimator anim;
    private float t;
    private boolean open;
    private boolean hasLift;

    private class Panel extends LinearLayout {
        Panel(Context c) {
            super(c);
            setOrientation(VERTICAL);
            setWillNotDraw(false);
            setClickable(true);
            final float rad = U.dp(c, 14);
            setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rad);
                    o.setAlpha(0.9f);
                }
            });
            setClipToOutline(true);
            setElevation(U.dp(c, 18));
        }

        @Override
        protected void onDraw(Canvas c) {
            frost.draw(c, this, wall, U.dp(getContext(), 14), 0xDCF4F4F7, 0, 0f);
        }
    }

    ContextMenuView(Context c, View wall) {
        super(c);
        this.wall = wall;
        setWillNotDraw(false);
        setVisibility(GONE);
        setClickable(true);
        setOnClickListener(v -> dismiss());
        setClipChildren(false);
        lifted = new ImageView(c);
        lifted.setScaleType(ImageView.ScaleType.FIT_XY);
        lifted.setVisibility(GONE);
        addView(lifted, new FrameLayout.LayoutParams(1, 1, Gravity.TOP | Gravity.START));
        panel = new Panel(c);
        addView(panel, new FrameLayout.LayoutParams(U.dpi(c, 270), -2, Gravity.TOP | Gravity.START));
    }

    boolean isOpen() { return open; }

    // ------------------------------------------------------------ building rows

    private View row(final Item it) {
        Context c = getContext();
        int col = it.danger ? 0xFFFF3B30 : 0xFF000000;
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(U.dpi(c, 16), 0, U.dpi(c, 16), 0);
        r.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22000000), null, new ColorDrawable(Color.BLACK)));
        TextView tv = new TextView(c);
        tv.setText(it.title);
        tv.setTextColor(col);
        tv.setTextSize(17);
        tv.setSingleLine(true);
        tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        r.addView(tv, new LinearLayout.LayoutParams(0, -2, 1f));
        if (it.iconDrawable != null || it.icon != 0) {
            ImageView iv = new ImageView(c);
            if (it.iconDrawable != null) {
                iv.setImageDrawable(it.iconDrawable);
            } else {
                iv.setImageResource(it.icon);
                iv.setColorFilter(col);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(U.dpi(c, 22), U.dpi(c, 22));
            lp.leftMargin = U.dpi(c, 12);
            r.addView(iv, lp);
        }
        r.setOnClickListener(v -> dismissThen(it.action));
        return r;
    }

    private void build(List<Item> items) {
        Context c = getContext();
        panel.removeAllViews();
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            if (i > 0) {
                View sep = new View(c);
                if (it.gap) {
                    sep.setBackgroundColor(0x2E7C7C84);
                    panel.addView(sep, new LinearLayout.LayoutParams(-1, U.dpi(c, 8)));
                } else {
                    sep.setBackgroundColor(0x22000000);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 1);
                    lp.leftMargin = U.dpi(c, 16);
                    panel.addView(sep, lp);
                }
            }
            panel.addView(row(it), new LinearLayout.LayoutParams(-1, U.dpi(c, 46)));
        }
    }

    // ------------------------------------------------------------ show / dismiss

    /**
     * @param anchor  screen rectangle of the pressed icon / widget (or a tiny rect at the touch point)
     * @param preview picture of the pressed object to lift above the blur, or null
     */
    void show(RectF anchor, Bitmap preview, List<Item> items) {
        if (items == null || items.isEmpty() || !(getParent() instanceof View)) return;
        Context c = getContext();
        View par = (View) getParent();
        float W = par.getWidth(), H = par.getHeight();
        int[] loc = new int[2];
        par.getLocationOnScreen(loc);
        RectF a = new RectF(anchor);
        a.offset(-loc[0], -loc[1]);

        build(items);
        float margin = U.dp(c, 14);
        int pw = Math.round(Math.min(U.dp(c, 270), W - 2 * margin));
        panel.getLayoutParams().width = pw;
        panel.measure(MeasureSpec.makeMeasureSpec(pw, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
        int ph = panel.getMeasuredHeight();
        panel.getLayoutParams().height = ph;

        hasLift = preview != null;
        float extra = hasLift ? a.height() * (LIFT - 1f) / 2f : 0f;
        float gap = U.dp(c, 10);
        float topSafe = margin + U.dp(c, 24), botSafe = H - margin - U.dp(c, 8);
        boolean below = a.bottom + extra + gap + ph <= botSafe;
        if (!below && a.top - extra - gap - ph < topSafe) {
            // no room on either side: use whichever has more space
            below = (H - a.bottom) >= a.top;
        }
        float y = below ? a.bottom + extra + gap : a.top - extra - gap - ph;
        y = U.clamp(y, topSafe, Math.max(topSafe, botSafe - ph));
        float x = a.centerX() < W / 2f ? a.left : a.right - pw;
        x = U.clamp(x, margin, Math.max(margin, W - pw - margin));
        panel.setTranslationX(x);
        panel.setTranslationY(y);
        panel.setPivotX(U.clamp(a.centerX() - x, 0f, pw));
        panel.setPivotY(below ? 0f : ph);

        if (hasLift) {
            lifted.setImageBitmap(preview);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) lifted.getLayoutParams();
            lp.width = Math.max(1, Math.round(a.width()));
            lp.height = Math.max(1, Math.round(a.height()));
            lifted.setLayoutParams(lp);
            lifted.setTranslationX(a.left);
            lifted.setTranslationY(a.top);
            lifted.setPivotX(a.width() / 2f);
            lifted.setPivotY(a.height() / 2f);
            lifted.setVisibility(VISIBLE);
        } else {
            lifted.setVisibility(GONE);
        }

        open = true;
        if (anim != null) anim.cancel();
        setVisibility(VISIBLE);
        apply(0f);
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(340);
        anim.setInterpolator(new PathInterpolator(0.2f, 1.2f, 0.4f, 1f));
        anim.addUpdateListener(an -> apply((Float) an.getAnimatedValue()));
        anim.start();
    }

    void dismiss() { dismissThen(null); }

    void dismissThen(final Runnable after) {
        if (!open) {
            if (after != null) after.run();
            return;
        }
        open = false;
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(Math.min(t, 1f), 0f);
        anim.setDuration(180);
        anim.setInterpolator(new DecelerateInterpolator(1.3f));
        anim.addUpdateListener(an -> apply((Float) an.getAnimatedValue()));
        anim.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;
            @Override public void onAnimationCancel(Animator a) { cancelled = true; }
            @Override public void onAnimationEnd(Animator a) {
                if (cancelled) return;
                if (!open) setVisibility(GONE);
                if (after != null) after.run();
            }
        });
        anim.start();
    }

    private void apply(float p) {
        t = p;
        panel.setAlpha(U.clamp(p * 1.8f, 0f, 1f));
        float s = U.lerp(0.45f, 1f, p);
        panel.setScaleX(s);
        panel.setScaleY(s);
        if (hasLift) {
            float ls = 1f + (LIFT - 1f) * p;
            lifted.setScaleX(ls);
            lifted.setScaleY(ls);
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float a = U.clamp(t, 0f, 1f);
        if (a <= 0f) return;
        if (Wall.blur != null) {
            if (sh == null || shBmp != Wall.blur) {
                shBmp = Wall.blur;
                sh = new BitmapShader(shBmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            }
            m.reset();
            m.setScale(getWidth() / (float) shBmp.getWidth(), getHeight() / (float) shBmp.getHeight());
            sh.setLocalMatrix(m);
            bgp.setShader(sh);
            bgp.setAlpha(Math.round(225 * a));
            c.drawRect(0, 0, getWidth(), getHeight(), bgp);
        }
        scrim.setColor(Math.round(80 * a) << 24);
        c.drawRect(0, 0, getWidth(), getHeight(), scrim);
    }
}
