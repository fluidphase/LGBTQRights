package com.convert.ipados;

import android.content.Context;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** The widgets that exist, their icons / names, and the user's chosen order. */
final class WidgetCatalog {
    static final String[] IDS = {"clock", "calendar", "weather", "shortcuts", "notes"};

    static String pref(String id) { return "w_" + id; }

    static String title(String id) {
        switch (id) {
            case "clock": return "Clock";
            case "calendar": return "Calendar";
            case "weather": return "Weather";
            case "shortcuts": return "Siri Suggestions";
            default: return "Notes";
        }
    }

    static int icon(String id) {
        switch (id) {
            case "clock": return R.drawable.ic_clock;
            case "calendar": return R.drawable.ic_calendar;
            case "weather": return R.drawable.ic_sun;
            case "shortcuts": return R.drawable.ic_bolt;
            default: return R.drawable.ic_note;
        }
    }

    /** Wide widgets take two columns when there is room. */
    static boolean wide(String id) { return id.equals("calendar") || id.equals("shortcuts"); }

    static View create(Context c, String id) {
        switch (id) {
            case "clock": return new ClockWidget(c);
            case "calendar": return new CalendarWidget(c);
            case "weather": return new WeatherWidget(c);
            case "shortcuts": return new ShortcutsWidget(c);
            default: return new NotesWidget(c);
        }
    }

    /** Saved order, with any unknown / missing ids repaired. */
    static List<String> order() {
        List<String> out = new ArrayList<>();
        for (String s : Prefs.list("w_order")) {
            for (String id : IDS) if (id.equals(s) && !out.contains(id)) out.add(id);
        }
        for (String id : IDS) if (!out.contains(id)) out.add(id);
        return out;
    }
}
