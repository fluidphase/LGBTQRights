package com.convert.ipados;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityOptions;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.LauncherApps;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ShortcutInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

public class LauncherActivity extends Activity {
    private FrameLayout root, content;
    private WallpaperView wallView;
    private Pager pager;
    private DotsView dots;
    private DockView dock;
    private SpotlightView spot;
    private ContextMenuView menu;
    private LaunchOverlay overlay;
    private TextView doneBtn;
    private ImageView addBtn;
    private WidgetGrid widgetGrid;
    private FolderView folderView;

    /** One icon on the home board: a layout entry (app or folder) and its view. */
    private static final class Cell {
        final HomeLayout.Entry e;
        final AppIconView v;
        Cell(HomeLayout.Entry e, AppIconView v) { this.e = e; this.v = v; }
    }
    private final List<Cell> cells = new ArrayList<>();
    private FrameLayout board;
    private int gPw = 1, gPh = 1, gSide, gCols = 4, gIp, gCellW = 1, gCellH = 1, gTop, gWidgetH, gRows0 = 1, gRowsN = 1, pages = 1;
    private Cell dragCell, mergeCell, hoverCell;
    private ImageView ghost;
    private float ghostDx, ghostDy, ghostOx, ghostOy, lastRawX, lastRawY;
    private long hoverSince, lastSwap;
    private int edgeDir;
    private final AppIconView.DragHost dragHost = new AppIconView.DragHost() {
        @Override public void dragStart(AppIconView v, float rx, float ry) { LauncherActivity.this.dragStart(v, rx, ry); }
        @Override public void dragMove(float rx, float ry) { LauncherActivity.this.dragMove(rx, ry); }
        @Override public void dragEnd(boolean cancelled) { LauncherActivity.this.dragEnd(cancelled); }
    };
    private final Set<String> droppedWidgets = new HashSet<>();

    private List<AppInfo> allApps = new ArrayList<>();
    private int rev = -1, insetT, insetB;
    private int state; // 0 = home, 1 = an app is open (overlay covers the screen)
    private boolean editing, loading, reloadAgain;
    private float downX, downY;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Runnable pendingStart;
    private ValueAnimator anim;
    private BroadcastReceiver pkgReceiver;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.init(this);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        wallView = new WallpaperView(this);
        root.addView(wallView, new FrameLayout.LayoutParams(-1, -1));

        content = new FrameLayout(this);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        pager = new Pager(this);
        content.addView(pager, new FrameLayout.LayoutParams(-1, -1));
        dots = new DotsView(this);
        content.addView(dots, new FrameLayout.LayoutParams(-1, U.dpi(this, 20), Gravity.BOTTOM));
        dock = new DockView(this, wallView);
        content.addView(dock, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL));

        doneBtn = new TextView(this);
        doneBtn.setText("Done");
        doneBtn.setTextColor(Color.WHITE);
        doneBtn.setTypeface(Typeface.DEFAULT_BOLD);
        doneBtn.setTextSize(16);
        int pp = U.dpi(this, 16);
        doneBtn.setPadding(pp, U.dpi(this, 8), pp, U.dpi(this, 8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x66000000);
        g.setCornerRadius(U.dp(this, 20));
        doneBtn.setBackground(g);
        doneBtn.setVisibility(View.GONE);
        doneBtn.setOnClickListener(v -> setEditing(false));
        content.addView(doneBtn, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));

        addBtn = new ImageView(this);
        addBtn.setImageResource(R.drawable.ic_plus);
        addBtn.setColorFilter(Color.WHITE);
        int ap = U.dpi(this, 9);
        addBtn.setPadding(ap, ap, ap, ap);
        GradientDrawable ag = new GradientDrawable();
        ag.setShape(GradientDrawable.OVAL);
        ag.setColor(0x66000000);
        addBtn.setBackground(ag);
        addBtn.setVisibility(View.GONE);
        addBtn.setOnClickListener(v -> showWidgetGallery(addBtn));
        content.addView(addBtn, new FrameLayout.LayoutParams(U.dpi(this, 38), U.dpi(this, 38), Gravity.TOP | Gravity.START));

        spot = new SpotlightView(this, wallView, new SpotlightView.Callback() {
            @Override public void open(AppInfo a, RectF from) {
                spot.hide();
                launch(a, from);
            }
            @Override public void web(String q) {
                spot.hide();
                try {
                    startActivity(new Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e2) {
                        Toast.makeText(LauncherActivity.this, "No browser found", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override public void close() { spot.hide(); }
        });
        root.addView(spot, new FrameLayout.LayoutParams(-1, -1));

        folderView = new FolderView(this, wallView, new FolderView.Callback() {
            @Override public void launch(AppInfo a, RectF from) {
                folderView.closeNow();
                LauncherActivity.this.launch(a, from);
            }
            @Override public void appMenu(AppInfo a, View icon) {
                String fid = null;
                for (Cell c : cells) if (c.e.folder && c.e.keys.contains(a.key())) fid = c.e.id;
                showAppMenu(a, icon, fid);
            }
            @Override public void renamed(String id, String name) {
                List<HomeLayout.Entry> l = entriesFromCells();
                for (HomeLayout.Entry e : l) if (e.folder && e.id.equals(id)) e.name = name;
                HomeLayout.save(l);
                rebuildPages();
            }
        });
        root.addView(folderView, new FrameLayout.LayoutParams(-1, -1));

        menu = new ContextMenuView(this, wallView);
        root.addView(menu, new FrameLayout.LayoutParams(-1, -1));

        overlay = new LaunchOverlay(this);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        root.setOnApplyWindowInsetsListener((v, ins) -> {
            insetT = ins.getSystemWindowInsetTop();
            insetB = ins.getSystemWindowInsetBottom();
            applyLayout();
            return ins;
        });
        pager.listener = pos -> dots.setPos(pos);
        pager.addOnLayoutChangeListener((v, l, t, r, bt, oldL, oldT, oldR, oldB) -> {
            if (r - l != oldR - oldL || bt - t != oldB - oldT) rebuildPages();
        });

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        pkgReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) { reloadAll(); }
        };
        registerReceiver(pkgReceiver, f);
        applySystemUi();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pkgReceiver != null) unregisterReceiver(pkgReceiver);
    }

    private void applySystemUi() {
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (Prefs.b("status_dark")) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        root.setSystemUiVisibility(f);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Prefs.init(this);
        applySystemUi();
        boolean wasOpen = state != 0;
        if (wasOpen) closeAnim();
        if (rev != Prefs.i("rev")) {
            rev = Prefs.i("rev");
            applyLayout();
            reloadAll();
        } else if (wasOpen) {
            rebuildDock();
            updateSpot();
        }
        if (!Prefs.b("asked_perm") && Prefs.i("wall_src") == 0 && !Wall.hasStoragePermission(this)) {
            Prefs.setQuiet("asked_perm", true);
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 7);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        Prefs.set("wall_src", Prefs.i("wall_src")); // bump revision => wallpaper reloads in onResume
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        reloadAll();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        menu.dismiss();
        folderView.close();
        if (spot.isShowing()) spot.hide();
        if (editing) setEditing(false);
        pager.goTo(0, true);
    }

    @Override
    public void onBackPressed() {
        if (menu.isOpen()) menu.dismiss();
        else if (folderView.isOpen()) folderView.close();
        else if (spot.isShowing()) spot.hide();
        else if (editing) setEditing(false);
        else pager.goTo(0, true);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            downX = e.getX();
            downY = e.getY();
        } else if (a == MotionEvent.ACTION_UP && Prefs.b("search_on") && !editing && state == 0
                && !spot.isShowing() && !menu.isOpen() && !folderView.isOpen()) {
            float dy = e.getY() - downY, dx = e.getX() - downX;
            if (dy > U.dp(this, 110) && Math.abs(dx) < dy * 0.6f && downY < root.getHeight() * 0.75f) spot.show();
        }
        return super.dispatchTouchEvent(e);
    }

    // ---------------------------------------------------------------- layout

    private void applyLayout() {
        boolean showDock = Prefs.b("dock_show");
        int dockH = showDock ? U.dpi(this, Prefs.i("dock_size")) + U.dpi(this, 18) : 0;
        int dockBottom = insetB + U.dpi(this, Prefs.i("dock_margin"));
        FrameLayout.LayoutParams dl = (FrameLayout.LayoutParams) dock.getLayoutParams();
        dl.bottomMargin = dockBottom;
        dock.setLayoutParams(dl);
        int dotsBottom = showDock ? dockBottom + dockH + U.dpi(this, 4) : insetB + U.dpi(this, 8);
        FrameLayout.LayoutParams ol = (FrameLayout.LayoutParams) dots.getLayoutParams();
        ol.bottomMargin = dotsBottom;
        dots.setLayoutParams(ol);
        dots.setVisibility(Prefs.b("page_dots") ? View.VISIBLE : View.INVISIBLE);
        FrameLayout.LayoutParams pl = (FrameLayout.LayoutParams) pager.getLayoutParams();
        pl.topMargin = insetT + U.dpi(this, 6);
        pl.bottomMargin = dotsBottom + U.dpi(this, 24);
        pager.setLayoutParams(pl);
        FrameLayout.LayoutParams bl = (FrameLayout.LayoutParams) doneBtn.getLayoutParams();
        bl.topMargin = insetT + U.dpi(this, 8);
        bl.rightMargin = U.dpi(this, 16);
        doneBtn.setLayoutParams(bl);
        FrameLayout.LayoutParams al = (FrameLayout.LayoutParams) addBtn.getLayoutParams();
        al.topMargin = insetT + U.dpi(this, 6);
        al.leftMargin = U.dpi(this, 16);
        addBtn.setLayoutParams(al);
        spot.setTopInset(insetT);
    }

    private void reloadAll() {
        if (loading) { reloadAgain = true; return; }
        loading = true;
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        final int sw = dm.widthPixels, sh = dm.heightPixels;
        final int ip = U.dpi(this, Prefs.i("icon_size")), dk = U.dpi(this, Prefs.i("dock_size")), sp = U.dpi(this, 44), sg = U.dpi(this, 52);
        new Thread(() -> {
            List<AppInfo> l = new ArrayList<>();
            try {
                Icons.configure(this);
                l = Apps.load(this);
                Wall.load(this, sw, sh);
                for (AppInfo a : l) {
                    Icons.get(this, a, ip);
                    Icons.get(this, a, dk);
                    Icons.get(this, a, sp);
                    Icons.get(this, a, sg);
                }
            } catch (Throwable ignored) { }
            final List<AppInfo> res = l;
            runOnUiThread(() -> {
                loading = false;
                allApps = res;
                wallView.invalidate();
                dock.invalidate();
                ensureDockDefaults();
                rebuildPages();
                rebuildDock();
                updateSpot();
                if (reloadAgain) { reloadAgain = false; reloadAll(); }
            });
        }).start();
    }

    private List<AppInfo> visibleApps() {
        Set<String> hid = new HashSet<>(Prefs.list("hidden"));
        List<AppInfo> o = new ArrayList<>();
        for (AppInfo a : allApps) if (!hid.contains(a.key())) o.add(a);
        return o;
    }

    private void updateSpot() {
        Map<String, AppInfo> m = new HashMap<>();
        List<AppInfo> vis = visibleApps();
        for (AppInfo a : vis) m.put(a.key(), a);
        List<AppInfo> rec = new ArrayList<>();
        for (String k : Prefs.list("recents")) {
            AppInfo a = m.get(k);
            if (a != null && rec.size() < 5) rec.add(a);
        }
        spot.setApps(vis, rec);
    }

    private void rebuildPages() {
        int pw = pager.getWidth(), ph = pager.getHeight();
        if (pw <= 0 || ph <= 0) return;
        cancelDrag();
        float dn = getResources().getDisplayMetrics().density;
        int side = U.dpi(this, Prefs.i("side_margin"));
        int cols = Prefs.i("cols");
        if (cols <= 0) cols = Math.max(4, Math.min(7, Math.round(pw / dn / 120f)));
        int ip = U.dpi(this, Prefs.i("icon_size"));
        boolean lab = Prefs.b("show_labels");
        int cellH = ip + (lab ? AppIconView.labelHeight(this) : 0) + U.dpi(this, Prefs.i("icon_gapv"));
        int cellW = Math.max(1, (pw - 2 * side) / cols);
        int topPad = U.dpi(this, 8);
        int[] wh = new int[1];
        droppedWidgets.clear();
        WidgetGrid wc = Prefs.b("w_show") ? buildWidgets(pw - 2 * side, ph, wh) : null;
        widgetGrid = wc;
        int widgetH = wc == null ? 0 : wh[0] + U.dpi(this, 14);
        int rowsMax = Prefs.i("rows");
        int rows0 = Math.max(1, (ph - topPad - widgetH) / cellH), rowsN = Math.max(1, (ph - topPad) / cellH);
        if (rowsMax > 0) {
            rows0 = Math.min(rows0, rowsMax);
            rowsN = Math.min(rowsN, rowsMax);
        }
        gPw = pw; gPh = ph; gSide = side; gCols = cols; gIp = ip; gCellW = cellW; gCellH = cellH;
        gTop = topPad; gWidgetH = widgetH; gRows0 = rows0; gRowsN = rowsN;

        int keep = pager.page();
        pager.strip.removeAllViews();
        cells.clear();
        board = new FrameLayout(this);
        board.setClipChildren(false);
        board.setOnLongClickListener(b -> { showHomeMenu(); return true; });
        if (wc != null) {
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(pw - 2 * side, wh[0]);
            lp.leftMargin = side;
            lp.topMargin = topPad;
            board.addView(wc, lp);
        }
        Map<String, AppInfo> map = appMap();
        for (HomeLayout.Entry e : HomeLayout.reconcile(visibleApps())) {
            AppInfo ai;
            Bitmap bmp;
            if (e.folder) {
                ai = new AppInfo();
                ai.folderId = e.id;
                ai.label = e.name;
                ai.folderKeys = new ArrayList<>(e.keys);
                List<Bitmap> minis = new ArrayList<>();
                for (String k : e.keys) {
                    AppInfo m = map.get(k);
                    if (m != null && minis.size() < 9) minis.add(Icons.get(this, m, ip));
                }
                bmp = FolderIcons.render(minis, ip);
            } else {
                ai = map.get(e.id);
                if (ai == null) continue;
                bmp = Icons.get(this, ai, ip);
            }
            AppIconView v = makeIcon(ai, bmp, ip, lab, true);
            cells.add(new Cell(e, v));
            board.addView(v, new FrameLayout.LayoutParams(cellW, cellH));
        }
        pages = pageCount();
        pager.strip.addView(board, new LinearLayout.LayoutParams(pages * pw, ph));
        layoutCells(false);
        pager.setPages(pages, pw);
        dots.setCount(pages);
        final int cur = Math.min(keep, pages - 1);
        pager.post(() -> { pager.goTo(cur, false); dots.setPos(cur); });
        if (editing) setEditing(true);
    }

    private WidgetGrid buildWidgets(int w, int ph, int[] outH) {
        float dn = getResources().getDisplayMetrics().density;
        int per = Prefs.i("w_perrow");
        if (per <= 0) per = w / dn >= 860 ? 4 : (w / dn >= 560 ? 3 : 2);
        int gap = U.dpi(this, 12);
        int card = (w - gap * (per - 1)) / per;
        WidgetGrid grid = new WidgetGrid(this, per, card, gap, (int) (ph * 0.46f));
        for (String id : WidgetCatalog.order()) {
            if (!Prefs.b(WidgetCatalog.pref(id))) continue;
            int span = WidgetCatalog.wide(id) && per >= 3 ? 2 : 1;
            if (!grid.add(id, WidgetCatalog.create(this, id), span)) droppedWidgets.add(id);
        }
        if (grid.count() == 0) return null;
        grid.listener = new WidgetGrid.Listener() {
            @Override public void onReorder(List<String> ids) {
                List<String> all = new ArrayList<>(ids);
                for (String id : WidgetCatalog.order()) if (!all.contains(id)) all.add(id);
                Prefs.setList("w_order", all, true);
            }
            @Override public void onRemove(String id) { removeWidget(id); }
            @Override public void onMenu(String id, View v) { showWidgetMenu(id, v); }
        };
        outH[0] = grid.usedHeight();
        return grid;
    }

    private AppIconView makeIcon(AppInfo a, int px, boolean lab) {
        return makeIcon(a, Icons.get(this, a, px), px, lab, false);
    }

    private AppIconView makeIcon(final AppInfo a, Bitmap bmp, int px, boolean lab, boolean draggable) {
        final AppIconView v = new AppIconView(this, a, bmp, px, lab);
        final boolean folder = a.folderId != null;
        v.setOnClickListener(x -> {
            if (folder) openFolder(a, v);
            else if (!editing) launch(a, v.iconRectOnScreen());
        });
        v.setOnLongClickListener(x -> {
            v.longFired = true; // lets a following finger move turn into a drag
            if (!editing) {
                if (folder) showFolderMenu(a, v);
                else showAppMenu(a, v, null);
            }
            return true;
        });
        v.onBadge = () -> { if (folder) dissolveFolder(a.folderId); else hideApp(a); };
        if (draggable) v.host = dragHost;
        return v;
    }

    // ---------------------------------------------------------------- dock

    private void ensureDockDefaults() {
        if (!Prefs.s("dock_apps").isEmpty() || allApps.isEmpty()) return;
        Intent[] ins = {
                new Intent(Intent.ACTION_DIAL),
                new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
                new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.example.com")),
                new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
                new Intent(Intent.ACTION_VIEW).setType("image/*"),
                new Intent(Settings.ACTION_SETTINGS)
        };
        List<String> out = new ArrayList<>();
        PackageManager pm = getPackageManager();
        for (Intent in : ins) {
            ResolveInfo ri = pm.resolveActivity(in, PackageManager.MATCH_DEFAULT_ONLY);
            if (ri == null || ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            for (AppInfo a : allApps) {
                if (a.cn.getPackageName().equals(pkg)) {
                    if (!out.contains(a.key())) out.add(a.key());
                    break;
                }
            }
        }
        Prefs.setList("dock_apps", out, true);
    }

    private void rebuildDock() {
        dock.removeAllViews();
        boolean show = Prefs.b("dock_show");
        if (!show) { dock.setVisibility(View.GONE); return; }
        Map<String, AppInfo> m = new HashMap<>();
        for (AppInfo a : allApps) m.put(a.key(), a);
        int px = U.dpi(this, Prefs.i("dock_size")), gap = U.dpi(this, 7), pad = U.dpi(this, 9);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int fit = Math.max(1, (dm.widthPixels - U.dpi(this, 32) - 2 * pad) / (px + 2 * gap));
        List<AppInfo> favs = new ArrayList<>(), rec = new ArrayList<>();
        for (String k : Prefs.list("dock_apps")) {
            AppInfo a = m.get(k);
            if (a != null && favs.size() < Math.min(Prefs.i("dock_max"), fit)) favs.add(a);
        }
        if (Prefs.b("dock_recents")) {
            for (String k : Prefs.list("recents")) {
                AppInfo a = m.get(k);
                if (a != null && !favs.contains(a) && rec.size() < Prefs.i("dock_recent_count")
                        && favs.size() + rec.size() < fit) rec.add(a);
            }
        }
        if (favs.isEmpty() && rec.isEmpty()) { dock.setVisibility(View.GONE); return; }
        dock.setVisibility(View.VISIBLE);
        dock.setPadding(pad, pad, pad, pad);
        for (AppInfo a : favs) addDockIcon(a, px, gap);
        if (!favs.isEmpty() && !rec.isEmpty()) {
            View div = new View(this);
            div.setBackgroundColor(0x55FFFFFF);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(U.dpi(this, 1), (int) (px * 0.8f));
            lp.leftMargin = gap;
            lp.rightMargin = gap;
            dock.addView(div, lp);
        }
        for (AppInfo a : rec) addDockIcon(a, px, gap);
        if (editing) forEachIcon(dock, v -> v.setEditing(true));
        dock.invalidate();
    }

    private void addDockIcon(AppInfo a, int px, int gap) {
        AppIconView v = makeIcon(a, px, false);
        dock.addView(v, new LinearLayout.LayoutParams(px + 2 * gap, px));
    }

    private void toggleDock(AppInfo a) {
        List<String> l = Prefs.list("dock_apps");
        if (!l.remove(a.key())) l.add(a.key());
        Prefs.setList("dock_apps", l, true);
        rebuildDock();
    }

    private void pushRecent(AppInfo a) {
        List<String> l = Prefs.list("recents");
        l.remove(a.key());
        l.add(0, a.key());
        while (l.size() > 12) l.remove(l.size() - 1);
        Prefs.setList("recents", l, true);
    }

    // ---------------------------------------------------------------- menus / edit mode

    private void forEachIcon(View v, Consumer<AppIconView> c) {
        if (v instanceof AppIconView) {
            c.accept((AppIconView) v);
        } else if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) forEachIcon(g.getChildAt(i), c);
        }
    }

    private void setEditing(final boolean on) {
        boolean changed = editing != on;
        editing = on;
        if (changed) {
            fade(doneBtn, on);
            fade(addBtn, on);
            if (on) tick();
        }
        forEachIcon(pager.strip, v -> v.setEditing(on));
        forEachIcon(dock, v -> v.setEditing(on));
        if (widgetGrid != null) widgetGrid.setEditing(on);
    }

    /** Pop the Done / + pills in and out with a little spring. */
    private void fade(final View v, final boolean show) {
        v.animate().cancel();
        if (show) {
            v.setVisibility(View.VISIBLE);
            v.setAlpha(0f);
            v.setScaleX(0.8f);
            v.setScaleY(0.8f);
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(280)
                    .setInterpolator(new OvershootInterpolator(1.8f)).start();
        } else {
            v.animate().alpha(0f).setDuration(150).withEndAction(() -> { if (!editing) v.setVisibility(View.GONE); }).start();
        }
    }

    private void tick() {
        if (Prefs.b("haptics")) root.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
    }

    private RectF rectOf(View v) {
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        return new RectF(l[0], l[1], l[0] + v.getWidth(), l[1] + v.getHeight());
    }

    private RectF touchRect() {
        float r = U.dp(this, 2);
        return new RectF(downX - r, downY - r, downX + r, downY + r);
    }

    private void safeStart(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Not available", Toast.LENGTH_SHORT).show();
        }
    }

    private void openSettings(String page) {
        Intent i = new Intent(this, SettingsActivity.class);
        if (page != null) i.putExtra("page", page);
        startActivity(i);
    }

    private void hideApp(AppInfo a) {
        List<String> l = Prefs.list("hidden");
        if (!l.contains(a.key())) l.add(a.key());
        Prefs.setList("hidden", l, false);
        rev = Prefs.i("rev"); // we rebuild by hand, no need for a full reload
        rebuildPages();
        rebuildDock();
        updateSpot();
    }

    // ---- app menu (iPadOS 16 style long-press menu)

    /** Quick actions the app publishes (needs the launcher to be the default home app). */
    private List<ContextMenuView.Item> shortcutItems(final AppInfo a) {
        List<ContextMenuView.Item> out = new ArrayList<>();
        try {
            final LauncherApps la = (LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE);
            if (la == null || !la.hasShortcutHostPermission()) return out;
            LauncherApps.ShortcutQuery q = new LauncherApps.ShortcutQuery();
            q.setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC
                    | LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST
                    | LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED);
            q.setPackage(a.cn.getPackageName());
            q.setActivity(a.cn);
            List<ShortcutInfo> l = la.getShortcuts(q, Process.myUserHandle());
            if (l == null) return out;
            int dpi = getResources().getDisplayMetrics().densityDpi;
            for (final ShortcutInfo si : l) {
                if (out.size() >= 4) break;
                CharSequence lbl = si.getShortLabel();
                if (lbl == null || !si.isEnabled()) continue;
                ContextMenuView.Item it = new ContextMenuView.Item(String.valueOf(lbl), 0, false, () -> {
                    try {
                        la.startShortcut(si, null, null);
                    } catch (Exception e) {
                        Toast.makeText(LauncherActivity.this, "Not available", Toast.LENGTH_SHORT).show();
                    }
                });
                it.iconDrawable = la.getShortcutIconDrawable(si, dpi);
                out.add(it);
            }
        } catch (Throwable ignored) { }
        return out;
    }

    private void showAppMenu(final AppInfo a, View anchor, final String folderId) {
        tick();
        final Uri pkg = Uri.parse("package:" + a.cn.getPackageName());
        boolean inDock = Prefs.list("dock_apps").contains(a.key());
        List<ContextMenuView.Item> its = shortcutItems(a);
        boolean hadShortcuts = !its.isEmpty();
        if (folderId != null) {
            ContextMenuView.Item rf = new ContextMenuView.Item("Remove from Folder", R.drawable.ic_folder, false,
                    () -> removeFromFolder(folderId, a));
            if (hadShortcuts) rf.gap();
            its.add(rf);
        }
        ContextMenuView.Item first = new ContextMenuView.Item(inDock ? "Remove from Dock" : "Add to Dock",
                inDock ? R.drawable.ic_dock_remove : R.drawable.ic_dock_add, false, () -> toggleDock(a));
        if (hadShortcuts && folderId == null) first.gap();
        its.add(first);
        its.add(new ContextMenuView.Item("App Info", R.drawable.ic_info, false,
                () -> safeStart(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))));
        its.add(new ContextMenuView.Item("Share App", R.drawable.ic_share, false, () -> {
            Intent s = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,
                    "https://play.google.com/store/apps/details?id=" + a.cn.getPackageName());
            safeStart(Intent.createChooser(s, null));
        }));
        its.add(new ContextMenuView.Item("Hide App", R.drawable.ic_hide, false, () -> hideApp(a)));
        its.add(new ContextMenuView.Item("Edit Home Screen", R.drawable.ic_edit_home, false, () -> setEditing(true)).gap());
        its.add(new ContextMenuView.Item("Remove App", R.drawable.ic_remove, true,
                () -> safeStart(new Intent(Intent.ACTION_DELETE, pkg))));
        if (anchor instanceof AppIconView) {
            AppIconView iv = (AppIconView) anchor;
            menu.show(iv.iconRectOnScreen(), iv.icon, its);
        } else {
            menu.show(rectOf(anchor), U.snapshot(anchor), its);
        }
    }

    // ---- home screen / widget menus

    private void showHomeMenu() {
        if (editing || menu.isOpen()) return;
        tick();
        List<ContextMenuView.Item> its = new ArrayList<>();
        its.add(new ContextMenuView.Item("Edit Home Screen", R.drawable.ic_edit_home, false, () -> setEditing(true)));
        its.add(new ContextMenuView.Item("Add Widget", R.drawable.ic_widgets, false, () -> showWidgetGallery(null)));
        its.add(new ContextMenuView.Item("Wallpaper", R.drawable.ic_wallpaper, false, () -> openSettings("wallpaper")));
        its.add(new ContextMenuView.Item("Launcher Settings", R.drawable.ic_sliders, false, () -> openSettings(null)).gap());
        menu.show(touchRect(), null, its);
    }

    private void showWidgetMenu(final String id, View v) {
        if (editing || menu.isOpen()) return;
        tick();
        List<ContextMenuView.Item> its = new ArrayList<>();
        its.add(new ContextMenuView.Item("Edit Home Screen", R.drawable.ic_edit_home, false, () -> setEditing(true)));
        its.add(new ContextMenuView.Item("Remove Widget", R.drawable.ic_remove, true, () -> removeWidget(id)).gap());
        menu.show(rectOf(v), U.snapshot(v), its);
    }

    /** "+" button / "Add Widget": a menu listing the widgets that are currently off. */
    private void showWidgetGallery(View anchor) {
        List<ContextMenuView.Item> its = new ArrayList<>();
        if (!Prefs.b("w_show")) {
            its.add(new ContextMenuView.Item("Show Widgets", R.drawable.ic_widgets, false, () -> {
                Prefs.setQuiet("w_show", true);
                rebuildPages();
            }));
        }
        for (final String id : WidgetCatalog.IDS) {
            if (Prefs.b(WidgetCatalog.pref(id))) continue;
            its.add(new ContextMenuView.Item(WidgetCatalog.title(id), WidgetCatalog.icon(id), false, () -> addWidget(id)));
        }
        if (its.isEmpty()) {
            Toast.makeText(this, "All widgets are already on your home screen", Toast.LENGTH_SHORT).show();
            return;
        }
        menu.show(anchor != null ? rectOf(anchor) : touchRect(), null, its);
    }

    private void addWidget(String id) {
        Prefs.setQuiet("w_show", true);
        Prefs.setQuiet(WidgetCatalog.pref(id), true);
        List<String> o = WidgetCatalog.order();
        o.remove(id);
        o.add(id);
        Prefs.setList("w_order", o, true);
        rebuildPages();
        if (droppedWidgets.contains(id)) { // the first page is full
            Prefs.setQuiet(WidgetCatalog.pref(id), false);
            rebuildPages();
            Toast.makeText(this, "No room for another widget on this page", Toast.LENGTH_SHORT).show();
        }
    }

    private void removeWidget(String id) {
        Prefs.setQuiet(WidgetCatalog.pref(id), false);
        rebuildPages();
    }

    // ---------------------------------------------------------------- board geometry

    /** Where slot i sits on the board: {x, y, page}. Items flow left-to-right, top-to-bottom, page after page. */
    private int[] slotPos(int i) {
        int cap0 = gRows0 * gCols, capN = gRowsN * gCols;
        int page, k;
        if (i < cap0) {
            page = 0;
            k = i;
        } else {
            int j = i - cap0;
            page = 1 + j / capN;
            k = j % capN;
        }
        int y0 = gTop + (page == 0 ? gWidgetH : 0);
        return new int[]{page * gPw + gSide + (k % gCols) * gCellW, y0 + (k / gCols) * gCellH, page};
    }

    /** Slot index under a point on the board, or -1 (widgets / margins). May be >= cells.size() for empty slots. */
    private int indexAt(float bx, float by) {
        int pages = Math.max(1, pageCount());
        int p = (int) U.clamp((float) Math.floor(bx / gPw), 0f, pages - 1);
        float lx = bx - p * gPw - gSide;
        float ly = by - (gTop + (p == 0 ? gWidgetH : 0));
        if (lx < 0 || ly < 0) return -1;
        int col = (int) (lx / gCellW), row = (int) (ly / gCellH);
        if (col >= gCols || row >= (p == 0 ? gRows0 : gRowsN)) return -1;
        int k = row * gCols + col;
        return p == 0 ? k : gRows0 * gCols + (p - 1) * gRowsN * gCols + k;
    }

    private int pageCount() {
        return cells.isEmpty() ? 1 : slotPos(cells.size() - 1)[2] + 1;
    }

    private void updatePages() {
        int pc = pageCount();
        if (pc == pages || board == null) return;
        pages = pc;
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) board.getLayoutParams();
        lp.width = pc * gPw;
        board.setLayoutParams(lp);
        pager.setPages(pc, gPw);
        dots.setCount(pc);
    }

    /** Put every icon in its slot. Animated = icons slide into gaps. */
    private void layoutCells(boolean animate) {
        for (int i = 0; i < cells.size(); i++) {
            int[] sp = slotPos(i);
            View v = cells.get(i).v;
            if (animate) {
                v.animate().translationX(sp[0]).translationY(sp[1]).setDuration(280)
                        .setInterpolator(new DecelerateInterpolator(1.5f)).start();
            } else {
                v.setTranslationX(sp[0]);
                v.setTranslationY(sp[1]);
            }
        }
        updatePages();
    }

    private List<HomeLayout.Entry> entriesFromCells() {
        List<HomeLayout.Entry> l = new ArrayList<>();
        for (Cell c : cells) l.add(c.e);
        return l;
    }

    private Cell cellOf(View v) {
        for (Cell c : cells) if (c.v == v) return c;
        return null;
    }

    private Map<String, AppInfo> appMap() {
        Map<String, AppInfo> m = new HashMap<>();
        for (AppInfo a : allApps) m.put(a.key(), a);
        return m;
    }

    // ---------------------------------------------------------------- dragging icons

    private void dragStart(AppIconView v, float rx, float ry) {
        Cell c = cellOf(v);
        if (c == null) return;
        menu.dismiss();
        if (!editing) setEditing(true);
        dragCell = c;
        mergeCell = null;
        hoverCell = null;
        lastSwap = 0;
        edgeDir = 0;
        Bitmap b = v.lift();
        int[] loc = new int[2], rl = new int[2];
        v.getLocationOnScreen(loc);
        root.getLocationOnScreen(rl);
        ghostOx = rl[0];
        ghostOy = rl[1];
        ghostDx = rx - loc[0];
        ghostDy = ry - loc[1];
        ghost = new ImageView(this);
        ghost.setImageBitmap(b);
        ghost.setScaleType(ImageView.ScaleType.FIT_XY);
        root.addView(ghost, new FrameLayout.LayoutParams(Math.max(1, v.getWidth()), Math.max(1, v.getHeight())));
        ghost.setTranslationX(loc[0] - ghostOx);
        ghost.setTranslationY(loc[1] - ghostOy);
        ghost.setPivotX(v.getWidth() / 2f);
        ghost.setPivotY(v.iconPx / 2f);
        ghost.animate().scaleX(1.14f).scaleY(1.14f).setDuration(220)
                .setInterpolator(new OvershootInterpolator(2.2f)).start();
        v.animate().cancel();
        v.setAlpha(0f);
        tick();
    }

    private void dragMove(float rx, float ry) {
        if (dragCell == null || ghost == null || board == null) return;
        lastRawX = rx;
        lastRawY = ry;
        ghost.setTranslationX(rx - ghostDx - ghostOx);
        ghost.setTranslationY(ry - ghostDy - ghostOy);
        edgeCheck(rx);
        int[] bl = new int[2];
        board.getLocationOnScreen(bl);
        float bx = rx - bl[0], by = ry - bl[1];
        int idx = indexAt(bx, by);
        if (idx < 0) {
            clearHover();
            return;
        }
        int tgt = Math.min(idx, cells.size() - 1);
        Cell t = cells.get(tgt);
        long now = System.currentTimeMillis();
        if (t == dragCell) {
            clearHover();
            return;
        }
        int[] sp = slotPos(tgt);
        float icx = sp[0] + gCellW / 2f, icy = sp[1] + gIp / 2f;
        boolean center = idx < cells.size() && Math.hypot(bx - icx, by - icy) < gIp * 0.36f;
        if (center && !dragCell.e.folder) {
            // hovering over the middle of another icon: after a short pause it becomes a folder drop
            if (hoverCell != t) {
                clearHover();
                hoverCell = t;
                hoverSince = now;
            } else if (mergeCell == null && now - hoverSince > 450) {
                mergeCell = t;
                t.v.setMerge(true);
                tick();
            }
        } else {
            clearHover();
            if (now - lastSwap > 200) {
                int cur = cells.indexOf(dragCell);
                cells.remove(cur);
                cells.add(tgt, dragCell);
                layoutCells(true);
                lastSwap = now;
                if (Prefs.b("haptics")) root.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            }
        }
    }

    private void clearHover() {
        if (mergeCell != null) mergeCell.v.setMerge(false);
        mergeCell = null;
        hoverCell = null;
    }

    /** Dragging into the left / right screen edge flips pages. */
    private void edgeCheck(float rx) {
        int w = root.getWidth();
        int dir = rx < U.dp(this, 40) ? -1 : (rx > w - U.dp(this, 40) ? 1 : 0);
        if (dir == edgeDir) return;
        edgeDir = dir;
        ui.removeCallbacks(edgeRun);
        if (dir != 0) ui.postDelayed(edgeRun, 650);
    }

    private final Runnable edgeRun = new Runnable() {
        @Override public void run() {
            if (dragCell == null || edgeDir == 0) return;
            int p = pager.page() + edgeDir;
            if (p >= 0 && p < pager.count) {
                pager.goTo(p, true);
                ui.postDelayed(() -> { if (dragCell != null) dragMove(lastRawX, lastRawY); }, 380);
            }
            ui.postDelayed(this, 1000);
        }
    };

    private void dragEnd(boolean cancelled) {
        ui.removeCallbacks(edgeRun);
        edgeDir = 0;
        final Cell c = dragCell;
        dragCell = null;
        final ImageView gh = ghost;
        ghost = null;
        if (c == null || gh == null) return;
        if (!cancelled && mergeCell != null) {
            Cell t = mergeCell;
            mergeCell = null;
            hoverCell = null;
            performMerge(c, t, gh);
            return;
        }
        clearHover();
        HomeLayout.save(entriesFromCells());
        int[] sp = slotPos(cells.indexOf(c));
        int[] bl = new int[2];
        board.getLocationOnScreen(bl);
        gh.animate().translationX(bl[0] + sp[0] - ghostOx).translationY(bl[1] + sp[1] - ghostOy)
                .scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(new OvershootInterpolator(0.9f))
                .withEndAction(() -> {
                    root.removeView(gh);
                    c.v.setAlpha(1f);
                }).start();
    }

    /** Drop an app onto another app (new folder) or onto a folder (add to it). */
    private void performMerge(final Cell drag, final Cell target, final ImageView gh) {
        RectF r = target.v.iconRectOnScreen();
        gh.animate().translationX(r.centerX() - gh.getWidth() / 2f - ghostOx)
                .translationY(r.centerY() - gh.getHeight() / 2f - ghostOy)
                .scaleX(0.4f).scaleY(0.4f).alpha(0f).setDuration(240)
                .setInterpolator(new DecelerateInterpolator(1.4f))
                .withEndAction(() -> {
                    root.removeView(gh);
                    List<HomeLayout.Entry> l = entriesFromCells();
                    HomeLayout.Entry de = drag.e, te = target.e;
                    l.remove(de);
                    int ti = l.indexOf(te);
                    if (te.folder) {
                        if (!te.keys.contains(de.id)) te.keys.add(de.id);
                    } else if (ti >= 0) {
                        HomeLayout.Entry f = new HomeLayout.Entry();
                        f.folder = true;
                        f.id = HomeLayout.newId();
                        f.name = "Folder";
                        f.keys.add(te.id);
                        f.keys.add(de.id);
                        l.set(ti, f);
                    }
                    HomeLayout.save(l);
                    tick();
                    rebuildPages();
                }).start();
    }

    private void cancelDrag() {
        ui.removeCallbacks(edgeRun);
        if (ghost != null) { root.removeView(ghost); ghost = null; }
        dragCell = null;
        mergeCell = null;
        hoverCell = null;
    }

    // ---------------------------------------------------------------- folders

    private HomeLayout.Entry folderEntry(String id) {
        for (HomeLayout.Entry e : entriesFromCells()) if (e.folder && e.id.equals(id)) return e;
        return null;
    }

    private void openFolder(AppInfo f, View anchor) {
        HomeLayout.Entry e = folderEntry(f.folderId);
        if (e == null || !(anchor instanceof AppIconView)) return;
        Map<String, AppInfo> m = appMap();
        List<AppInfo> apps = new ArrayList<>();
        for (String k : e.keys) if (m.containsKey(k)) apps.add(m.get(k));
        if (apps.isEmpty()) return;
        menu.dismiss();
        folderView.open(e.id, e.name, apps, ((AppIconView) anchor).iconRectOnScreen());
    }

    private void showFolderMenu(final AppInfo f, View anchor) {
        tick();
        final String id = f.folderId;
        List<ContextMenuView.Item> its = new ArrayList<>();
        its.add(new ContextMenuView.Item("Rename", R.drawable.ic_pencil, false, () -> {
            openFolder(f, anchor);
            folderView.startRename();
        }));
        its.add(new ContextMenuView.Item("Edit Home Screen", R.drawable.ic_edit_home, false, () -> setEditing(true)));
        its.add(new ContextMenuView.Item("Remove Folder", R.drawable.ic_remove, true, () -> dissolveFolder(id)).gap());
        AppIconView iv = (AppIconView) anchor;
        menu.show(iv.iconRectOnScreen(), iv.icon, its);
    }

    /** Folder goes away; its apps take its place on the grid. */
    private void dissolveFolder(String id) {
        List<HomeLayout.Entry> l = entriesFromCells();
        for (int i = 0; i < l.size(); i++) {
            HomeLayout.Entry e = l.get(i);
            if (e.folder && e.id.equals(id)) {
                l.remove(i);
                for (int k = 0; k < e.keys.size(); k++) l.add(i + k, HomeLayout.Entry.app(e.keys.get(k)));
                break;
            }
        }
        HomeLayout.save(l);
        folderView.closeNow();
        rebuildPages();
    }

    private void removeFromFolder(String id, AppInfo a) {
        List<HomeLayout.Entry> l = entriesFromCells();
        for (int i = 0; i < l.size(); i++) {
            HomeLayout.Entry e = l.get(i);
            if (e.folder && e.id.equals(id)) {
                e.keys.remove(a.key());
                int at = i + 1;
                if (e.keys.size() <= 1) { // a folder with one app dissolves
                    l.remove(i);
                    at = i;
                    for (int k = 0; k < e.keys.size(); k++) l.add(at++, HomeLayout.Entry.app(e.keys.get(k)));
                }
                l.add(at, HomeLayout.Entry.app(a.key()));
                break;
            }
        }
        HomeLayout.save(l);
        folderView.closeNow();
        rebuildPages();
    }

    // ---------------------------------------------------------------- open / close animation

    private long dur(long base) { return Math.max(60, base * 100 / Math.max(25, Prefs.i("anim_speed"))); }

    private void homeProgress(float p) {
        if (!Prefs.b("anim_home")) return;
        float sc = 1f + 0.10f * p; // iPadOS: the home screen zooms toward you and fades as the app opens
        content.setScaleX(sc);
        content.setScaleY(sc);
        content.setAlpha(1f - 0.85f * Math.min(1f, p * 1.4f));
    }

    private void launch(final AppInfo a, RectF from) {
        if (state != 0) return;
        final Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(a.cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        pushRecent(a);
        int style = Prefs.i("anim_open");
        if (style == 2) { start(i, null); return; }
        state = 1;
        android.graphics.Bitmap ic = Icons.get(this, a, U.dpi(this, Prefs.i("icon_size")));
        int oc = Prefs.i("anim_overlay"), color = 0xFFF2F2F7;
        if (oc == 1) color = 0xFF1C1C1E;
        else if (oc == 2) color = blendWhite(U.avgColor(ic), 0.8f);
        overlay.prepare(from, ic, color, style);
        long d = dur(430);
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(d);
        anim.setInterpolator(new PathInterpolator(0.22f, 0.85f, 0.25f, 1f));
        anim.addUpdateListener(an -> {
            float p = (Float) an.getAnimatedValue();
            overlay.setProgress(p);
            homeProgress(p);
        });
        anim.start();
        pendingStart = () -> {
            pendingStart = null;
            start(i, ActivityOptions.makeCustomAnimation(this, 0, 0).toBundle());
        };
        ui.postDelayed(pendingStart, (long) (d * 0.55f));
    }

    private int blendWhite(int c, float amount) {
        int r = Math.round(Color.red(c) * (1 - amount) + 255 * amount);
        int g = Math.round(Color.green(c) * (1 - amount) + 255 * amount);
        int b = Math.round(Color.blue(c) * (1 - amount) + 255 * amount);
        return Color.rgb(r, g, b);
    }

    private void start(Intent i, Bundle opts) {
        try {
            startActivity(i, opts);
        } catch (Exception e) {
            Toast.makeText(this, "Can't open this app", Toast.LENGTH_SHORT).show();
            if (state != 0) closeAnim();
        }
    }

    private void closeAnim() {
        if (state == 0) return;
        state = 0;
        if (pendingStart != null) { ui.removeCallbacks(pendingStart); pendingStart = null; }
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(overlay.progress, 0f);
        anim.setDuration(dur(400));
        anim.setInterpolator(new PathInterpolator(0.3f, 0f, 0.15f, 1f));
        anim.addUpdateListener(an -> {
            float p = (Float) an.getAnimatedValue();
            overlay.setProgress(p);
            homeProgress(p);
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator a) {
                overlay.setVisibility(View.GONE);
                homeProgress(0f);
                content.setScaleX(1f);
                content.setScaleY(1f);
                content.setAlpha(1f);
            }
        });
        anim.start();
    }
}
