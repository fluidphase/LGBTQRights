package com.convert.ipados;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

public class LauncherActivity extends Activity {
    private FrameLayout root, content;
    private WallpaperView wallView;
    private Pager pager;
    private DotsView dots;
    private DockView dock;
    private SpotlightView spot;
    private LaunchOverlay overlay;
    private TextView doneBtn;

    private List<AppInfo> allApps = new ArrayList<>();
    private int rev = -1, insetT, insetB;
    private int state; // 0 = home, 1 = an app is open (overlay covers the screen)
    private boolean editing, loading, reloadAgain;
    private float downX, downY;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Runnable pendingStart;
    private ValueAnimator anim;
    private BroadcastReceiver pkgReceiver;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.init(this);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        wallView = new WallpaperView(this);
        root.addView(wallView, new FrameLayout.LayoutParams(-1, -1));

        content = new FrameLayout(this);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        pager = new Pager(this);
        content.addView(pager, new FrameLayout.LayoutParams(-1, -1));
        dots = new DotsView(this);
        content.addView(dots, new FrameLayout.LayoutParams(-1, U.dpi(this, 20), Gravity.BOTTOM));
        dock = new DockView(this, wallView);
        content.addView(dock, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL));

        doneBtn = new TextView(this);
        doneBtn.setText("Done");
        doneBtn.setTextColor(Color.WHITE);
        doneBtn.setTypeface(Typeface.DEFAULT_BOLD);
        doneBtn.setTextSize(15);
        int pp = U.dpi(this, 14);
        doneBtn.setPadding(pp, pp / 2, pp, pp / 2);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x66000000);
        g.setCornerRadius(U.dp(this, 18));
        doneBtn.setBackground(g);
        doneBtn.setVisibility(View.GONE);
        doneBtn.setOnClickListener(v -> setEditing(false));
        content.addView(doneBtn, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));

        spot = new SpotlightView(this, new SpotlightView.Callback() {
            @Override public void open(AppInfo a) {
                spot.hide();
                float cx = root.getWidth() / 2f, cy = root.getHeight() / 2f, s = U.dp(LauncherActivity.this, 40);
                launch(a, new RectF(cx - s, cy - s, cx + s, cy + s));
            }
            @Override public void close() { spot.hide(); }
        });
        root.addView(spot, new FrameLayout.LayoutParams(-1, -1));

        overlay = new LaunchOverlay(this);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        root.setOnApplyWindowInsetsListener((v, ins) -> {
            insetT = ins.getSystemWindowInsetTop();
            insetB = ins.getSystemWindowInsetBottom();
            applyLayout();
            return ins;
        });
        pager.listener = pos -> dots.setPos(pos);
        pager.addOnLayoutChangeListener((v, l, t, r, bt, oldL, oldT, oldR, oldB) -> {
            if (r - l != oldR - oldL || bt - t != oldB - oldT) rebuildPages();
        });

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        pkgReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) { reloadAll(); }
        };
        registerReceiver(pkgReceiver, f);
        applySystemUi();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pkgReceiver != null) unregisterReceiver(pkgReceiver);
    }

    private void applySystemUi() {
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (Prefs.b("status_dark")) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        root.setSystemUiVisibility(f);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Prefs.init(this);
        applySystemUi();
        boolean wasOpen = state != 0;
        if (wasOpen) closeAnim();
        if (rev != Prefs.i("rev")) {
            rev = Prefs.i("rev");
            applyLayout();
            reloadAll();
        } else if (wasOpen) {
            rebuildDock();
            updateSpot();
        }
        if (!Prefs.b("asked_perm") && Prefs.i("wall_src") == 0 && !Wall.hasStoragePermission(this)) {
            Prefs.setQuiet("asked_perm", true);
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 7);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        Prefs.set("wall_src", Prefs.i("wall_src")); // bump revision => wallpaper reloads in onResume
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        reloadAll();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (spot.getVisibility() == View.VISIBLE) spot.hide();
        if (editing) setEditing(false);
        pager.goTo(0, true);
    }

    @Override
    public void onBackPressed() {
        if (spot.getVisibility() == View.VISIBLE) spot.hide();
        else if (editing) setEditing(false);
        else pager.goTo(0, true);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            downX = e.getX();
            downY = e.getY();
        } else if (a == MotionEvent.ACTION_UP && Prefs.b("search_on") && !editing && state == 0
                && spot.getVisibility() != View.VISIBLE) {
            float dy = e.getY() - downY, dx = e.getX() - downX;
            if (dy > U.dp(this, 110) && Math.abs(dx) < dy * 0.6f && downY < root.getHeight() * 0.75f) spot.show();
        }
        return super.dispatchTouchEvent(e);
    }

    // ---------------------------------------------------------------- layout

    private void applyLayout() {
        boolean showDock = Prefs.b("dock_show");
        int dockH = showDock ? U.dpi(this, Prefs.i("dock_size")) + U.dpi(this, 18) : 0;
        int dockBottom = insetB + U.dpi(this, Prefs.i("dock_margin"));
        FrameLayout.LayoutParams dl = (FrameLayout.LayoutParams) dock.getLayoutParams();
        dl.bottomMargin = dockBottom;
        dock.setLayoutParams(dl);
        int dotsBottom = showDock ? dockBottom + dockH + U.dpi(this, 4) : insetB + U.dpi(this, 8);
        FrameLayout.LayoutParams ol = (FrameLayout.LayoutParams) dots.getLayoutParams();
        ol.bottomMargin = dotsBottom;
        dots.setLayoutParams(ol);
        dots.setVisibility(Prefs.b("page_dots") ? View.VISIBLE : View.INVISIBLE);
        FrameLayout.LayoutParams pl = (FrameLayout.LayoutParams) pager.getLayoutParams();
        pl.topMargin = insetT + U.dpi(this, 6);
        pl.bottomMargin = dotsBottom + U.dpi(this, 24);
        pager.setLayoutParams(pl);
        FrameLayout.LayoutParams bl = (FrameLayout.LayoutParams) doneBtn.getLayoutParams();
        bl.topMargin = insetT + U.dpi(this, 8);
        bl.rightMargin = U.dpi(this, 16);
        doneBtn.setLayoutParams(bl);
        spot.setTopInset(insetT);
    }

    private void reloadAll() {
        if (loading) { reloadAgain = true; return; }
        loading = true;
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        final int sw = dm.widthPixels, sh = dm.heightPixels;
        final int ip = U.dpi(this, Prefs.i("icon_size")), dk = U.dpi(this, Prefs.i("dock_size")), sp = U.dpi(this, 44);
        new Thread(() -> {
            List<AppInfo> l = new ArrayList<>();
            try {
                Icons.configure(this);
                l = Apps.load(this);
                Wall.load(this, sw, sh);
                for (AppInfo a : l) {
                    Icons.get(this, a, ip);
                    Icons.get(this, a, dk);
                    Icons.get(this, a, sp);
                }
            } catch (Throwable ignored) { }
            final List<AppInfo> res = l;
            runOnUiThread(() -> {
                loading = false;
                allApps = res;
                wallView.invalidate();
                dock.invalidate();
                ensureDockDefaults();
                rebuildPages();
                rebuildDock();
                updateSpot();
                if (reloadAgain) { reloadAgain = false; reloadAll(); }
            });
        }).start();
    }

    private List<AppInfo> visibleApps() {
        Set<String> hid = new HashSet<>(Prefs.list("hidden"));
        List<AppInfo> o = new ArrayList<>();
        for (AppInfo a : allApps) if (!hid.contains(a.key())) o.add(a);
        return o;
    }

    private void updateSpot() {
        Map<String, AppInfo> m = new HashMap<>();
        List<AppInfo> vis = visibleApps();
        for (AppInfo a : vis) m.put(a.key(), a);
        List<AppInfo> rec = new ArrayList<>();
        for (String k : Prefs.list("recents")) {
            AppInfo a = m.get(k);
            if (a != null && rec.size() < 5) rec.add(a);
        }
        spot.setApps(vis, rec);
    }

    private void rebuildPages() {
        int pw = pager.getWidth(), ph = pager.getHeight();
        if (pw <= 0 || ph <= 0) return;
        float dn = getResources().getDisplayMetrics().density;
        int side = U.dpi(this, Prefs.i("side_margin"));
        int cols = Prefs.i("cols");
        if (cols <= 0) cols = Math.max(4, Math.min(7, Math.round(pw / dn / 120f)));
        int ip = U.dpi(this, Prefs.i("icon_size"));
        boolean lab = Prefs.b("show_labels");
        int cellH = ip + (lab ? AppIconView.labelHeight(this) : 0) + U.dpi(this, Prefs.i("icon_gapv"));
        int cellW = Math.max(1, (pw - 2 * side) / cols);
        int topPad = U.dpi(this, 8);
        int[] wh = new int[1];
        FrameLayout wc = Prefs.b("w_show") ? buildWidgets(pw - 2 * side, ph, wh) : null;
        int widgetH = wc == null ? 0 : wh[0] + U.dpi(this, 14);
        int rowsMax = Prefs.i("rows");
        int rows0 = Math.max(1, (ph - topPad - widgetH) / cellH), rowsN = Math.max(1, (ph - topPad) / cellH);
        if (rowsMax > 0) {
            rows0 = Math.min(rows0, rowsMax);
            rowsN = Math.min(rowsN, rowsMax);
        }
        int keep = pager.page();
        pager.strip.removeAllViews();
        List<AppInfo> apps = visibleApps();
        int idx = 0, pageNo = 0;
        do {
            FrameLayout page = new FrameLayout(this);
            page.setOnLongClickListener(pg -> { showHomeMenu(); return true; });
            int rows = pageNo == 0 ? rows0 : rowsN;
            int y0 = topPad + (pageNo == 0 ? widgetH : 0);
            if (pageNo == 0 && wc != null) {
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(pw - 2 * side, wh[0]);
                lp.leftMargin = side;
                lp.topMargin = topPad;
                page.addView(wc, lp);
            }
            for (int r = 0; r < rows && idx < apps.size(); r++) {
                for (int k = 0; k < cols && idx < apps.size(); k++) {
                    AppIconView v = makeIcon(apps.get(idx++), ip, lab);
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(cellW, cellH);
                    lp.leftMargin = side + k * cellW;
                    lp.topMargin = y0 + r * cellH;
                    page.addView(v, lp);
                }
            }
            pager.strip.addView(page, new LinearLayout.LayoutParams(pw, ph));
            pageNo++;
        } while (idx < apps.size());
        pager.setPages(pageNo, pw);
        dots.setCount(pageNo);
        final int cur = Math.min(keep, pageNo - 1);
        pager.post(() -> { pager.goTo(cur, false); dots.setPos(cur); });
        if (editing) setEditing(true);
    }

    private FrameLayout buildWidgets(int w, int ph, int[] outH) {
        float dn = getResources().getDisplayMetrics().density;
        int per = Prefs.i("w_perrow");
        if (per <= 0) per = w / dn >= 860 ? 4 : (w / dn >= 560 ? 3 : 2);
        int gap = U.dpi(this, 12);
        int card = (w - gap * (per - 1)) / per;
        List<View> vs = new ArrayList<>();
        List<Integer> spans = new ArrayList<>();
        if (Prefs.b("w_clock")) { vs.add(new ClockWidget(this)); spans.add(1); }
        if (Prefs.b("w_calendar")) { vs.add(new CalendarWidget(this)); spans.add(per >= 3 ? 2 : 1); }
        if (Prefs.b("w_weather")) { vs.add(new WeatherWidget(this)); spans.add(1); }
        if (Prefs.b("w_shortcuts")) { vs.add(new ShortcutsWidget(this)); spans.add(per >= 3 ? 2 : 1); }
        if (Prefs.b("w_notes")) { vs.add(new NotesWidget(this)); spans.add(1); }
        FrameLayout wc = new FrameLayout(this);
        int col = 0, y = 0, used = 0, maxH = (int) (ph * 0.46f);
        for (int i = 0; i < vs.size(); i++) {
            int s = Math.min(per, spans.get(i));
            if (col + s > per) { col = 0; y += card + gap; }
            if (y + card > maxH && y > 0) break;
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(card * s + gap * (s - 1), card);
            lp.leftMargin = col * (card + gap);
            lp.topMargin = y;
            wc.addView(vs.get(i), lp);
            col += s;
            used = y + card;
        }
        if (wc.getChildCount() == 0) return null;
        outH[0] = used;
        return wc;
    }

    private AppIconView makeIcon(final AppInfo a, int px, boolean lab) {
        final AppIconView v = new AppIconView(this, a, Icons.get(this, a, px), px, lab);
        v.setOnClickListener(x -> { if (!editing) launch(a, v.iconRectOnScreen()); });
        v.setOnLongClickListener(x -> { if (!editing) showAppMenu(a, v); return true; });
        v.onBadge = () -> hideApp(a);
        return v;
    }

    // ---------------------------------------------------------------- dock

    private void ensureDockDefaults() {
        if (!Prefs.s("dock_apps").isEmpty() || allApps.isEmpty()) return;
        Intent[] ins = {
                new Intent(Intent.ACTION_DIAL),
                new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
                new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.example.com")),
                new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
                new Intent(Intent.ACTION_VIEW).setType("image/*"),
                new Intent(Settings.ACTION_SETTINGS)
        };
        List<String> out = new ArrayList<>();
        PackageManager pm = getPackageManager();
        for (Intent in : ins) {
            ResolveInfo ri = pm.resolveActivity(in, PackageManager.MATCH_DEFAULT_ONLY);
            if (ri == null || ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            for (AppInfo a : allApps) {
                if (a.cn.getPackageName().equals(pkg)) {
                    if (!out.contains(a.key())) out.add(a.key());
                    break;
                }
            }
        }
        Prefs.setList("dock_apps", out, true);
    }

    private void rebuildDock() {
        dock.removeAllViews();
        boolean show = Prefs.b("dock_show");
        if (!show) { dock.setVisibility(View.GONE); return; }
        Map<String, AppInfo> m = new HashMap<>();
        for (AppInfo a : allApps) m.put(a.key(), a);
        int px = U.dpi(this, Prefs.i("dock_size")), gap = U.dpi(this, 7), pad = U.dpi(this, 9);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int fit = Math.max(1, (dm.widthPixels - U.dpi(this, 32) - 2 * pad) / (px + 2 * gap));
        List<AppInfo> favs = new ArrayList<>(), rec = new ArrayList<>();
        for (String k : Prefs.list("dock_apps")) {
            AppInfo a = m.get(k);
            if (a != null && favs.size() < Math.min(Prefs.i("dock_max"), fit)) favs.add(a);
        }
        if (Prefs.b("dock_recents")) {
            for (String k : Prefs.list("recents")) {
                AppInfo a = m.get(k);
                if (a != null && !favs.contains(a) && rec.size() < Prefs.i("dock_recent_count")
                        && favs.size() + rec.size() < fit) rec.add(a);
            }
        }
        if (favs.isEmpty() && rec.isEmpty()) { dock.setVisibility(View.GONE); return; }
        dock.setVisibility(View.VISIBLE);
        dock.setPadding(pad, pad, pad, pad);
        for (AppInfo a : favs) addDockIcon(a, px, gap);
        if (!favs.isEmpty() && !rec.isEmpty()) {
            View div = new View(this);
            div.setBackgroundColor(0x55FFFFFF);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(U.dpi(this, 1), (int) (px * 0.8f));
            lp.leftMargin = gap;
            lp.rightMargin = gap;
            dock.addView(div, lp);
        }
        for (AppInfo a : rec) addDockIcon(a, px, gap);
        if (editing) forEachIcon(dock, v -> v.setEditing(true));
        dock.invalidate();
    }

    private void addDockIcon(AppInfo a, int px, int gap) {
        AppIconView v = makeIcon(a, px, false);
        dock.addView(v, new LinearLayout.LayoutParams(px + 2 * gap, px));
    }

    private void toggleDock(AppInfo a) {
        List<String> l = Prefs.list("dock_apps");
        if (!l.remove(a.key())) l.add(a.key());
        Prefs.setList("dock_apps", l, true);
        rebuildDock();
    }

    private void pushRecent(AppInfo a) {
        List<String> l = Prefs.list("recents");
        l.remove(a.key());
        l.add(0, a.key());
        while (l.size() > 12) l.remove(l.size() - 1);
        Prefs.setList("recents", l, true);
    }

    // ---------------------------------------------------------------- menus / edit mode

    private void forEachIcon(View v, Consumer<AppIconView> c) {
        if (v instanceof AppIconView) {
            c.accept((AppIconView) v);
        } else if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) forEachIcon(g.getChildAt(i), c);
        }
    }

    private void setEditing(final boolean on) {
        editing = on;
        doneBtn.setVisibility(on ? View.VISIBLE : View.GONE);
        forEachIcon(pager.strip, v -> v.setEditing(on));
        forEachIcon(dock, v -> v.setEditing(on));
    }

    private void hideApp(AppInfo a) {
        List<String> l = Prefs.list("hidden");
        if (!l.contains(a.key())) l.add(a.key());
        Prefs.setList("hidden", l, false);
        rev = Prefs.i("rev"); // we rebuild by hand, no need for a full reload
        rebuildPages();
        rebuildDock();
        updateSpot();
    }

    private void showAppMenu(final AppInfo a, View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        boolean inDock = Prefs.list("dock_apps").contains(a.key());
        m.add(0, 1, 0, "Edit Home Screen");
        m.add(0, 2, 0, inDock ? "Remove from Dock" : "Add to Dock");
        m.add(0, 3, 0, "Hide App");
        m.add(0, 4, 0, "App Info");
        m.add(0, 5, 0, "Uninstall App");
        pm.setOnMenuItemClickListener(it -> {
            Uri pkg = Uri.parse("package:" + a.cn.getPackageName());
            try {
                switch (it.getItemId()) {
                    case 1: setEditing(true); break;
                    case 2: toggleDock(a); break;
                    case 3: hideApp(a); break;
                    case 4: startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)); break;
                    default: startActivity(new Intent(Intent.ACTION_DELETE, pkg));
                }
            } catch (Exception e) {
                Toast.makeText(this, "Not available", Toast.LENGTH_SHORT).show();
            }
            return true;
        });
        pm.show();
    }

    private void showHomeMenu() {
        if (editing) return;
        final String[] items = {"Edit Home Screen", "Wallpaper", "Widgets", "Launcher Settings"};
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Light_Dialog_Alert)
                .setItems(items, (d, w) -> {
                    if (w == 0) { setEditing(true); return; }
                    Intent i = new Intent(this, SettingsActivity.class);
                    if (w == 1) i.putExtra("page", "wallpaper");
                    if (w == 2) i.putExtra("page", "widgets");
                    startActivity(i);
                }).show();
    }

    // ---------------------------------------------------------------- open / close animation

    private long dur(long base) { return Math.max(60, base * 100 / Math.max(25, Prefs.i("anim_speed"))); }

    private void homeProgress(float p) {
        if (!Prefs.b("anim_home")) return;
        content.setScaleX(1f + 0.05f * p);
        content.setScaleY(1f + 0.05f * p);
        content.setAlpha(1f - 0.35f * p);
    }

    private void launch(final AppInfo a, RectF from) {
        if (state != 0) return;
        final Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(a.cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        pushRecent(a);
        int style = Prefs.i("anim_open");
        if (style == 2) { start(i, null); return; }
        state = 1;
        android.graphics.Bitmap ic = Icons.get(this, a, U.dpi(this, Prefs.i("icon_size")));
        int oc = Prefs.i("anim_overlay"), color = 0xFFF2F2F7;
        if (oc == 1) color = 0xFF1C1C1E;
        else if (oc == 2) color = blendWhite(U.avgColor(ic), 0.8f);
        overlay.prepare(from, ic, color, style);
        long d = dur(380);
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(d);
        anim.setInterpolator(new PathInterpolator(0.22f, 0.85f, 0.25f, 1f));
        anim.addUpdateListener(an -> {
            float p = (Float) an.getAnimatedValue();
            overlay.setProgress(p);
            homeProgress(p);
        });
        anim.start();
        pendingStart = () -> {
            pendingStart = null;
            start(i, ActivityOptions.makeCustomAnimation(this, 0, 0).toBundle());
        };
        ui.postDelayed(pendingStart, (long) (d * 0.55f));
    }

    private int blendWhite(int c, float amount) {
        int r = Math.round(Color.red(c) * (1 - amount) + 255 * amount);
        int g = Math.round(Color.green(c) * (1 - amount) + 255 * amount);
        int b = Math.round(Color.blue(c) * (1 - amount) + 255 * amount);
        return Color.rgb(r, g, b);
    }

    private void start(Intent i, Bundle opts) {
        try {
            startActivity(i, opts);
        } catch (Exception e) {
            Toast.makeText(this, "Can't open this app", Toast.LENGTH_SHORT).show();
            if (state != 0) closeAnim();
        }
    }

    private void closeAnim() {
        if (state == 0) return;
        state = 0;
        if (pendingStart != null) { ui.removeCallbacks(pendingStart); pendingStart = null; }
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(overlay.progress, 0f);
        anim.setDuration(dur(360));
        anim.setInterpolator(new PathInterpolator(0.3f, 0f, 0.15f, 1f));
        anim.addUpdateListener(an -> {
            float p = (Float) an.getAnimatedValue();
            overlay.setProgress(p);
            homeProgress(p);
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator a) {
                overlay.setVisibility(View.GONE);
                homeProgress(0f);
                content.setScaleX(1f);
                content.setScaleY(1f);
                content.setAlpha(1f);
            }
        });
        anim.start();
    }
}
