package com.ipados.sim;

import android.Manifest;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    static final int REQ_PERM = 21, REQ_WP = 22;
    FrameLayout root;
    HomeLayer layer;
    HomeView home;
    Widgets widgets;
    LockView lock;
    View overlay;
    boolean permAsked;
    int lastWpId = -2;
    BroadcastReceiver pkgRx, batRx;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.load(this);
        Ui.init(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        hideBars();
        home = new HomeView(this);
        widgets = new Widgets(this, home);
        home.widgets = widgets;
        layer = new HomeLayer(this, home, widgets.layer);
        if (Prefs.intro) root.addView(new InstallView(this, this::showBoot), new FrameLayout.LayoutParams(-1, -1));
        else root.addView(layer, new FrameLayout.LayoutParams(-1, -1));

        pkgRx = new BroadcastReceiver() { @Override public void onReceive(Context c, Intent i) { home.reloadApps(); } };
        IntentFilter pf = new IntentFilter(); pf.addAction(Intent.ACTION_PACKAGE_ADDED); pf.addAction(Intent.ACTION_PACKAGE_REMOVED); pf.addAction(Intent.ACTION_PACKAGE_CHANGED); pf.addDataScheme("package");
        registerReceiver(pkgRx, pf);
        batRx = new BroadcastReceiver() { @Override public void onReceive(Context c, Intent i) {
            int lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 100), sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            Ui.batt = Math.max(0, Math.min(100, Math.round(lv * 100f / Math.max(1, sc))));
        } };
        registerReceiver(batRx, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideBars(); }
    @Override protected void onStart() { super.onStart(); widgets.start(); }
    @Override protected void onStop() { super.onStop(); widgets.stop(); }
    @Override protected void onDestroy() { super.onDestroy(); try { unregisterReceiver(pkgRx); unregisterReceiver(batRx); } catch (Exception ignored) { } }

    @Override protected void onResume() {
        super.onResume();
        overridePendingTransition(0, 0);
        home.onResumed();
        if (Prefs.wpMode == 0) {
            if (!hasStorage()) { if (!permAsked) { permAsked = true; askStorage(); } }
            else if (Build.VERSION.SDK_INT >= 24) {
                int id = WallpaperManager.getInstance(this).getWallpaperId(WallpaperManager.FLAG_SYSTEM);
                if (id != lastWpId) { lastWpId = id; home.reloadWallpaper(); }
            }
        }
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); overridePendingTransition(0, 0); closeOverlay(); home.goHome(); }

    // ---- storage permission (used to read the real system wallpaper for the home screen + blurred dock)
    boolean hasStorage() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                || (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED);
    }

    void askStorage() {
        if (Build.VERSION.SDK_INT < 23) return;
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERM);
        else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERM);
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] r) { super.onRequestPermissionsResult(rc, p, r); home.reloadWallpaper(); }

    void pickWallpaper() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, REQ_WP); } catch (Exception ignored) { }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (widgets.onResult(req, res, data)) return;
        if (req == REQ_WP && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            Prefs.put("wpUri", u.toString()); Prefs.put("wpMode", 1);
            home.reloadWallpaper();
        }
    }

    // ---- overlays
    void apply(boolean heavy) { home.applyPrefs(heavy); }
    void openSettings() { if (overlay == null) show(new SettingsView(this, home)); }
    void openSearch() { if (overlay == null) show(new SearchView(this, home)); }

    void show(View v) {
        overlay = v; root.addView(v, new FrameLayout.LayoutParams(-1, -1));
        v.setAlpha(0f); v.animate().alpha(1f).setDuration(160).start();
    }

    void closeOverlay() {
        final View v = overlay;
        if (v == null) return;
        overlay = null;
        if (v instanceof SearchView) ((SearchView) v).hideIme();
        v.animate().alpha(0f).setDuration(140).withEndAction(() -> root.removeView(v)).start();
    }

    void expandNotifications() {
        try {
            Object sb = getSystemService("statusbar");
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb);
        } catch (Throwable ignored) { }
    }

    // ---- optional intro (install -> boot -> lock -> home)
    void showBoot() {
        final View old = root.getChildAt(0);
        BootView bv = new BootView(this, this::showLock);
        root.addView(bv, new FrameLayout.LayoutParams(-1, -1));
        bv.setAlpha(0f);
        bv.animate().alpha(1f).setDuration(350).withEndAction(() -> root.removeView(old));
    }

    void showLock() {
        final View boot = root.getChildAt(0);
        root.addView(layer, 0, new FrameLayout.LayoutParams(-1, -1));
        lock = new LockView(this, this::unlock);
        lock.setAlpha(0f);
        root.addView(lock, new FrameLayout.LayoutParams(-1, -1));
        lock.animate().alpha(1f).setDuration(700).withEndAction(() -> root.removeView(boot));
    }

    void unlock() {
        layer.setScaleX(1.1f); layer.setScaleY(1.1f);
        layer.animate().scaleX(1f).scaleY(1f).setDuration(500).setInterpolator(new DecelerateInterpolator(2f)).start();
        lock.animate().translationY(-root.getHeight()).alpha(0f).setDuration(380).setInterpolator(new DecelerateInterpolator(1.5f))
                .withEndAction(() -> { root.removeView(lock); lock = null; }).start();
    }

    @Override public void onBackPressed() {
        if (overlay != null) { closeOverlay(); return; }
        if (home != null && lock == null) home.handleBack();
    }
}
