package com.ipados.sim;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

/** All launcher settings. Hot values are cached in static fields; put() writes + re-reads. */
final class Prefs {
    static SharedPreferences sp;
    static int cols = 7, rows = 4, labelColor = 0xFFFFFFFF, dockBlur = 3, dockTint = 56, dockRadius = 28, dockMax = 9,
            wpMode = 0, wpDim = 26, wpBlur = 0, splash = 0, swipeLeft = 1, accent = 0xFF0A84FF;
    static float iconScale = 1f, labelSize = 11.5f, corner = 22.5f, dockScale = 1f, speed = 1f;
    static boolean labels = true, ios = true, builtin = true, parallax = true, haptics = true, jiggle = true,
            status = true, h24 = false, date = true, pull = true, intro = false, cc = true;
    static String wpUri = "";

    static void load(Context c) { if (sp == null) sp = c.getSharedPreferences("launcher", 0); read(); }

    static void read() {
        cols = sp.getInt("cols", 7); rows = sp.getInt("rows", 4); labelColor = sp.getInt("labelColor", 0xFFFFFFFF);
        dockBlur = sp.getInt("dockBlur", 3); dockTint = sp.getInt("dockTint", 56); dockRadius = sp.getInt("dockRadius", 28);
        dockMax = sp.getInt("dockMax", 9); wpMode = sp.getInt("wpMode", 0); wpDim = sp.getInt("wpDim", 26); wpBlur = sp.getInt("wpBlur", 0);
        splash = sp.getInt("splash", 0); swipeLeft = sp.getInt("swipeLeft", 1); accent = sp.getInt("accent", 0xFF0A84FF);
        iconScale = sp.getFloat("iconScale", 1f); labelSize = sp.getFloat("labelSize", 11.5f); corner = sp.getFloat("corner", 22.5f);
        dockScale = sp.getFloat("dockScale", 1f); speed = sp.getFloat("speed", 1f);
        labels = sp.getBoolean("labels", true); ios = sp.getBoolean("ios", true); builtin = sp.getBoolean("builtin", true);
        parallax = sp.getBoolean("parallax", true); haptics = sp.getBoolean("haptics", true); jiggle = sp.getBoolean("jiggle", true);
        status = sp.getBoolean("status", true); h24 = sp.getBoolean("h24", false); date = sp.getBoolean("date", true);
        pull = sp.getBoolean("pull", true); intro = sp.getBoolean("intro", false); cc = sp.getBoolean("cc", true);
        wpUri = sp.getString("wpUri", "");
    }

    static void put(String k, Object v) {
        SharedPreferences.Editor e = sp.edit();
        if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
        else if (v instanceof Integer) e.putInt(k, (Integer) v);
        else if (v instanceof Float) e.putFloat(k, (Float) v);
        else e.putString(k, String.valueOf(v));
        e.apply(); read();
    }

    static ArrayList<String> list(String k) {
        ArrayList<String> r = new ArrayList<>();
        String s = sp.getString(k, "");
        if (s.isEmpty()) return r;
        for (String x : s.split("\\|")) if (!x.isEmpty()) r.add(x);
        return r;
    }

    static void putList(String k, List<String> l) {
        StringBuilder b = new StringBuilder();
        for (String s : l) { if (b.length() > 0) b.append('|'); b.append(s); }
        sp.edit().putString(k, b.toString()).apply();
    }
}
