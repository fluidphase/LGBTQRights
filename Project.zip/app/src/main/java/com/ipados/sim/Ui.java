package com.ipados.sim;

import android.animation.TimeInterpolator;
import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import java.io.InputStream;
import android.graphics.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class Ui {
    static float d = 1;
    static Context ctx;
    static int batt = 100;
    static boolean gfx = true;   // Graphics Accelerator switch
    static int bg(int col) { return gfx ? col : 0xFF000000; }
    static void init(Context c) {
        ctx = c.getApplicationContext();
        d = c.getResources().getDisplayMetrics().density;
        try {
            Typeface sf = Typeface.createFromAsset(c.getAssets(), "sf.otf");
            REG = sf; MED = sf; LIGHT = sf; THIN = sf; BOLD = Typeface.create(sf, Typeface.BOLD);
        } catch (Exception ignored) { }
        Icons.init(c);
    }
    static float dp(float v) { return v * d; }
    static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    static float cl(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

    static Typeface REG = Typeface.create("sans-serif", Typeface.NORMAL), MED = REG, LIGHT = REG, THIN = REG, BOLD = Typeface.create("sans-serif", Typeface.BOLD);
    static final Typeface MONO = Typeface.MONOSPACE;

    static Paint p(int col) { Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(col); return p; }

    private static final Paint TX = new Paint(Paint.ANTI_ALIAS_FLAG);
    /** Shared text paint (size in dp). Don't hold two at once. */
    static Paint tx(int col, float sizeDp, Typeface f, Paint.Align a) {
        TX.setShader(null); TX.setStyle(Paint.Style.FILL); TX.setColor(gfx ? col : 0xFFFF2B2B);
        TX.setTextSize(dp(sizeDp)); TX.setTypeface(f); TX.setTextAlign(a); return TX;
    }

    /** Critically-ish damped spring with a small, iOS-like overshoot. */
    static class Spring implements TimeInterpolator {
        final float k, w;
        Spring() { this(8, 8); }
        Spring(float k, float w) { this.k = k; this.w = w; }
        public float getInterpolation(float t) { return (float) (1 - Math.exp(-k * t) * Math.cos(w * t)); }
    }

    /** Critically damped spring with initial velocity: fluid, never overshoots (no bounce). */
    static class Smooth implements TimeInterpolator {
        public float getInterpolation(float t) { return (float) (1 - (1 + 5 * t) * Math.exp(-9 * t)); }
    }

    static String fmt(String f) { return new SimpleDateFormat(f, Locale.US).format(new Date()); }

    static Bitmap wallpaper(int w, int h) {
        Bitmap src = null;
        try {
            if (Prefs.wpMode == 1 && Prefs.wpUri != null && !Prefs.wpUri.isEmpty()) src = decode(Uri.parse(Prefs.wpUri), w / 2, h / 2);
            else if (Prefs.wpMode == 0) src = systemWallpaper();
        } catch (Throwable ignored) { }
        int bw = Math.max(2, w / 2), bh = Math.max(2, h / 2);
        if (src != null) {
            Bitmap b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
            float s = Math.max(bw / (float) src.getWidth(), bh / (float) src.getHeight());
            float dw = src.getWidth() * s, dh = src.getHeight() * s;
            new Canvas(b).drawBitmap(src, null, new RectF((bw - dw) / 2, (bh - dh) / 2, (bw + dw) / 2, (bh + dh) / 2), new Paint(Paint.FILTER_BITMAP_FLAG));
            return Prefs.wpBlur > 0 ? HomeView.blur(b, Prefs.wpBlur) : b;
        }
        return gradient(w, h);
    }

    /** Needs READ_EXTERNAL_STORAGE / READ_MEDIA_IMAGES to read the real system wallpaper. */
    static Bitmap systemWallpaper() {
        try {
            WallpaperManager wm = WallpaperManager.getInstance(ctx);
            Drawable dr = null;
            try { dr = wm.getDrawable(); } catch (Throwable ignored) { }
            if (dr == null) dr = wm.getBuiltInDrawable();
            if (dr instanceof BitmapDrawable) return ((BitmapDrawable) dr).getBitmap();
            if (dr != null) {
                int iw = Math.min(1600, Math.max(2, dr.getIntrinsicWidth())), ih = Math.min(1600, Math.max(2, dr.getIntrinsicHeight()));
                Bitmap b = Bitmap.createBitmap(iw, ih, Bitmap.Config.ARGB_8888);
                dr.setBounds(0, 0, iw, ih); dr.draw(new Canvas(b)); return b;
            }
        } catch (Throwable ignored) { }
        return null;
    }

    static Bitmap decode(Uri u, int tw, int th) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
        InputStream in = ctx.getContentResolver().openInputStream(u); BitmapFactory.decodeStream(in, null, o); in.close();
        int s = 1; while (o.outWidth / (s * 2) >= tw && o.outHeight / (s * 2) >= th) s *= 2;
        o = new BitmapFactory.Options(); o.inSampleSize = s;
        in = ctx.getContentResolver().openInputStream(u); Bitmap b = BitmapFactory.decodeStream(in, null, o); in.close();
        return b;
    }

    static Bitmap gradient(int w, int h) {
        int bw = Math.max(2, w / 3), bh = Math.max(2, h / 3);
        Bitmap b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, bw, bh, new int[]{0xFF0A1A55, 0xFF352B9A, 0xFFAE48C6, 0xFFFF7C8C},
                new float[]{0, .4f, .75f, 1}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, bw, bh, p);
        int[] cols = {0x22D3EE, 0x6D5DF6, 0xFF5FA2, 0x3B82F6, 0xFFB86B};
        float[][] pos = {{.18f, .25f, .55f}, {.78f, .22f, .5f}, {.62f, .9f, .6f}, {.08f, .95f, .5f}, {.95f, .8f, .45f}};
        for (int i = 0; i < cols.length; i++) {
            p.setShader(new RadialGradient(bw * pos[i][0], bh * pos[i][1], bw * pos[i][2],
                    0xAA000000 | cols[i], cols[i], Shader.TileMode.CLAMP));
            c.drawRect(0, 0, bw, bh, p);
        }
        return b;
    }

    /** Status bar intentionally removed. */
    static void statusBar(Canvas c, int W, boolean left, int col) { }

    static void ring(Canvas c, float cx, float cy, float r, float prog, int col, float w) {
        Paint s = p(col); s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(dp(w)); s.setStrokeCap(Paint.Cap.ROUND);
        s.setAlpha(70); c.drawCircle(cx, cy, r, s); s.setAlpha(255);
        c.drawArc(cx - r, cy - r, cx + r, cy + r, -90, 360 * prog, false, s);
    }
}
