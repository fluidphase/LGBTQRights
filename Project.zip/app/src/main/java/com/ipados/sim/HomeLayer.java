package com.ipados.sim;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

/** Holds the canvas HomeView plus the real widget layer; hands horizontal swipes that start on a widget over to HomeView for paging. */
final class HomeLayer extends FrameLayout {
    final HomeView home; final int slop; float dx, dy; boolean fwd;

    HomeLayer(Context c, HomeView h, View widgetLayer) {
        super(c); home = h; slop = ViewConfiguration.get(c).getScaledTouchSlop();
        addView(h, new LayoutParams(-1, -1)); addView(widgetLayer, new LayoutParams(-1, -1));
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) { dx = e.getX(); dy = e.getY(); fwd = false; }
        else if (a == MotionEvent.ACTION_MOVE && !fwd && Math.abs(e.getX() - dx) > slop && Math.abs(e.getX() - dx) > Math.abs(e.getY() - dy)) {
            fwd = true;
            MotionEvent d = MotionEvent.obtain(e.getDownTime(), e.getDownTime(), MotionEvent.ACTION_DOWN, dx, dy, 0);
            home.dispatchTouchEvent(d); d.recycle();
            home.dispatchTouchEvent(e);
            return true;
        }
        return false;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (!fwd) return false;
        home.dispatchTouchEvent(e);
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) fwd = false;
        return true;
    }
}
