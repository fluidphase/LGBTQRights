package com.ipados.sim;

import android.graphics.*;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;

final class AppIcon {
    static final String[][] MAP = {{"phone", "phone"}, {"dialer", "phone"}, {"messages", "messages"}, {"messaging", "messages"}, {"camera", "camera"},
            {"settings", "settings"}, {"calendar", "calendar"}, {"clock", "clock"}, {"calculator", "calculator"}, {"photos", "photos"}, {"gallery", "photos"},
            {"contacts", "contacts"}, {"files", "files"}, {"my files", "files"}, {"notes", "notes"}, {"music", "music"}, {"maps", "maps"}, {"weather", "weather"},
            {"chrome", "safari"}, {"internet", "safari"}, {"browser", "safari"}, {"gmail", "mail"}, {"email", "mail"}, {"mail", "mail"}, {"play store", "appstore"},
            {"podcasts", "podcasts"}, {"tv", "tv"}, {"health", "health"}, {"wallet", "wallet"}, {"recorder", "voicememos"}, {"voice recorder", "voicememos"},
            {"tips", "tips"}, {"news", "news"}, {"stocks", "stocks"}, {"books", "books"}, {"reminders", "reminders"}, {"meet", "facetime"}, {"duo", "facetime"},
            {"measure", "measure"}, {"compass", "compass"}, {"keep notes", "notes"}, {"home", "home"}};

    /** Bundled iOS-style icon id for a well-known app label, or null. */
    static String iosId(String label) {
        String l = label.trim().toLowerCase(java.util.Locale.ROOT);
        for (String[] m : MAP) if (m[0].equals(l)) return m[1];
        return null;
    }

    /** Renders the app's own icon into a 192px rounded-corner bitmap (adaptive icons are re-masked to our corner radius). */
    static Bitmap make(Drawable d, float cornerPct, float zoom, boolean force) {
        int S = 192;
        Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        boolean mask = true;
        try {
            if (Build.VERSION.SDK_INT >= 26 && d instanceof AdaptiveIconDrawable) {
                AdaptiveIconDrawable ad = (AdaptiveIconDrawable) d;
                float span = S * 1.5f / Math.max(0.5f, zoom), o = -(span - S) / 2f, e = o + span;
                Drawable bg = ad.getBackground(), fg = ad.getForeground();
                if (bg != null) { bg.setBounds((int) o, (int) o, (int) e, (int) e); bg.draw(c); }
                if (fg != null) { fg.setBounds((int) o, (int) o, (int) e, (int) e); fg.draw(c); }
            } else {   // legacy icon: already shaped by its author -> full size, transparent background, only re-masked if forced
                d.setBounds(0, 0, S, S); d.draw(c);
                mask = force;
            }
        } catch (Throwable ignored) { c.drawColor(0xFF8E8E93); }
        if (mask) {
            Paint m = new Paint(Paint.ANTI_ALIAS_FLAG);
            m.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            float r = S * cornerPct / 100f;
            c.drawRoundRect(0, 0, S, S, r, r, m);
        }
        return b;
    }

    static int avg(Bitmap b) { return 0xFF000000 | Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0); }
}
