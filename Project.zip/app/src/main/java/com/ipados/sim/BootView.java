package com.ipados.sim;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.LinearInterpolator;
import java.util.ArrayList;
import java.util.Random;

public class BootView extends View {
    final Runnable done;
    final ArrayList<String> lines = new ArrayList<>();
    final Handler h = new Handler(Looper.getMainLooper());
    int shown = 0;
    float logo = 0, prog = 0;
    boolean logoPhase = false;
    Bitmap logoBmp;

    static final String[] MODS = {"AppleARMPE", "IOKit", "AMFI", "Sandbox", "AppleKeyStore", "IOSurface", "AppleH13CLCD", "IOHIDFamily",
            "AppleSEP", "IOAccelerator", "AppleBCMWLAN", "AppleUSBHost", "IOMobileFramebuffer", "AppleANE", "CoreTelephony",
            "SpringBoard", "backboardd", "configd", "launchd", "mediaserverd", "AppleCredentialManager", "IONVMeFamily", "AppleMesa", "AppleAVE2"};
    static final String[] ACTS = {"initialized", "kext loaded", "probing device tree", "registering service", "attached", "started",
            "ready", "mounted volume", "signature verified", "pool allocated", "handshake complete", "firmware OK", "entitlements validated"};

    public BootView(Context c, Runnable done) {
        super(c); this.done = done;
        logoBmp = BitmapFactory.decodeResource(c.getResources(), R.drawable.boot_logo);
        Random r = new Random(17);
        lines.add("iBoot-8422.100.650 for iPad14,6  (iPadOS 17.0 21A329)");
        lines.add("Darwin Kernel Version 23.0.0: root:xnu-10002.1.13~1/RELEASE_ARM64_T8112");
        lines.add("boot-args = \"-v serial=3 debug=0x14e\"");
        int sec = 0, us = 0;
        for (int i = 0; i < 128; i++) {
            us += r.nextInt(300000); if (us > 999999) { us -= 1000000; sec++; }
            String m = MODS[r.nextInt(MODS.length)], a = ACTS[r.nextInt(ACTS.length)];
            lines.add(String.format("[%5d.%06d] %s: %s @0x%08x", sec, us, m, a, r.nextInt()));
        }
        lines.add("[    4.912034] launchd: Starting SpringBoard");
        lines.add("[    4.998120] SpringBoard: boot complete");
        h.postDelayed(tick, 400);
    }

    final Runnable tick = new Runnable() {
        @Override public void run() {
            shown = Math.min(lines.size(), shown + 2 + (int) (Math.random() * 3));
            invalidate();
            if (shown < lines.size()) h.postDelayed(this, 30);
            else h.postDelayed(() -> startLogo(), 500);
        }
    };

    void startLogo() {
        logoPhase = true; logo = 1f; invalidate();
        h.postDelayed(done, 2600);
    }

    @Override protected void onDetachedFromWindow() { super.onDetachedFromWindow(); h.removeCallbacksAndMessages(null); }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), hh = getHeight();
        c.drawColor(0xFF000000);
        if (!logoPhase) {
            float lh = Ui.dp(13.5f);
            int max = (int) ((hh - Ui.dp(16)) / lh);
            int start = Math.max(0, shown - max);
            Paint t = Ui.tx(0xFFE8E8E8, 10.5f, Ui.MONO, Paint.Align.LEFT);
            for (int i = start; i < shown; i++) c.drawText(lines.get(i), Ui.dp(10), Ui.dp(12) + (i - start + 1) * lh - Ui.dp(2), t);
            return;
        }
        if (logoBmp == null) return;
        float lh = Math.min(Ui.dp(110), hh * 0.3f), lw = lh * logoBmp.getWidth() / logoBmp.getHeight();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        p.setAlpha((int) (255 * logo));
        c.drawBitmap(logoBmp, null, new RectF(w / 2f - lw / 2, hh / 2f - lh / 2, w / 2f + lw / 2, hh / 2f + lh / 2), p);
    }
}
