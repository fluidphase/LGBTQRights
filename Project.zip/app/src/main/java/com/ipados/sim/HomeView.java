package com.ipados.sim;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.LauncherApps;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ShortcutInfo;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class HomeView extends View {
    static final int LABEL_DP = 18;
    static final float ROW = 46, SEP = 6;
    static final int A_REMOVE = 0, A_SHARE = 1, A_EDIT = 2, A_OPEN = 3, A_INFO = 4, A_WIDGET = 10, A_WALL = 11, A_SETTINGS = 12;

    static class App {
        String key, pkg, cls, name, id; int page, avg; boolean removed, dock, avgSet;
        float cx, top, sz, press = 1f, phase, tcx, ttop; Drawable raw; Bitmap icon;
    }

    final MainActivity host;
    Widgets widgets;
    final ArrayList<App> apps = new ArrayList<>(), dock = new ArrayList<>();
    final ArrayList<int[]> slots = new ArrayList<>();
    final Paint bp = new Paint(Paint.FILTER_BITMAP_FLAG), fp = Ui.p(0);
    Bitmap wp, wpBlur, snap;
    int W, H, pages = 2, slop;
    float iconSz, dockSz, cellW, cellH, gridTop, dockTop, dockBottom, vPad, hPad, label, widgetTop;
    final RectF wWeather = new RectF(), wCal = new RectF(), wBat = new RectF(), dockRect = new RectF(), doneBtn = new RectF(), addBtn = new RectF(), wpr = new RectF();

    float pageF = 1, startPage, downX, downY, openT = 0, dragX, dragY;
    boolean moved, jiggle, lpFired, pull, leftPend, launched, plainExit, closingAnim, capturing, edgePosted;
    App pressed, openApp, dragApp, menuApp;
    Object pendingSc;
    RectF ir = new RectF();
    ValueAnimator pageAnim, openAnim, menuAnim;
    VelocityTracker vt;
    long lastSec = -1;
    // low-FPS "no accelerator" mode
    Bitmap lagBmp; Canvas lagCv; long nextFrame; boolean lastAnim; int fakeFps = 60;
    // Control Center
    float ccT = 0f; boolean ccOpen, ccDrag, ccPending, ccDown; ValueAnimator ccAnim; Bitmap ccSnap; int sliderDrag = -1;
    float brightness = 0.8f, volume = 0.55f;
    final float[] tileT = new float[11]; final boolean[] tileOn = new boolean[11];
    final RectF[] tiles = new RectF[11]; final RectF ccPanel = new RectF(); RectF mConn = new RectF(), mMedia = new RectF(), sB = new RectF(), sV = new RectF();
    final Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Runnable clk = new Runnable() { public void run() { invalidate(); postDelayed(this, 1000); } };
    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); post(clk); }
    @Override protected void onDetachedFromWindow() { super.onDetachedFromWindow(); removeCallbacks(clk); }

    // context menu
    boolean menuOn; float menuT = 0; final RectF menuRect = new RectF(), menuAnchor = new RectF();
    String[] menuLabels; int[] menuIco, menuAct; int menuSep = -1; List<Object> menuSc = new ArrayList<>();

    public HomeView(Context c) {
        super(c);
        host = (MainActivity) c;
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        tileOn[2] = true; tileOn[3] = true; tileT[2] = 1f; tileT[3] = 1f;
        reloadApps();
    }

    void hap(int type) { if (Prefs.haptics) performHapticFeedback(type); }
    void syncW() { if (widgets != null) widgets.sync(pageF, openT > 0.001f || ccT > 0.001f || menuOn); }
    boolean builtinOn() { return Prefs.builtin && Prefs.cols >= 6; }

    // ---------------------------------------------------------------- apps
    void reloadApps() {
        Context cx = getContext(); PackageManager pm = cx.getPackageManager();
        ArrayList<App> list = new ArrayList<>();
        Intent in = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo ri : pm.queryIntentActivities(in, 0)) {
            if (ri.activityInfo.packageName.equals(cx.getPackageName())) continue;
            App a = new App(); a.pkg = ri.activityInfo.packageName; a.cls = ri.activityInfo.name; a.key = a.pkg + "/" + a.cls;
            a.name = String.valueOf(ri.loadLabel(pm)); a.raw = ri.loadIcon(pm); a.id = AppIcon.iosId(a.name);
            a.phase = (float) (Math.random() * 6.28); list.add(a);
        }
        Collections.sort(list, (x, y) -> x.name.compareToIgnoreCase(y.name));
        HashMap<String, App> by = new HashMap<>();
        for (App a : list) by.put(a.key, a);
        ArrayList<String> dk = Prefs.list("dockList"), ok = Prefs.list("order"), hid = Prefs.list("hidden");
        if (dk.isEmpty() && ok.isEmpty()) dk = defaultDock(pm, list);
        apps.clear(); dock.clear();
        for (String k : dk) { App a = by.remove(k); if (a != null && dock.size() < Prefs.dockMax) { a.dock = true; dock.add(a); } else if (a != null) by.put(k, a); }
        for (String k : ok) { App a = by.remove(k); if (a != null) apps.add(a); }
        for (App a : list) if (by.containsKey(a.key)) apps.add(a);
        for (App a : apps) a.removed = hid.contains(a.key);
        if (W > 0) { measure(); }
        invalidate();
    }

    ArrayList<String> defaultDock(PackageManager pm, ArrayList<App> list) {
        Intent[] ins = {new Intent(Intent.ACTION_DIAL), new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")), new Intent(Intent.ACTION_VIEW, Uri.parse("http://example.com")),
                new Intent(MediaStore.ACTION_IMAGE_CAPTURE), new Intent(Settings.ACTION_SETTINGS)};
        ArrayList<String> r = new ArrayList<>();
        for (Intent i : ins) {
            ResolveInfo ri = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
            if (ri == null || ri.activityInfo == null) continue;
            for (App a : list) if (a.pkg.equals(ri.activityInfo.packageName) && !r.contains(a.key)) { r.add(a.key); break; }
        }
        return r;
    }

    void saveState() {
        ArrayList<String> o = new ArrayList<>(), d = new ArrayList<>(), h = new ArrayList<>();
        for (App a : apps) { o.add(a.key); if (a.removed) h.add(a.key); }
        for (App a : dock) d.add(a.key);
        Prefs.putList("order", o); Prefs.putList("dockList", d); Prefs.putList("hidden", h);
    }

    void resetLayout() { Prefs.putList("order", new ArrayList<String>()); Prefs.putList("dockList", new ArrayList<String>()); Prefs.putList("hidden", new ArrayList<String>()); reloadApps(); }
    ArrayList<App> allApps() { ArrayList<App> l = new ArrayList<>(apps); l.addAll(dock); Collections.sort(l, (x, y) -> x.name.compareToIgnoreCase(y.name)); return l; }
    ArrayList<App> hiddenApps() { ArrayList<App> l = new ArrayList<>(); for (App a : apps) if (a.removed) l.add(a); return l; }
    void unhide(App a) { a.removed = false; layoutApps(false); saveState(); invalidate(); }
    void hideApp(App a) { a.removed = true; layoutApps(false); saveState(); invalidate(); }

    // ---------------------------------------------------------------- icons
    void ensureIcon(App a) { if (a.icon == null) a.icon = AppIcon.make(a.raw, Prefs.corner); }

    void drawIcon(Canvas c, App a, float x, float y, float s) {
        if (a.id != null && Prefs.ios) { Icons.draw(c, a.id, x, y, s); return; }
        ensureIcon(a); c.drawBitmap(a.icon, null, new RectF(x, y, x + s, y + s), bp);
    }

    Bitmap iconBitmap(App a, int size) {
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        drawIcon(new Canvas(b), a, 0, 0, size);
        return b;
    }

    int avgColor(App a) { if (!a.avgSet) { a.avg = AppIcon.avg(iconBitmap(a, 32)); a.avgSet = true; } return a.avg; }

    // ---------------------------------------------------------------- layout
    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { W = w; H = h; reloadWallpaper(); measure(); }

    void reloadWallpaper() {
        if (W <= 0) return;
        wp = Ui.wallpaper(W, H);
        wpBlur = Prefs.dockBlur > 0 ? blur(wp, Prefs.dockBlur) : wp;
        invalidate();
    }

    void applyPrefs(boolean heavy) {
        for (App a : apps) a.icon = null;
        for (App a : dock) a.icon = null;
        if (heavy) reloadWallpaper();
        measure(); syncW(); invalidate();
    }

    void measure() {
        if (W <= 0) return;
        label = Prefs.labels ? Ui.dp(LABEL_DP) : 0;
        gridTop = Ui.dp(30);
        dockSz = Math.min(Ui.dp(64) * Prefs.dockScale, W / (Math.max(dock.size(), 6) + 4f));
        dockBottom = H - Ui.dp(10); dockTop = dockBottom - (dockSz + Ui.dp(20));
        float gridBottom = dockTop - Ui.dp(26);
        cellW = W / (float) Prefs.cols; cellH = (gridBottom - gridTop) / Prefs.rows;
        iconSz = Math.min(Math.min(cellW * 0.58f, (cellH - label) * 0.82f) * Prefs.iconScale, cellW * 0.92f);
        vPad = Math.max(0, (cellH - iconSz - label) / 2); hPad = (cellW - iconSz) / 2;
        widgetTop = Ui.dp(60);
        wRect(wWeather, 0, 0, 3, 2); wRect(wCal, 3, 0, 2, 2); wRect(wBat, 5, 0, Math.max(1, Prefs.cols - 5), 1);
        addBtn.set(W / 2f - Ui.dp(75), Ui.dp(16), W / 2f + Ui.dp(75), Ui.dp(46));
        doneBtn.set(W - Ui.dp(92), Ui.dp(38), W - Ui.dp(16), Ui.dp(68));
        layoutDock(true); layoutApps(true);
        if (widgets != null) widgets.layout();
    }

    void wRect(RectF r, int col, int row, int cw, int ch) {
        r.set(col * cellW + hPad, gridTop + row * cellH + vPad, (col + cw) * cellW - hPad, gridTop + (row + ch) * cellH - vPad - label);
    }

    RectF widgetRect(int r, int c, int cw, int ch) {
        float m = Ui.dp(6);
        return new RectF(c * cellW + m, widgetTop + r * cellH + m, (c + cw) * cellW - m, widgetTop + (r + ch) * cellH - m);
    }
    int widgetRows() { return Math.max(2, (int) ((dockTop - Ui.dp(26) - widgetTop) / cellH)); }

    void layoutDock(boolean snapNow) {
        int n = dock.size(); float gap = dockSz * 0.28f, total = n * dockSz + Math.max(0, n - 1) * gap, x0 = (W - total) / 2, tw = Math.max(total, dockSz * 2);
        for (int i = 0; i < n; i++) {
            App a = dock.get(i); a.sz = dockSz; a.dock = true; a.tcx = x0 + i * (dockSz + gap) + dockSz / 2; a.ttop = dockTop + Ui.dp(10);
            if (snapNow) { a.cx = a.tcx; a.top = a.ttop; }
        }
        dockRect.set((W - tw) / 2 - Ui.dp(16), dockTop, (W + tw) / 2 + Ui.dp(16), dockBottom);
    }

    boolean reserved(int r, int c) { return (r < 2 && c < 5) || (r == 0 && c >= 5); }

    void layoutApps(boolean snapNow) {
        int cols = Prefs.cols, rows = Prefs.rows, n = 0;
        for (App a : apps) if (!a.removed) n++;
        slots.clear();
        int pg = 1;
        do {
            for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) { if (pg == 1 && builtinOn() && reserved(r, c)) continue; slots.add(new int[]{pg, r, c}); }
            pg++;
        } while (slots.size() < n);
        pages = Math.max(2, pg);
        int i = 0;
        for (App a : apps) {
            if (a.removed) continue;
            int[] s = slots.get(i++);
            a.dock = false; a.page = s[0]; a.sz = iconSz; a.tcx = s[2] * cellW + cellW / 2; a.ttop = gridTop + s[1] * cellH + vPad;
            if (snapNow) { a.cx = a.tcx; a.top = a.ttop; }
        }
        if (pageF > pages - 1) pageF = pages - 1;
    }

    RectF screenRect(App a) {
        float sh = a.dock ? 0 : (a.page - pageF) * W;
        return new RectF(a.cx - a.sz / 2 + sh, a.top, a.cx + a.sz / 2 + sh, a.top + a.sz);
    }

    App hit(float x, float y) {
        for (App a : dock) { RectF r = screenRect(a); r.inset(-Ui.dp(6), -Ui.dp(6)); if (r.contains(x, y)) return a; }
        int pg = Math.round(pageF);
        if (pg < 1) return null;
        for (App a : apps) {
            if (a.removed || a.page != pg) continue;
            RectF r = screenRect(a); r.inset(-Ui.dp(6), -Ui.dp(4)); r.bottom += label;
            if (r.contains(x, y)) return a;
        }
        return null;
    }

    // ---------------------------------------------------------------- drawing
    @Override protected void onDraw(Canvas c) {
        if (wp == null) return;
        long now = SystemClock.uptimeMillis();
        if (Ui.gfx) lastAnim = render(c, now, true);
        else {
            if (lagBmp == null || lagBmp.getWidth() != W || lagBmp.getHeight() != H) { lagBmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888); lagCv = new Canvas(lagBmp); nextFrame = 0; }
            if (now >= nextFrame) {
                lagBmp.eraseColor(0); fakeFps = 3 + (int) (Math.random() * 10);
                lastAnim = render(lagCv, now, true);
                nextFrame = now + 90 + (long) (Math.random() * 280);
            }
            c.drawBitmap(lagBmp, 0, 0, null);
        }
        if (lastAnim) { if (Ui.gfx) postInvalidateOnAnimation(); else postInvalidateDelayed(24); }
    }

    boolean render(Canvas c, long now, boolean overlays) {
        if (now / 1000 != lastSec) { lastSec = now / 1000; Icons.calDay = Ui.fmt("EEEE"); Icons.calNum = Ui.fmt("d"); }
        boolean anim = jiggle || !Ui.gfx || dragApp != null || (pageAnim != null && pageAnim.isRunning()) || (openAnim != null && openAnim.isRunning())
                || (menuAnim != null && menuAnim.isRunning()) || (ccAnim != null && ccAnim.isRunning());
        float tc = Math.max(0, openT);
        c.save();
        float s = 1 + 0.07f * Math.min(1, tc);
        c.scale(s, s, W / 2f, H / 2f);
        if (drawHomeBody(c, now)) anim = true;
        if (tc > 0.001f && snap != null) {
            bp.setAlpha((int) (255 * Math.min(1f, tc * 1.6f))); c.drawBitmap(snap, null, new RectF(0, 0, W, H), bp); bp.setAlpha(255);
            fp.setColor(Color.argb((int) (70 * Math.min(1f, tc)), 0, 0, 0)); c.drawRect(0, 0, W, H, fp);
        }
        if (menuOn) { drawMenu(c); anim = true; }
        c.restore();
        if (dragApp != null) { float sz = dragApp.sz * 1.12f; drawIcon(c, dragApp, dragX - sz / 2, dragY - sz / 2, sz); }
        if (tc > 0.001f && openApp != null) drawWindow(c);
        if (overlays) {
            if (ccT > 0.001f && ccSnap != null && drawCC(c)) anim = true;
            if (brightness < 0.99f) { fp.setColor(Color.argb((int) ((1 - brightness) * 150), 0, 0, 0)); c.drawRect(0, 0, W, H, fp); }
            if (!Ui.gfx) c.drawText("FPS: " + fakeFps, W / 2f, Ui.dp(21), Ui.tx(0xFFFFFFFF, 11.5f, Ui.MED, Paint.Align.CENTER));
        }
        return anim;
    }

    boolean drawHomeBody(Canvas c, long now) {
        boolean anim = jiggle || dragApp != null || (pageAnim != null && pageAnim.isRunning());
        if (Ui.gfx) {
            float off = (Prefs.parallax && pages > 1) ? (0.5f - pageF / (pages - 1)) * Ui.dp(56) : 0;
            wpr.set(off - Ui.dp(30), 0, W + Ui.dp(30) + off, H);
            c.drawBitmap(wp, null, wpr, bp); c.drawColor(Color.argb(Prefs.wpDim, 0, 0, 0));
        } else c.drawColor(0xFF000000);
        Ui.statusBar(c, W, true, 0xFFFFFFFF);
        int sv = c.save();
        for (int pg = 0; pg < pages; pg++) {
            float x = (pg - pageF) * W;
            if (Math.abs(x) >= W) continue;
            c.save(); c.translate(x, 0);
            if (pg == 0) drawWidgetPage(c);
            else {
                if (pg == 1 && builtinOn()) { drawWeather(c, wWeather); drawCalendar(c, wCal); drawBattery(c, wBat); }
                for (App a : apps) if (a.page == pg && !a.removed && a != menuApp && a != dragApp) { if (drawApp(c, a, now, true)) anim = true; }
            }
            c.restore();
        }
        for (int i = 0; i < pages; i++) {
            Paint d = Ui.p(0xFFFFFFFF); d.setAlpha(Math.abs(i - pageF) < 0.5f ? 255 : 110);
            c.drawCircle(W / 2f + (i - (pages - 1) / 2f) * Ui.dp(14), dockTop - Ui.dp(12), Ui.dp(3.2f), d);
        }
        float dr = Ui.dp(Prefs.dockRadius);
        if (Ui.gfx) {
            Path dpp = new Path(); dpp.addRoundRect(dockRect, dr, dr, Path.Direction.CW);
            c.save(); c.clipPath(dpp);
            if (Prefs.dockBlur > 0) c.drawBitmap(wpBlur, null, wpr, bp);
            fp.setColor(Color.argb(Prefs.wpDim, 0, 0, 0)); c.drawRect(dockRect, fp);
            fp.setColor(Color.argb(Prefs.dockTint, 255, 255, 255)); c.drawRect(dockRect, fp); c.restore();
        } else { fp.setColor(0xFF141414); c.drawRoundRect(dockRect, dr, dr, fp); }
        fp.setStyle(Paint.Style.STROKE); fp.setStrokeWidth(Ui.dp(0.6f)); fp.setColor(0x33FFFFFF); c.drawRoundRect(dockRect, dr, dr, fp); fp.setStyle(Paint.Style.FILL);
        for (App a : dock) if (a != menuApp && a != dragApp) { if (drawApp(c, a, now, false)) anim = true; }
        if (jiggle) {
            fp.setColor(0x66000000); c.drawRoundRect(doneBtn, Ui.dp(16), Ui.dp(16), fp);
            c.drawText("Done", doneBtn.centerX(), doneBtn.centerY() + Ui.dp(5), Ui.tx(0xFFFFFFFF, 15, Ui.MED, Paint.Align.CENTER));
        }
        c.restoreToCount(sv);
        return anim;
    }

    void drawWidgetPage(Canvas c) {
        fp.setColor(0x38000000); c.drawRoundRect(addBtn, Ui.dp(15), Ui.dp(15), fp);
        SvgIcons.draw(c, SvgIcons.PLUS, addBtn.left + Ui.dp(22), addBtn.centerY(), Ui.dp(15), 0xFFFFFFFF, 2.2f);
        c.drawText("Add Widget", addBtn.centerX() + Ui.dp(10), addBtn.centerY() + Ui.dp(5), Ui.tx(0xFFFFFFFF, 14, Ui.MED, Paint.Align.CENTER));
        if (widgets == null || widgets.list.isEmpty())
            c.drawText("Widgets from your apps appear here", W / 2f, H * 0.42f, Ui.tx(0xCCFFFFFF, 15, Ui.REG, Paint.Align.CENTER));
    }

    static Bitmap blur(Bitmap src, int n) {
        Bitmap cur = src;
        for (int i = 0; i < n; i++) cur = Bitmap.createScaledBitmap(cur, Math.max(2, cur.getWidth() / 2), Math.max(2, cur.getHeight() / 2), true);
        for (int i = 0; i < n; i++) cur = Bitmap.createScaledBitmap(cur, cur.getWidth() * 2, cur.getHeight() * 2, true);
        return cur;
    }

    void captureSnap() {
        if (W <= 0) return;
        Bitmap b = Bitmap.createBitmap(Math.max(2, W / 4), Math.max(2, H / 4), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b); cv.scale(b.getWidth() / (float) W, b.getHeight() / (float) H);
        capturing = true; drawHomeBody(cv, SystemClock.uptimeMillis()); capturing = false;
        snap = blur(b, 3);
    }

    boolean drawApp(Canvas c, App a, long now, boolean labels) {
        if (a == openApp && (openT > 0.001f || capturing)) return false;
        boolean busy = false;
        if (Math.abs(a.cx - a.tcx) > 0.4f) { a.cx += (a.tcx - a.cx) * 0.3f; busy = true; } else a.cx = a.tcx;
        if (Math.abs(a.top - a.ttop) > 0.4f) { a.top += (a.ttop - a.top) * 0.3f; busy = true; } else a.top = a.ttop;
        float target = (a == pressed && !moved && openApp == null && !menuOn) ? 0.9f : 1f;
        if (Math.abs(a.press - target) > 0.002f) { a.press += (target - a.press) * 0.35f; busy = true; }
        float rot = (jiggle && Prefs.jiggle) ? (float) Math.sin(now / 62.0 + a.phase) * 1.7f : 0;
        float cx = a.cx, cy = a.top + a.sz / 2, rr = a.sz * Prefs.corner / 100f;
        c.save(); c.scale(a.press, a.press, cx, cy); if (rot != 0) c.rotate(rot, cx, cy);
        drawIcon(c, a, cx - a.sz / 2, a.top, a.sz);
        if (a.press < 0.995f) { fp.setColor(Color.argb((int) ((1 - a.press) * 380), 0, 0, 0)); c.drawRoundRect(cx - a.sz / 2, a.top, cx + a.sz / 2, a.top + a.sz, rr, rr, fp); }
        if (jiggle && !a.dock) {
            fp.setColor(0xFFB8B8BE); c.drawCircle(cx - a.sz / 2 + Ui.dp(2), a.top + Ui.dp(2), Ui.dp(9), fp);
            fp.setColor(0xFF2C2C2E); c.drawRoundRect(cx - a.sz / 2 - Ui.dp(2.5f), a.top + Ui.dp(0.9f), cx - a.sz / 2 + Ui.dp(6.5f), a.top + Ui.dp(3.1f), Ui.dp(1), Ui.dp(1), fp);
        }
        c.restore();
        if (labels && Prefs.labels) {
            Paint lt = Ui.tx(Prefs.labelColor, Prefs.labelSize, Ui.REG, Paint.Align.CENTER); float mw = lt.measureText(a.name), mx = cellW - Ui.dp(8);
            if (mw > mx) lt.setTextSize(lt.getTextSize() * mx / mw);
            if (Ui.gfx) lt.setShadowLayer(Ui.dp(2.5f), 0, Ui.dp(1), 0x66000000);
            c.drawText(a.name, cx, a.top + a.sz + Ui.dp(3 + Prefs.labelSize), lt);
            lt.clearShadowLayer();
        }
        return busy;
    }

    void card(Canvas c, RectF r, int col) { fp.setStyle(Paint.Style.FILL); fp.setColor(col); c.drawRoundRect(r, Ui.dp(22), Ui.dp(22), fp); }
    void txt(Canvas c, String s, float x, float y, int col, float sz, Typeface f, Paint.Align al) { c.drawText(s, x, y, Ui.tx(col, sz, f, al)); }

    void drawLoading(Canvas c, RectF r) {
        card(c, r, 0xFF0F0F0F);
        fp.setColor(0xFF262626);
        c.drawRoundRect(r.left + Ui.dp(16), r.top + Ui.dp(16), r.left + r.width() * 0.45f, r.top + Ui.dp(28), Ui.dp(6), Ui.dp(6), fp);
        c.drawRoundRect(r.left + Ui.dp(16), r.top + Ui.dp(36), r.left + r.width() * 0.3f, r.top + Ui.dp(46), Ui.dp(5), Ui.dp(5), fp);
        float cx = r.centerX(), cy = r.centerY() + Ui.dp(8), rr = Math.min(Ui.dp(11), r.height() * 0.16f);
        Paint sp = Ui.p(0xFFFF2B2B); sp.setStyle(Paint.Style.STROKE); sp.setStrokeWidth(Ui.dp(2.2f)); sp.setStrokeCap(Paint.Cap.ROUND);
        float ang = (SystemClock.uptimeMillis() % 900) / 900f * 360f;
        c.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, ang, 100, false, sp);
        if (r.height() > Ui.dp(70)) txt(c, "Loading\u2026", cx, cy + rr + Ui.dp(18), 0xFFFFFFFF, 12, Ui.REG, Paint.Align.CENTER);
    }

    void drawWeather(Canvas c, RectF r) {
        if (!Ui.gfx) { drawLoading(c, r); return; }
        card(c, r, 0xD91C1C1E);
        float u = Math.max(0.5f, Math.min(r.height() / Ui.dp(160), r.width() / Ui.dp(300))), x = r.left + Ui.dp(16) * u, y = r.top;
        txt(c, "Cupertino", x, y + Ui.dp(26) * u, 0xFFFFFFFF, 15 * u, Ui.BOLD, Paint.Align.LEFT);
        txt(c, "72\u00B0", x, y + Ui.dp(72) * u, 0xFFFFFFFF, 44 * u, Ui.LIGHT, Paint.Align.LEFT);
        fp.setColor(0xFFFFCC00); c.drawCircle(r.right - Ui.dp(38) * u, y + Ui.dp(34) * u, Ui.dp(11) * u, fp);
        txt(c, "Sunny", r.right - Ui.dp(16) * u, y + Ui.dp(64) * u, 0xFFFFFFFF, 13 * u, Ui.MED, Paint.Align.RIGHT);
        txt(c, "H:78\u00B0  L:61\u00B0", r.right - Ui.dp(16) * u, y + Ui.dp(82) * u, 0xCCFFFFFF, 12 * u, Ui.REG, Paint.Align.RIGHT);
        String[] t = {"Now", "10 AM", "11 AM", "12 PM", "1 PM"}; int[] d = {72, 74, 76, 77, 77};
        float cw = (r.width() - Ui.dp(32) * u) / 5;
        for (int i = 0; i < 5; i++) {
            float cx = x + cw * i + cw / 2;
            txt(c, t[i], cx, y + Ui.dp(116) * u, 0xCCFFFFFF, 11 * u, Ui.MED, Paint.Align.CENTER);
            fp.setColor(0xFFFFCC00); c.drawCircle(cx, y + Ui.dp(130) * u, Ui.dp(5.5f) * u, fp);
            txt(c, d[i] + "\u00B0", cx, y + Ui.dp(150) * u, 0xFFFFFFFF, 12.5f * u, Ui.MED, Paint.Align.CENTER);
        }
    }

    void drawCalendar(Canvas c, RectF r) {
        if (!Ui.gfx) { drawLoading(c, r); return; }
        card(c, r, 0xD91C1C1E);
        float u = Math.max(0.5f, Math.min(r.height() / Ui.dp(160), r.width() / Ui.dp(160))), x = r.left + Ui.dp(14) * u;
        txt(c, Ui.fmt("EEEE").toUpperCase(), x, r.top + Ui.dp(26) * u, 0xFFFF453A, 12 * u, Ui.BOLD, Paint.Align.LEFT);
        txt(c, Ui.fmt("d"), x, r.top + Ui.dp(70) * u, 0xFFFFFFFF, 44 * u, Ui.LIGHT, Paint.Align.LEFT);
        String[] ev = {"Design review", "Lunch with Marcel", "Timesheet deadline"}; String[] tm = {"10:30 AM", "12:00 PM", "5:00 PM"};
        int[] col = {0xFF0A84FF, 0xFF30D158, 0xFFFF9F0A};
        for (int i = 0; i < 3; i++) {
            float y = r.top + Ui.dp(92) * u + i * Ui.dp(22) * u;
            fp.setColor(col[i]); c.drawRoundRect(x, y - Ui.dp(11) * u, x + Ui.dp(3) * u, y + Ui.dp(7) * u, 2, 2, fp);
            txt(c, ev[i], x + Ui.dp(9) * u, y - Ui.dp(1) * u, 0xFFFFFFFF, 11 * u, Ui.MED, Paint.Align.LEFT);
            txt(c, tm[i], x + Ui.dp(9) * u, y + Ui.dp(8) * u, 0x99FFFFFF, 9 * u, Ui.REG, Paint.Align.LEFT);
        }
    }

    void drawBattery(Canvas c, RectF r) {
        if (!Ui.gfx) { drawLoading(c, r); return; }
        card(c, r, 0xD91C1C1E);
        float rad = r.height() * 0.3f;
        for (int i = 0; i < 2; i++) {
            float cx = r.left + r.width() * (0.28f + 0.44f * i), cy = r.centerY();
            Ui.ring(c, cx, cy, rad, 1f, i == 0 ? 0xFF30D158 : 0xFF30D158, 3.4f);
            Icons.fill(0xFFFFFFFF);
            c.drawRoundRect(cx - rad * 0.3f, cy - rad * 0.45f, cx + rad * 0.3f, cy + rad * 0.45f, 3, 3, Icons.P);
        }
    }

    // ---------------------------------------------------------------- context menu
    static boolean has(String s, String... k) { for (String x : k) if (s.contains(x)) return true; return false; }

    static int iconFor(String s) {
        s = s.toLowerCase(Locale.ROOT);
        if (has(s, "photo", "camera", "selfie", "scan", "picture")) return SvgIcons.CAMERA;
        if (has(s, "search", "find", "discover")) return SvgIcons.SEARCH;
        if (has(s, "todo", "to-do", "task", "check", "remind", "list")) return SvgIcons.CHECKBOX;
        if (has(s, "video", "record", "film", "movie")) return SvgIcons.VIDEO;
        if (has(s, "mail", "email", "inbox")) return SvgIcons.MAIL;
        if (has(s, "call", "dial", "phone")) return SvgIcons.CALL;
        if (has(s, "tab", "window", "incognito", "private")) return SvgIcons.TABS;
        if (has(s, "contact", "person", "friend", "profile", "account")) return SvgIcons.PERSON;
        if (has(s, "map", "location", "navigate", "direction", "place")) return SvgIcons.PIN;
        if (has(s, "note", "compose", "write", "edit", "draft", "message", "chat", "text")) return SvgIcons.PENCIL;
        if (has(s, "setting")) return SvgIcons.GEAR;
        if (has(s, "new", "add", "create")) return SvgIcons.PLUS;
        return SvgIcons.ARROW_UR;
    }

    List<Object> shortcuts(App a) {
        ArrayList<Object> out = new ArrayList<>();
        if (Build.VERSION.SDK_INT < 25) return out;
        try {
            LauncherApps la = (LauncherApps) getContext().getSystemService(Context.LAUNCHER_APPS_SERVICE);
            if (!la.hasShortcutHostPermission()) return out;
            LauncherApps.ShortcutQuery q = new LauncherApps.ShortcutQuery();
            q.setPackage(a.pkg);
            q.setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC | LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST | LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED);
            List<ShortcutInfo> l = la.getShortcuts(q, Process.myUserHandle());
            if (l == null) return out;
            ArrayList<ShortcutInfo> sorted = new ArrayList<>(l);
            Collections.sort(sorted, (x, y) -> x.getRank() - y.getRank());
            for (ShortcutInfo s : sorted) if (s.isEnabled() && s.getShortLabel() != null && out.size() < 4) out.add(s);
        } catch (Throwable ignored) { }
        return out;
    }

    void showMenu(App a) {
        menuApp = a;
        ArrayList<String> L = new ArrayList<>(); ArrayList<Integer> I = new ArrayList<>(), A = new ArrayList<>();
        L.add("Remove App"); I.add(SvgIcons.MINUS); A.add(A_REMOVE);
        L.add("Share App"); I.add(SvgIcons.SHARE); A.add(A_SHARE);
        L.add("Edit Home Screen"); I.add(SvgIcons.PHONE); A.add(A_EDIT);
        menuSc = shortcuts(a);
        if (!menuSc.isEmpty()) {
            for (int k = 0; k < menuSc.size(); k++) { String lb = ((ShortcutInfo) menuSc.get(k)).getShortLabel().toString(); L.add(lb); I.add(iconFor(lb)); A.add(100 + k); }
        } else { L.add("Open"); I.add(SvgIcons.ARROW_UR); A.add(A_OPEN); L.add("App Info"); I.add(SvgIcons.INFO); A.add(A_INFO); }
        openMenu(screenRect(a), label + Ui.dp(6), L, I, A, 3);
    }

    void showHomeMenu(float x, float y) {
        menuApp = null;
        ArrayList<String> L = new ArrayList<>(); ArrayList<Integer> I = new ArrayList<>(), A = new ArrayList<>();
        L.add("Edit Home Screen"); I.add(SvgIcons.PHONE); A.add(A_EDIT);
        L.add("Add Widget"); I.add(SvgIcons.WIDGET); A.add(A_WIDGET);
        L.add("Wallpaper"); I.add(SvgIcons.IMAGE); A.add(A_WALL);
        L.add("Launcher Settings"); I.add(SvgIcons.SLIDERS); A.add(A_SETTINGS);
        openMenu(new RectF(x, y, x, y), Ui.dp(6), L, I, A, 3);
    }

    void openMenu(RectF anchor, float extra, ArrayList<String> L, ArrayList<Integer> I, ArrayList<Integer> A, int sep) {
        captureSnap();
        int n = L.size();
        menuLabels = L.toArray(new String[0]); menuIco = new int[n]; menuAct = new int[n];
        for (int i = 0; i < n; i++) { menuIco[i] = I.get(i); menuAct[i] = A.get(i); }
        menuSep = sep < n ? sep : -1; menuOn = true; menuAnchor.set(anchor);
        float w = Ui.dp(250), h = ROW * Ui.d * n + (menuSep >= 0 ? SEP * Ui.d : 0);
        float l = Math.max(Ui.dp(12), Math.min(anchor.left, W - w - Ui.dp(12)));
        float t = anchor.bottom + extra;
        if (t + h > H - Ui.dp(12)) t = Math.max(Ui.dp(12), anchor.top - h - Ui.dp(10));
        menuRect.set(l, t, l + w, t + h);
        menuAnim(0, 1, 280); syncW();
    }

    void menuAnim(float from, float to, int ms) {
        if (menuAnim != null) menuAnim.cancel();
        menuAnim = ValueAnimator.ofFloat(from, to); menuAnim.setDuration(ms); menuAnim.setInterpolator(new DecelerateInterpolator(1.6f));
        menuAnim.addUpdateListener(v -> { menuT = (float) v.getAnimatedValue(); invalidate(); });
        if (to == 0) menuAnim.addListener(new AnimatorListenerAdapter() { boolean cn; @Override public void onAnimationCancel(Animator an) { cn = true; }
            @Override public void onAnimationEnd(Animator an) { if (!cn) { menuOn = false; menuApp = null; syncW(); invalidate(); } } });
        menuAnim.start();
    }

    void drawMenu(Canvas c) {
        if (snap != null) { bp.setAlpha((int) (255 * menuT)); c.drawBitmap(snap, null, new RectF(0, 0, W, H), bp); bp.setAlpha(255); }
        fp.setColor(Color.argb((int) (70 * menuT), 0, 0, 0)); c.drawRect(0, 0, W, H, fp);
        if (menuApp != null) {
            App a = menuApp; RectF r = screenRect(a);
            c.save(); float s = 1 + 0.08f * menuT; c.scale(s, s, r.centerX(), r.centerY()); drawIcon(c, a, r.left, r.top, r.width()); c.restore();
        }
        c.save();
        float sc = Ui.lerp(0.5f, 1f, menuT);
        c.scale(sc, sc, menuAnchor.centerX() < W / 2f ? menuRect.left : menuRect.right, menuRect.top < menuAnchor.top ? menuRect.bottom : menuRect.top);
        c.saveLayerAlpha(menuRect.left - 4, menuRect.top - 4, menuRect.right + 4, menuRect.bottom + 4, (int) (255 * Math.min(1, menuT * 1.4f)));
        Path mp = new Path(); mp.addRoundRect(menuRect, Ui.dp(16), Ui.dp(16), Path.Direction.CW);
        c.save(); c.clipPath(mp);
        if (snap != null) c.drawBitmap(snap, null, new RectF(0, 0, W, H), bp);
        fp.setColor(0xCCEDEDF4); c.drawRect(menuRect, fp);
        float rh = Ui.dp(ROW), y = menuRect.top;
        for (int i = 0; i < menuLabels.length; i++) {
            if (i == menuSep) { fp.setColor(0xFFD0D0D8); c.drawRect(menuRect.left, y, menuRect.right, y + Ui.dp(SEP), fp); y += Ui.dp(SEP); }
            int col = menuAct[i] == A_REMOVE ? 0xFFFF3B30 : 0xFF1C1C1E;
            Paint tp = Ui.tx(col, 16.5f, Ui.REG, Paint.Align.LEFT); float mx = menuRect.width() - Ui.dp(64), mw = tp.measureText(menuLabels[i]);
            if (mw > mx) tp.setTextSize(tp.getTextSize() * mx / mw);
            c.drawText(menuLabels[i], menuRect.left + Ui.dp(16), y + rh / 2 + Ui.dp(5.5f), tp);
            SvgIcons.draw(c, menuIco[i], menuRect.right - Ui.dp(26), y + rh / 2, Ui.dp(20), col, 1.6f);
            if (i != menuLabels.length - 1 && i + 1 != menuSep) { fp.setColor(0x1F000000); c.drawRect(menuRect.left, y + rh - 1, menuRect.right, y + rh, fp); }
            y += rh;
        }
        c.restore(); c.restore(); c.restore();
    }

    void menuTap(float x, float y) {
        if (!menuRect.contains(x, y)) { menuAnim(menuT, 0, 160); return; }
        float rh = Ui.dp(ROW), yy = menuRect.top; int idx = -1;
        for (int i = 0; i < menuLabels.length; i++) {
            if (i == menuSep) yy += Ui.dp(SEP);
            if (y >= yy && y < yy + rh) { idx = i; break; }
            yy += rh;
        }
        if (idx < 0) return;
        int act = menuAct[idx]; App a = menuApp;
        if (act >= 100 || act == A_OPEN) {
            Object sc = act >= 100 ? menuSc.get(act - 100) : null;
            ir = screenRect(a); openApp = a; pendingSc = sc; menuOn = false; menuApp = null; menuT = 0; animateOpen(true); return;
        }
        menuAnim(menuT, 0, 160);
        switch (act) {
            case A_REMOVE: removeApp(a); break;
            case A_SHARE: shareApp(a); break;
            case A_EDIT: setJiggle(true); break;
            case A_INFO: try { Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i); } catch (Exception ignored) { } break;
            case A_WIDGET: if (widgets != null) { pageAnim(0); widgets.pick(); } break;
            case A_WALL: host.pickWallpaper(); break;
            case A_SETTINGS: host.openSettings(); break;
        }
    }

    void removeApp(App a) {
        boolean sys = true;
        try { sys = (getContext().getPackageManager().getApplicationInfo(a.pkg, 0).flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0; } catch (Exception ignored) { }
        if (!sys) { try { Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i); return; } catch (Exception ignored) { } }
        if (a.dock) { dock.remove(a); apps.add(a); layoutDock(false); layoutApps(false); saveState(); } else hideApp(a);
        Toast.makeText(getContext(), sys ? a.name + " hidden (restore in Launcher Settings)" : "", Toast.LENGTH_SHORT).show();
    }

    void shareApp(App a) {
        try {
            Intent s = new Intent(Intent.ACTION_SEND); s.setType("text/plain"); s.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + a.pkg);
            getContext().startActivity(Intent.createChooser(s, "Share " + a.name));
        } catch (Exception ignored) { }
    }

    // ---------------------------------------------------------------- app window (open / close)
    void drawWindow(Canvas c) {
        float t = openT, tc = Math.min(1f, Math.max(0f, t));
        float l = Ui.lerp(ir.left, 0, t), tp = Ui.lerp(ir.top, 0, t), r = Ui.lerp(ir.right, W, t), b = Ui.lerp(ir.bottom, H, t);
        float rad = Ui.lerp(ir.width() * Prefs.corner / 100f, Ui.dp(26), Math.min(1f, tc * 1.15f));
        Path clip = new Path(); clip.addRoundRect(l, tp, r, b, rad, rad, Path.Direction.CW);   // no drop shadow
        c.save(); c.clipPath(clip);
        fp.setColor(0xFF000000); c.drawRect(l, tp, r, b, fp);
        float ia = plainExit ? 1f : 1 - Ui.cl(tc / 0.34f); ia = ia * ia * (3 - 2 * ia);
        if (!plainExit) {   // opening: app content fades in as the icon fades out
            float k = Math.max((r - l) / W, (b - tp) / H);
            c.save(); c.translate((l + r) / 2, (tp + b) / 2); c.scale(k, k); c.translate(-W / 2f, -H / 2f);
            drawSkin(c, openApp); c.restore();
        }
        if (ia > 0) {   // closing: content vanishes instantly, only the icon shrinks back
            float sz = r - l;
            c.saveLayerAlpha(l, tp, r, b, (int) (255 * ia));
            drawIcon(c, openApp, l, (tp + b) / 2 - sz / 2, sz);
            c.restore();
        }
        c.restore();
    }

    void drawSkin(Canvas c, App a) {
        int bg = Prefs.splash == 1 ? 0xFF000000 : (Prefs.splash == 2 ? avgColor(a) : 0xFFF2F2F7);
        boolean dk = (Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000 < 140;
        c.drawColor(Ui.bg(bg));
        float s = Math.min(Ui.dp(96), H * 0.24f);
        drawIcon(c, a, W / 2f - s / 2, H * 0.42f - s / 2, s);
        txt(c, a.name, W / 2f, H * 0.42f + s / 2 + Ui.dp(40), dk ? 0xFFFFFFFF : 0xFF1C1C1E, 22, Ui.MED, Paint.Align.CENTER);
        Ui.statusBar(c, W, true, dk ? 0xFFFFFFFF : 0xFF000000);
    }

    int mix(int a, int b, float t) {
        return Color.argb(255, (int) Ui.lerp(Color.red(a), Color.red(b), t), (int) Ui.lerp(Color.green(a), Color.green(b), t), (int) Ui.lerp(Color.blue(a), Color.blue(b), t));
    }

    void animateOpen(boolean open) {
        if (!open && closingAnim && openAnim != null && openAnim.isRunning()) return;
        if (openAnim != null) openAnim.cancel();
        if (open) { launched = false; plainExit = false; closingAnim = false; if (openT < 0.01f) captureSnap(); }
        else { plainExit = true; closingAnim = true; if (openApp != null) { if (!openApp.dock) { pageF = openApp.page; syncW(); } ir = screenRect(openApp); } }
        final float from = openT, to = open ? 1f : 0f;
        openAnim = ValueAnimator.ofFloat(0, 1); openAnim.setDuration((long) ((open ? 820 : 700) / Prefs.speed)); openAnim.setInterpolator(new Ui.Smooth());
        openAnim.addUpdateListener(v -> {
            float f = (float) v.getAnimatedValue(); openT = Math.max(0f, from + (to - from) * f);
            if (open && !launched && f > 0.72f) { launched = true; launchPending(); }
            syncW(); invalidate();
        });
        openAnim.addListener(new AnimatorListenerAdapter() { boolean cn; @Override public void onAnimationCancel(Animator a) { cn = true; }
            @Override public void onAnimationEnd(Animator a) { if (cn) return; openT = to; if (!open) { openApp = null; pendingSc = null; closingAnim = false; } syncW(); invalidate(); } });
        openAnim.start();
    }

    void launchPending() {
        if (openApp == null) return;
        if (pendingSc != null) launchShortcut(pendingSc); else launch(openApp);
    }

    boolean launch(App a) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName(a.pkg, a.cls))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            getContext().startActivity(i, android.app.ActivityOptions.makeCustomAnimation(getContext(), 0, 0).toBundle());
            return true;
        } catch (Exception e) {
            Toast.makeText(getContext(), "Can't open " + a.name, Toast.LENGTH_SHORT).show();
            if (openApp != null) animateOpen(false);
            return false;
        }
    }

    void launchShortcut(Object sc) {
        try {
            if (Build.VERSION.SDK_INT >= 25) ((LauncherApps) getContext().getSystemService(Context.LAUNCHER_APPS_SERVICE)).startShortcut((ShortcutInfo) sc, null, null);
        } catch (Throwable t) { if (openApp != null) launch(openApp); }
    }

    /** Called when the launcher comes back to the front: play the close animation. */
    void onResumed() {
        if (openApp != null && launched && openT > 0.99f && (openAnim == null || !openAnim.isRunning())) animateOpen(false);
    }

    void goHome() {
        if (ccOpen) ccAnimate(false);
        if (menuOn) menuAnim(menuT, 0, 160);
        if (jiggle) setJiggle(false);
        dragApp = null;
        if (openApp != null) { if (launched && openT > 0.99f && (openAnim == null || !openAnim.isRunning())) animateOpen(false); }
        else if (Math.round(pageF) != 1) pageAnim(1);
    }

    boolean handleBack() {
        if (ccOpen) { ccAnimate(false); return true; }
        if (menuOn) { menuAnim(menuT, 0, 160); return true; }
        if (jiggle) { setJiggle(false); return true; }
        if (Math.round(pageF) != 1 && openApp == null) { pageAnim(1); return true; }
        return false;
    }

    void setJiggle(boolean v) { jiggle = v; if (v) hap(HapticFeedbackConstants.LONG_PRESS); if (widgets != null) widgets.refresh(); invalidate(); }
    void setPage(float v) { pageF = v; syncW(); invalidate(); }

    void pageAnim(int target) {
        if (pageAnim != null) pageAnim.cancel();
        pageAnim = ValueAnimator.ofFloat(pageF, target); pageAnim.setDuration((long) (460 / Prefs.speed)); pageAnim.setInterpolator(new Ui.Smooth());
        pageAnim.addUpdateListener(v -> setPage((float) v.getAnimatedValue()));
        pageAnim.start();
    }

    // ---------------------------------------------------------------- touch
    final Runnable lp = new Runnable() { public void run() {
        if (moved || openApp != null || menuOn || jiggle || dragApp != null) return;
        lpFired = true; hap(HapticFeedbackConstants.LONG_PRESS);
        if (pressed != null) showMenu(pressed); else if (Math.round(pageF) >= 1) showHomeMenu(downX, downY);
    } };

    final Runnable edgeFlip = new Runnable() { public void run() {
        edgePosted = false;
        if (dragApp == null) return;
        int pg = Math.round(pageF), np = dragX < Ui.dp(48) ? pg - 1 : (dragX > W - Ui.dp(48) ? pg + 1 : pg);
        if (np != pg && np >= 1 && np < pages) { pageAnim(np); edgePosted = true; postDelayed(this, 800); }
    } };

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        if (ccTouch(e)) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x; downY = y; moved = false; lpFired = false; pull = false;
                leftPend = Prefs.swipeLeft == 1 && !menuOn && y < Ui.dp(34) && x < W * 0.38f;
                if (vt != null) vt.recycle(); vt = VelocityTracker.obtain(); vt.addMovement(e);
                if (openApp != null || menuOn) return true;
                if (pageAnim != null) pageAnim.cancel();
                startPage = pageF; pressed = hit(x, y);
                if (!jiggle) postDelayed(lp, 450);
                invalidate(); return true;
            case MotionEvent.ACTION_MOVE: {
                vt.addMovement(e);
                float dx = x - downX, dy = y - downY;
                if (openApp != null || menuOn) return true;
                if (leftPend && dy > Ui.dp(40)) { leftPend = false; host.expandNotifications(); return true; }
                if (dragApp != null) {
                    dragX = x; dragY = y;
                    if (x < Ui.dp(40) || x > W - Ui.dp(40)) { if (!edgePosted) { edgePosted = true; postDelayed(edgeFlip, 600); } }
                    else { removeCallbacks(edgeFlip); edgePosted = false; }
                    invalidate(); return true;
                }
                if (jiggle && pressed != null && !moved && Math.hypot(dx, dy) > slop * 1.5f) {
                    dragApp = pressed; pressed = null; dragX = x; dragY = y; removeCallbacks(lp); hap(HapticFeedbackConstants.KEYBOARD_TAP); invalidate(); return true;
                }
                if (!moved && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) { moved = true; removeCallbacks(lp); pressed = null; }
                if (moved) {
                    float v = startPage - dx / W, mx = pages - 1;
                    if (v < 0) v *= 0.22f; else if (v > mx) v = mx + (v - mx) * 0.22f;
                    setPage(v);
                } else if (Math.abs(dy) > slop) {
                    removeCallbacks(lp);
                    if (Prefs.pull && !jiggle && !pull && dy > Ui.dp(90) && Math.abs(dx) < dy * 0.6f && y > Ui.dp(34) && Math.round(pageF) >= 1) { pull = true; pressed = null; host.openSearch(); }
                    else if (Math.abs(dy) > slop * 2) pressed = null;
                }
                return true;
            }
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: {
                vt.addMovement(e); vt.computeCurrentVelocity(1000);
                removeCallbacks(lp);
                boolean up = e.getActionMasked() == MotionEvent.ACTION_UP;
                float dx = x - downX; leftPend = false;
                if (openApp != null) return true;
                if (menuOn) { if (up) menuTap(x, y); return true; }
                if (dragApp != null) { finishDrag(); return true; }
                App p = pressed; pressed = null;
                if (moved) {
                    int target = Math.round(startPage);
                    if (Math.abs(dx) > W * 0.12f || Math.abs(vt.getXVelocity()) > 900) target += dx < 0 ? 1 : -1;
                    pageAnim(Math.max(0, Math.min(pages - 1, target)));
                } else if (up && !lpFired && !pull) {
                    if (Math.round(pageF) == 0 && addBtn.contains(x, y) && widgets != null) { widgets.pick(); }
                    else if (jiggle) {
                        if (doneBtn.contains(x, y)) setJiggle(false);
                        else if (p != null && !p.dock) { RectF r = screenRect(p); if (Math.hypot(x - (r.left + Ui.dp(2)), y - (r.top + Ui.dp(2))) < Ui.dp(20)) hideApp(p); }
                    } else if (p != null) { ir = screenRect(p); openApp = p; pendingSc = null; animateOpen(true); }
                }
                if (pageF != Math.round(pageF) && (pageAnim == null || !pageAnim.isRunning())) pageAnim(Math.round(pageF));
                invalidate(); return true;
            }
        }
        return true;
    }

    void finishDrag() {
        App a = dragApp; dragApp = null; removeCallbacks(edgeFlip); edgePosted = false;
        boolean wasDock = a.dock;
        if (dragY > dockTop - Ui.dp(14)) {
            int idx = 0; for (App d : dock) if (d != a && d.cx < dragX) idx++;
            if (dock.size() - (wasDock ? 1 : 0) < Prefs.dockMax) {
                if (wasDock) dock.remove(a); else apps.remove(a);
                dock.add(Math.min(idx, dock.size()), a); a.dock = true;
            }
        } else {
            int pg = Math.max(1, Math.round(pageF)), best = -1; float bd = Float.MAX_VALUE;
            for (int i = 0; i < slots.size(); i++) {
                int[] s = slots.get(i); if (s[0] != pg) continue;
                float sx = s[2] * cellW + cellW / 2, sy = gridTop + s[1] * cellH + vPad + iconSz / 2;
                float d = (float) Math.hypot(dragX - (sx + (pg - pageF) * W), dragY - sy);
                if (d < bd) { bd = d; best = i; }
            }
            if (wasDock) dock.remove(a); else apps.remove(a);
            a.dock = false;
            if (best < 0) best = Integer.MAX_VALUE;
            int cnt = 0, pos = apps.size();
            for (int i = 0; i < apps.size(); i++) { if (apps.get(i).removed) continue; if (cnt == best) { pos = i; break; } cnt++; }
            apps.add(pos, a);
        }
        layoutDock(false); layoutApps(false);
        if (a.dock) { a.cx = dragX; a.top = dragY - a.sz / 2; } else { a.cx = dragX - (a.page - pageF) * W; a.top = dragY - a.sz / 2; }
        saveState(); hap(HapticFeedbackConstants.KEYBOARD_TAP); invalidate();
    }

    // ---------------------------------------------------------------- Control Center
    RectF cell(float px, float py, float cs, float g, int col, int row, int cw, int ch) {
        float l = px + col * (cs + g), t = py + row * (cs + g);
        return new RectF(l, t, l + cw * cs + (cw - 1) * g, t + ch * cs + (ch - 1) * g);
    }

    void ccLayout() {
        float g = Ui.dp(12), cs = Math.min(Ui.dp(78), (H - Ui.dp(72) - 4 * g) / 5f);
        float pw = 4 * cs + 3 * g, ph = 5 * cs + 4 * g, px = W - pw - Ui.dp(18), py = Ui.dp(46);
        ccPanel.set(px, py, px + pw, py + ph);
        mConn = cell(px, py, cs, g, 0, 0, 2, 2); mMedia = cell(px, py, cs, g, 2, 0, 2, 2);
        for (int i = 0; i < 4; i++) {
            float qw = mConn.width() / 2, qh = mConn.height() / 2;
            tiles[i] = new RectF(mConn.left + (i % 2) * qw, mConn.top + (i / 2) * qh, mConn.left + (i % 2 + 1) * qw, mConn.top + (i / 2 + 1) * qh);
        }
        tiles[4] = cell(px, py, cs, g, 0, 2, 1, 1); tiles[5] = cell(px, py, cs, g, 1, 2, 1, 1); tiles[6] = cell(px, py, cs, g, 2, 2, 2, 1);
        sB = cell(px, py, cs, g, 0, 3, 1, 2); sV = cell(px, py, cs, g, 1, 3, 1, 2);
        tiles[7] = cell(px, py, cs, g, 2, 3, 1, 1); tiles[8] = cell(px, py, cs, g, 3, 3, 1, 1);
        tiles[9] = cell(px, py, cs, g, 2, 4, 1, 1); tiles[10] = cell(px, py, cs, g, 3, 4, 1, 1);
    }

    void captureCC() {
        if (W <= 0) return;
        Bitmap b = Bitmap.createBitmap(Math.max(2, W / 4), Math.max(2, H / 4), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b); cv.scale(b.getWidth() / (float) W, b.getHeight() / (float) H);
        render(cv, SystemClock.uptimeMillis(), false);
        ccSnap = blur(b, 3);
    }

    void ccAnimate(boolean open) {
        ccOpen = open;
        if (open && ccT < 0.01f) captureCC();
        if (ccAnim != null) ccAnim.cancel();
        final float from = ccT, to = open ? 1f : 0f;
        ccAnim = ValueAnimator.ofFloat(0, 1); ccAnim.setDuration(open ? 600 : 340);
        ccAnim.setInterpolator(open ? new Ui.Spring(8f, 7f) : new DecelerateInterpolator(1.6f));
        ccAnim.addUpdateListener(v -> { ccT = Math.max(0f, from + (to - from) * (float) v.getAnimatedValue()); syncW(); invalidate(); });
        ccAnim.addListener(new AnimatorListenerAdapter() { boolean cn; @Override public void onAnimationCancel(Animator a) { cn = true; }
            @Override public void onAnimationEnd(Animator a) { if (!cn) { ccT = to; invalidate(); } } });
        ccAnim.start();
    }

    void setSlider(float y) {
        RectF r = sliderDrag == 0 ? sB : sV;
        float v = Ui.cl(1 - (y - r.top) / r.height());
        if (sliderDrag == 0) brightness = Math.max(0.12f, v); else volume = v;
        invalidate();
    }

    boolean ccTouch(MotionEvent e) {
        float x = e.getX(), y = e.getY(); int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) {
            ccDown = false; sliderDrag = -1;
            if (ccOpen) {
                ccDown = true; downX = x; downY = y; ccLayout();
                if (sB.contains(x, y)) { sliderDrag = 0; setSlider(y); } else if (sV.contains(x, y)) { sliderDrag = 1; setSlider(y); }
                return true;
            }
            if (!menuOn && Prefs.cc && x > W * 0.62f && y < Ui.dp(34) && (openAnim == null || !openAnim.isRunning())) { ccPending = true; ccDrag = false; downX = x; downY = y; return true; }
            return false;
        }
        if (ccOpen && ccDown) {
            if (act == MotionEvent.ACTION_MOVE) {
                if (sliderDrag >= 0) setSlider(y); else if (y - downY < -Ui.dp(50)) { ccDown = false; ccAnimate(false); }
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                if (sliderDrag < 0 && act == MotionEvent.ACTION_UP && Math.abs(x - downX) < slop * 2 && Math.abs(y - downY) < slop * 2) ccTap(x, y);
                sliderDrag = -1; ccDown = false;
            }
            return true;
        }
        if (ccPending) {
            if (act == MotionEvent.ACTION_MOVE) {
                float dy = y - downY;
                if (!ccDrag && dy > slop) { ccDrag = true; if (ccAnim != null) ccAnim.cancel(); captureCC(); }
                if (ccDrag) { ccT = Ui.cl(dy / Ui.dp(230)); syncW(); invalidate(); }
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                boolean was = ccDrag; ccPending = false; ccDrag = false;
                if (was) ccAnimate(ccT > 0.3f && act == MotionEvent.ACTION_UP);
            }
            return true;
        }
        return false;
    }

    void ccTap(float x, float y) {
        ccLayout();
        if (!ccPanel.contains(x, y)) { ccAnimate(false); return; }
        for (int i = 0; i < tiles.length; i++) {
            if (tiles[i] != null && tiles[i].contains(x, y)) {
                hap(HapticFeedbackConstants.KEYBOARD_TAP);
                tileOn[i] = !tileOn[i];
                if (i == 0 && tileOn[0]) { tileOn[1] = false; tileOn[2] = false; tileOn[3] = false; }
                if ((i == 1 || i == 2 || i == 3) && tileOn[i]) tileOn[0] = false;
                invalidate(); return;
            }
        }
    }

    void modStart(Canvas c, RectF r, int idx) {
        float a = Ui.cl(ccT * 1.6f - idx * 0.07f), sc = Ui.lerp(0.9f, 1f, a);
        c.save(); c.scale(sc, sc, r.centerX(), r.centerY());
        c.saveLayerAlpha(r.left - 8, r.top - 8, r.right + 8, r.bottom + 8, (int) (255 * a));
    }
    void modEnd(Canvas c) { c.restore(); c.restore(); }

    void glass(Canvas c, RectF r, float rad) {
        Path p = new Path(); p.addRoundRect(r, rad, rad, Path.Direction.CW);
        c.save(); c.clipPath(p); c.drawBitmap(ccSnap, null, new RectF(0, 0, W, H), bp); fp.setColor(0x6640404A); c.drawRect(r, fp); c.restore();
    }

    boolean drawCC(Canvas c) {
        float t = ccT; boolean busy = false;
        ccLayout();
        bp.setAlpha((int) (255 * Math.min(1f, t * 1.3f))); c.drawBitmap(ccSnap, null, new RectF(0, 0, W, H), bp); bp.setAlpha(255);
        fp.setColor(Color.argb((int) (90 * Math.min(1f, t)), 0, 0, 0)); c.drawRect(0, 0, W, H, fp);
        c.save();
        c.translate(0, -Ui.dp(26) * (1 - Math.min(1f, t)));
        float ps = Ui.lerp(0.92f, 1f, Math.min(1f, t)); c.scale(ps, ps, ccPanel.right, ccPanel.top);
        float R = Ui.dp(22);
        // connectivity
        modStart(c, mConn, 0); glass(c, mConn, R);
        int[] oc = {0xFFFF9F0A, 0xFF30D158, 0xFF0A84FF, 0xFF0A84FF};
        for (int i = 0; i < 4; i++) {
            RectF q = tiles[i]; float rad = Math.min(q.width(), q.height()) / 2f - Ui.dp(5);
            tileT[i] += ((tileOn[i] ? 1f : 0f) - tileT[i]) * 0.28f; if (Math.abs((tileOn[i] ? 1f : 0f) - tileT[i]) > 0.01f) busy = true;
            fp.setColor(mix(0xFF303036, oc[i], tileT[i])); c.drawCircle(q.centerX(), q.centerY(), rad, fp);
            gl(c, i, q.centerX(), q.centerY(), rad * 1.05f, 0xFFFFFFFF);
        }
        modEnd(c);
        // media
        modStart(c, mMedia, 1); glass(c, mMedia, R);
        gl(c, 16, mMedia.left + Ui.dp(22), mMedia.top + Ui.dp(22), Ui.dp(18), 0xCCFFFFFF);
        gl(c, 6, mMedia.right - Ui.dp(22), mMedia.top + Ui.dp(22), Ui.dp(18), 0xCCFFFFFF);
        txt(c, "Not Playing", mMedia.centerX(), mMedia.centerY() - Ui.dp(2), 0xFFFFFFFF, 13.5f, Ui.MED, Paint.Align.CENTER);
        float my = mMedia.bottom - Ui.dp(26), mw = mMedia.width() / 4;
        gl(c, 13, mMedia.centerX() - mw, my, Ui.dp(20), 0xAAFFFFFF); gl(c, 14, mMedia.centerX(), my, Ui.dp(24), 0xFFFFFFFF); gl(c, 15, mMedia.centerX() + mw, my, Ui.dp(20), 0xAAFFFFFF);
        modEnd(c);
        // small tiles
        int[] gid = {4, 5, 6, 7, 8, 9, 10};
        int[] onc = {0xFFFF3B30, 0xFF5E5CE6, 0xFF0A84FF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF};
        for (int k = 0; k < 7; k++) {
            int i = 4 + k; RectF r = tiles[i];
            modStart(c, r, 2 + k); glass(c, r, R);
            tileT[i] += ((tileOn[i] ? 1f : 0f) - tileT[i]) * 0.28f; if (Math.abs((tileOn[i] ? 1f : 0f) - tileT[i]) > 0.01f) busy = true;
            if (tileT[i] > 0.01f) { fp.setColor((onc[k] & 0xFFFFFF) | ((int) (255 * Ui.cl(tileT[i])) << 24)); c.drawRoundRect(r, R, R, fp); }
            boolean light = onc[k] == 0xFFFFFFFF && tileT[i] > 0.5f;
            if (i == 6) {
                gl(c, 6, r.left + Ui.dp(30), r.centerY(), Ui.dp(24), 0xFFFFFFFF);
                txt(c, "Screen", r.left + Ui.dp(52), r.centerY() - Ui.dp(2), 0xFFFFFFFF, 12.5f, Ui.MED, Paint.Align.LEFT);
                txt(c, "Mirroring", r.left + Ui.dp(52), r.centerY() + Ui.dp(13), 0xFFFFFFFF, 12.5f, Ui.MED, Paint.Align.LEFT);
            } else gl(c, gid[k], r.centerX(), r.centerY(), Math.min(r.width(), r.height()) * 0.42f, light ? 0xFF1C1C1E : 0xFFFFFFFF);
            modEnd(c);
        }
        // sliders
        for (int k = 0; k < 2; k++) {
            RectF r = k == 0 ? sB : sV; float lv = k == 0 ? brightness : volume;
            modStart(c, r, 9 + k); glass(c, r, R);
            Path p = new Path(); p.addRoundRect(r, R, R, Path.Direction.CW);
            c.save(); c.clipPath(p);
            fp.setColor(0xF2FFFFFF); c.drawRect(r.left, r.bottom - r.height() * lv, r.right, r.bottom, fp);
            c.restore();
            gl(c, k == 0 ? 11 : 12, r.centerX(), r.bottom - Ui.dp(26), Ui.dp(24), lv > 0.16f ? 0xFF3A3A3C : 0xFFFFFFFF);
            modEnd(c);
        }
        c.restore();
        return busy;
    }

    void fpoly(Canvas c, float... q) {
        Path p = new Path(); p.moveTo(q[0], q[1]); for (int i = 2; i < q.length; i += 2) p.lineTo(q[i], q[i + 1]); p.close();
        gp.setStyle(Paint.Style.FILL); c.drawPath(p, gp);
    }

    /** Control Center glyphs on a 24-unit grid centred at (cx, cy) with box size s. */
    void gl(Canvas c, int id, float cx, float cy, float s, int col) {
        c.save(); c.translate(cx, cy); c.scale(s / 24f, s / 24f); c.translate(-12, -12);
        gp.setColor(col); gp.setStrokeCap(Paint.Cap.ROUND); gp.setStrokeJoin(Paint.Join.ROUND); gp.setStrokeWidth(2f); gp.setShader(null);
        Path p = new Path();
        switch (id) {
            case 0: fpoly(c, 12, 2, 14, 9, 22, 14, 22, 16, 14, 13.5f, 13, 19, 16, 21, 16, 22, 12, 21, 8, 22, 8, 21, 11, 19, 10, 13.5f, 2, 16, 2, 14, 10, 9); break;
            case 1: gp.setStyle(Paint.Style.FILL); for (int i = 0; i < 4; i++) c.drawRoundRect(3 + 5.2f * i, 20 - (4 + 4 * i), 6.4f + 5.2f * i, 20, 1, 1, gp); break;
            case 2: gp.setStyle(Paint.Style.STROKE); gp.setStrokeWidth(2.4f);
                for (float r : new float[]{5f, 9.5f, 14f}) c.drawArc(12 - r, 19.5f - r, 12 + r, 19.5f + r, -135, 90, false, gp);
                gp.setStyle(Paint.Style.FILL); c.drawCircle(12, 19.2f, 1.8f, gp); break;
            case 3: p.moveTo(6.5f, 8); p.lineTo(17, 16.5f); p.lineTo(12, 21); p.lineTo(12, 3); p.lineTo(17, 7.5f); p.lineTo(6.5f, 16);
                gp.setStyle(Paint.Style.STROKE); c.drawPath(p, gp); break;
            case 4: gp.setStyle(Paint.Style.STROKE); c.drawRoundRect(7, 6, 17, 18, 2.2f, 2.2f, gp); c.drawArc(2.5f, 2.5f, 21.5f, 21.5f, 150, 70, false, gp); c.drawArc(2.5f, 2.5f, 21.5f, 21.5f, -30, 70, false, gp); break;
            case 5: { Path a = new Path(), b = new Path(); a.addCircle(12, 12, 9, Path.Direction.CW); b.addCircle(17.5f, 7.5f, 8, Path.Direction.CW); a.op(b, Path.Op.DIFFERENCE); gp.setStyle(Paint.Style.FILL); c.drawPath(a, gp); break; }
            case 6: gp.setStyle(Paint.Style.STROKE); c.drawRoundRect(2.5f, 5, 21.5f, 17, 2, 2, gp); c.drawLine(8, 21, 16, 21, gp); break;
            case 7: gp.setStyle(Paint.Style.FILL); c.drawRoundRect(8, 10, 16, 22, 2, 2, gp); fpoly(c, 7, 2.5f, 17, 2.5f, 16, 9, 8, 9); break;
            case 8: gp.setStyle(Paint.Style.STROKE); c.drawCircle(12, 13, 8, gp); c.drawLine(12, 13, 12, 8.5f, gp); c.drawLine(9.5f, 2.5f, 14.5f, 2.5f, gp); break;
            case 9: gp.setStyle(Paint.Style.STROKE); c.drawRoundRect(5, 3, 19, 21, 2.5f, 2.5f, gp); gp.setStyle(Paint.Style.FILL); c.drawRoundRect(7.5f, 5.5f, 16.5f, 9.5f, 1, 1, gp);
                for (int r = 0; r < 2; r++) for (int q = 0; q < 3; q++) c.drawCircle(9 + 3 * q, 13.5f + 3.6f * r, 1.1f, gp); break;
            case 10: gp.setStyle(Paint.Style.STROKE); c.drawRoundRect(2.5f, 7, 21.5f, 20, 3, 3, gp); c.drawCircle(12, 13.5f, 4, gp); c.drawLine(8.5f, 5, 15.5f, 5, gp); break;
            case 11: gp.setStyle(Paint.Style.FILL); c.drawCircle(12, 12, 4.2f, gp); gp.setStyle(Paint.Style.STROKE);
                for (int i = 0; i < 8; i++) { c.save(); c.rotate(i * 45, 12, 12); c.drawLine(12, 2.5f, 12, 5, gp); c.restore(); } break;
            case 12: fpoly(c, 3, 9, 7, 9, 12, 5, 12, 19, 7, 15, 3, 15); gp.setStyle(Paint.Style.STROKE);
                c.drawArc(7, 7, 17, 17, -50, 100, false, gp); c.drawArc(3, 3, 21, 21, -50, 100, false, gp); break;
            case 13: fpoly(c, 11, 5, 11, 19, 2, 12); fpoly(c, 21, 5, 21, 19, 12, 12); break;
            case 14: fpoly(c, 6, 3, 6, 21, 21, 12); break;
            case 15: fpoly(c, 13, 5, 13, 19, 22, 12); fpoly(c, 3, 5, 3, 19, 12, 12); break;
            case 16: gp.setStyle(Paint.Style.FILL); c.drawCircle(8, 18, 3.6f, gp); fpoly(c, 11.4f, 5, 19, 7.5f, 19, 11, 11.4f, 8.5f); gp.setStyle(Paint.Style.STROKE); c.drawLine(11.4f, 18, 11.4f, 5, gp); break;
        }
        c.restore();
    }

}
