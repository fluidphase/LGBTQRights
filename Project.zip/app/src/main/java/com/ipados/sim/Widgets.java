package com.ipados.sim;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Context;
import android.content.Intent;
import android.graphics.*;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Real Android AppWidget hosting. Widgets live on the left-most "Today" page. */
final class Widgets {
    static final int HOST_ID = 1024, REQ_BIND = 31, REQ_CONFIG = 32;
    static final int[][] SIZES = {{1, 1}, {2, 1}, {2, 2}, {3, 2}, {4, 2}, {4, 3}, {5, 3}};

    final MainActivity act; final HomeView home; final AppWidgetHost host; final AppWidgetManager mgr; final FrameLayout layer;
    final ArrayList<W> list = new ArrayList<>();
    int pendingId = -1;

    class W { int id, cw, ch, r, c; AppWidgetHostView hv; Frame fr; }

    Widgets(MainActivity a, HomeView h) {
        act = a; home = h; host = new AppWidgetHost(a, HOST_ID); mgr = AppWidgetManager.getInstance(a); layer = new FrameLayout(a);
        for (String s : Prefs.list("widgets")) {
            try { int id = Integer.parseInt(s); AppWidgetProviderInfo info = mgr.getAppWidgetInfo(id); if (info != null) add(id, info); } catch (Exception ignored) { }
        }
    }

    void start() { try { host.startListening(); } catch (Throwable ignored) { } }
    void stop() { try { host.stopListening(); } catch (Throwable ignored) { } }

    void add(int id, AppWidgetProviderInfo info) {
        W w = new W(); w.id = id;
        String sp = Prefs.sp.getString("ws" + id, "");
        if (!sp.isEmpty()) { String[] p = sp.split(","); w.cw = Integer.parseInt(p[0]); w.ch = Integer.parseInt(p[1]); }
        w.hv = host.createView(act, id, info);
        w.fr = new Frame(act, w); w.fr.addView(w.hv, new FrameLayout.LayoutParams(-1, -1));
        layer.addView(w.fr); list.add(w);
    }

    void save() { ArrayList<String> l = new ArrayList<>(); for (W w : list) l.add(String.valueOf(w.id)); Prefs.putList("widgets", l); }

    void layout() {
        if (home.W <= 0) return;
        int cols = Prefs.cols, rows = home.widgetRows();
        boolean[][] occ = new boolean[rows][cols];
        for (W w : list) {
            AppWidgetProviderInfo info = mgr.getAppWidgetInfo(w.id);
            if (w.cw == 0 || w.ch == 0) {
                float mw = info != null ? info.minWidth : 160, mh = info != null ? info.minHeight : 160;
                w.cw = Math.max(1, (int) Math.ceil(mw / (home.cellW / Ui.d))); w.ch = Math.max(1, (int) Math.ceil(mh / (home.cellH / Ui.d)));
            }
            w.cw = Math.min(w.cw, cols); w.ch = Math.min(w.ch, rows);
            boolean placed = false;
            for (int r = 0; r + w.ch <= rows && !placed; r++) for (int c = 0; c + w.cw <= cols && !placed; c++) {
                boolean free = true;
                for (int i = r; i < r + w.ch && free; i++) for (int j = c; j < c + w.cw; j++) if (occ[i][j]) { free = false; break; }
                if (free) { for (int i = r; i < r + w.ch; i++) for (int j = c; j < c + w.cw; j++) occ[i][j] = true; w.r = r; w.c = c; placed = true; }
            }
            w.fr.setVisibility(placed ? View.VISIBLE : View.GONE);
            if (!placed) continue;
            RectF rc = home.widgetRect(w.r, w.c, w.cw, w.ch);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) rc.width(), (int) rc.height());
            lp.leftMargin = (int) rc.left; lp.topMargin = (int) rc.top; w.fr.setLayoutParams(lp);
            int wd = (int) (rc.width() / Ui.d), hd = (int) (rc.height() / Ui.d);
            try { w.hv.updateAppWidgetSize(null, wd, hd, wd, hd); } catch (Throwable ignored) { }
        }
    }

    void sync(float pageF, boolean hide) {
        layer.setTranslationX(-pageF * home.W);
        int vis = (pageF < 0.999f && !hide) ? View.VISIBLE : View.INVISIBLE;
        if (layer.getVisibility() != vis) layer.setVisibility(vis);
    }

    void refresh() { for (W w : list) w.fr.invalidate(); }

    void cycle(W w) {
        int idx = -1;
        for (int i = 0; i < SIZES.length; i++) if (SIZES[i][0] == w.cw && SIZES[i][1] == w.ch) idx = i;
        idx = (idx + 1) % SIZES.length; w.cw = SIZES[idx][0]; w.ch = SIZES[idx][1];
        Prefs.sp.edit().putString("ws" + w.id, w.cw + "," + w.ch).apply();
        layout(); home.invalidate();
    }

    void remove(W w) {
        try { host.deleteAppWidgetId(w.id); } catch (Throwable ignored) { }
        layer.removeView(w.fr); list.remove(w); Prefs.sp.edit().remove("ws" + w.id).apply(); save(); layout(); home.invalidate();
    }

    // ---- adding: our own picker -> bind (asks permission if needed) -> optional configure -> add
    void pick() {
        final List<AppWidgetProviderInfo> ps = new ArrayList<>(mgr.getInstalledProviders());
        final android.content.pm.PackageManager pm = act.getPackageManager();
        Collections.sort(ps, (a, b) -> String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        String[] names = new String[ps.size()];
        for (int i = 0; i < names.length; i++) {
            AppWidgetProviderInfo p = ps.get(i);
            String app; try { app = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(p.provider.getPackageName(), 0))); } catch (Exception e) { app = p.provider.getPackageName(); }
            names[i] = app + " \u2014 " + p.loadLabel(pm);
        }
        new AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert).setTitle("Add Widget").setItems(names, (d, which) -> bind(ps.get(which))).show();
    }

    void bind(AppWidgetProviderInfo info) {
        int id = host.allocateAppWidgetId();
        if (mgr.bindAppWidgetIdIfAllowed(id, info.provider)) { configureOrFinish(id); return; }
        pendingId = id;
        Intent i = new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id); i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider);
        try { act.startActivityForResult(i, REQ_BIND); } catch (Exception e) { host.deleteAppWidgetId(id); Toast.makeText(act, "Widgets can't be bound on this device", Toast.LENGTH_SHORT).show(); }
    }

    void configureOrFinish(int id) {
        AppWidgetProviderInfo info = mgr.getAppWidgetInfo(id);
        if (info != null && info.configure != null) {
            pendingId = id;
            try { host.startAppWidgetConfigureActivityForResult(act, id, 0, REQ_CONFIG, null); return; } catch (Exception ignored) { }
        }
        finish(id);
    }

    void finish(int id) {
        AppWidgetProviderInfo info = mgr.getAppWidgetInfo(id);
        if (info == null) { host.deleteAppWidgetId(id); return; }
        add(id, info); save(); layout(); home.pageAnim(0); home.invalidate();
    }

    boolean onResult(int req, int res, Intent data) {
        if (req != REQ_BIND && req != REQ_CONFIG) return false;
        int id = pendingId; pendingId = -1;
        if (id < 0) return true;
        if (res != Activity.RESULT_OK) { host.deleteAppWidgetId(id); return true; }
        if (req == REQ_BIND) configureOrFinish(id); else finish(id);
        return true;
    }

    void widgetMenu(final W w) {
        new AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert).setTitle("Widget")
                .setItems(new String[]{"Remove Widget", "Resize", "Edit Home Screen"}, (d, i) -> { if (i == 0) remove(w); else if (i == 1) cycle(w); else home.setJiggle(true); }).show();
    }

    /** Wrapper around one widget: rounded clip, long-press -> edit mode, remove / resize badges while editing. */
    class Frame extends FrameLayout {
        final W w; float dx, dy; final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Runnable lp = new Runnable() { public void run() { home.hap(HapticFeedbackConstants.LONG_PRESS); widgetMenu(Frame.this.w); } };

        Frame(Context c, W w) {
            super(c); this.w = w; setWillNotDraw(false);
            setOutlineProvider(new ViewOutlineProvider() { @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), Ui.dp(22)); } });
            setClipToOutline(true);
        }

        @Override public boolean onInterceptTouchEvent(MotionEvent e) {
            if (home.jiggle) return true;
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { dx = e.getX(); dy = e.getY(); postDelayed(lp, 550); }
            else if (a == MotionEvent.ACTION_MOVE) { if (Math.hypot(e.getX() - dx, e.getY() - dy) > home.slop) removeCallbacks(lp); }
            else removeCallbacks(lp);
            return false;
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (home.jiggle && e.getActionMasked() == MotionEvent.ACTION_UP) {
                float x = e.getX(), y = e.getY(), r = Ui.dp(30);
                if (Math.hypot(x - Ui.dp(16), y - Ui.dp(16)) < r) remove(w);
                else if (Math.hypot(x - (getWidth() - Ui.dp(16)), y - (getHeight() - Ui.dp(16))) < r) cycle(w);
            }
            return true;
        }

        @Override protected void dispatchDraw(Canvas c) {
            super.dispatchDraw(c);
            if (!home.jiggle) return;
            p.setStyle(Paint.Style.FILL); p.setColor(0xE6B8B8BE); c.drawCircle(Ui.dp(16), Ui.dp(16), Ui.dp(13), p);
            SvgIcons.draw(c, SvgIcons.MINUS, Ui.dp(16), Ui.dp(16), Ui.dp(16), 0xFF2C2C2E, 2f);
            p.setColor(0xE6B8B8BE); c.drawCircle(getWidth() - Ui.dp(16), getHeight() - Ui.dp(16), Ui.dp(11), p);
            SvgIcons.draw(c, SvgIcons.GRID, getWidth() - Ui.dp(16), getHeight() - Ui.dp(16), Ui.dp(14), 0xFF2C2C2E, 2f);
        }
    }
}
