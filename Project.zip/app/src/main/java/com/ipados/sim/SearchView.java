package com.ipados.sim;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

/** Pull-down app search. */
final class SearchView extends FrameLayout {
    final MainActivity act; final HomeView home; final LinearLayout results; final EditText et; final float d = Ui.d;

    SearchView(MainActivity a, HomeView h) {
        super(a); act = a; home = h;
        setBackgroundColor(0xE60B0B10); setOnClickListener(v -> act.closeOverlay());
        LinearLayout box = new LinearLayout(a); box.setOrientation(LinearLayout.VERTICAL); box.setClickable(true);
        box.setPadding(dp(16), dp(36), dp(16), 0);
        et = new EditText(a); et.setHint("Search"); et.setHintTextColor(0x99FFFFFF); et.setTextColor(0xFFFFFFFF); et.setTextSize(18); et.setSingleLine(true); et.setTypeface(Ui.REG);
        et.setPadding(dp(18), dp(12), dp(18), dp(12));
        GradientDrawable g = new GradientDrawable(); g.setColor(0x33FFFFFF); g.setCornerRadius(dp(14)); et.setBackground(g);
        box.addView(et, new LinearLayout.LayoutParams(-1, -2));
        ScrollView sv = new ScrollView(a); results = new LinearLayout(a); results.setOrientation(LinearLayout.VERTICAL); sv.addView(results);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, 0, 1f); sl.topMargin = dp(10); box.addView(sv, sl);
        int w = Math.min(dp(560), a.getResources().getDisplayMetrics().widthPixels - dp(24));
        addView(box, new LayoutParams(w, -1, Gravity.CENTER_HORIZONTAL));
        et.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { refresh(s.toString().trim()); }
            public void afterTextChanged(Editable s) { }
        });
        refresh("");
        post(() -> { et.requestFocus(); InputMethodManager im = (InputMethodManager) act.getSystemService(Context.INPUT_METHOD_SERVICE); if (im != null) im.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT); });
    }

    int dp(float v) { return (int) (v * d); }

    void hideIme() { InputMethodManager im = (InputMethodManager) act.getSystemService(Context.INPUT_METHOD_SERVICE); if (im != null) im.hideSoftInputFromWindow(et.getWindowToken(), 0); }

    void refresh(String q) {
        results.removeAllViews();
        String lq = q.toLowerCase();
        int n = 0;
        for (HomeView.App app : home.allApps()) {
            if (!lq.isEmpty() && !app.name.toLowerCase().contains(lq)) continue;
            if (lq.isEmpty() && n >= 8) break;
            if (n++ >= 14) break;
            LinearLayout r = row(); ImageView iv = new ImageView(act); iv.setImageBitmap(home.iconBitmap(app, 96));
            r.addView(iv, new LinearLayout.LayoutParams(dp(44), dp(44))); r.addView(label(app.name));
            r.setOnClickListener(v -> { act.closeOverlay(); home.launch(app); });
            results.addView(r);
        }
        if (!q.isEmpty()) {
            LinearLayout r = row(); r.addView(new IconV(act, SvgIcons.SEARCH, 0xFFFFFFFF, 0x55FFFFFF), new LinearLayout.LayoutParams(dp(44), dp(44))); r.addView(label("Search web for \u201C" + q + "\u201D"));
            r.setOnClickListener(v -> { act.closeOverlay(); try { Intent i = new Intent(Intent.ACTION_WEB_SEARCH); i.putExtra(SearchManager.QUERY, q); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); act.startActivity(i); } catch (Exception e) { try { act.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))); } catch (Exception ignored) { } } });
            results.addView(r);
        }
    }

    LinearLayout row() { LinearLayout r = new LinearLayout(act); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(dp(8), dp(6), dp(8), dp(6)); return r; }
    TextView label(String s) { TextView t = new TextView(act); t.setText(s); t.setTextColor(0xFFFFFFFF); t.setTextSize(17); t.setTypeface(Ui.REG); t.setPadding(dp(14), 0, 0, 0); return t; }
}
