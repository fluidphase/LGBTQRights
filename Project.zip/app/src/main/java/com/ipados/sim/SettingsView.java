package com.ipados.sim;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;

/** Native, scrollable launcher settings sheet. */
final class SettingsView extends FrameLayout {
    interface IntCb { void on(int v); }
    interface FloatCb { void on(float v); }
    interface BoolCb { void on(boolean v); }

    final MainActivity act; final HomeView home; final LinearLayout col; final float d = Ui.d;

    SettingsView(MainActivity a, HomeView h) {
        super(a); act = a; home = h;
        setBackgroundColor(0x99000000);
        setOnClickListener(v -> act.closeOverlay());
        DisplayMetrics dm = a.getResources().getDisplayMetrics();
        LinearLayout sheet = new LinearLayout(a); sheet.setOrientation(LinearLayout.VERTICAL); sheet.setClickable(true);
        GradientDrawable g = new GradientDrawable(); g.setColor(0xFF000000); g.setCornerRadius(dp(22)); sheet.setBackground(g);
        FrameLayout hd = new FrameLayout(a);
        TextView title = tv("Launcher Settings", 17, 0xFFFFFFFF); title.setTypeface(Ui.BOLD);
        hd.addView(title, new LayoutParams(-2, -2, Gravity.CENTER));
        TextView done = tv("Done", 17, Prefs.accent); done.setPadding(dp(20), dp(10), dp(20), dp(10));
        done.setOnClickListener(v -> act.closeOverlay());
        hd.addView(done, new LayoutParams(-2, -2, Gravity.CENTER_VERTICAL | Gravity.END));
        sheet.addView(hd, new LinearLayout.LayoutParams(-1, dp(52)));
        ScrollView sv = new ScrollView(a); sv.setOverScrollMode(OVER_SCROLL_NEVER);
        col = new LinearLayout(a); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(dp(18), dp(4), dp(18), dp(30));
        sv.addView(col); sheet.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LayoutParams lp = new LayoutParams(Math.min(dp(640), (int) (dm.widthPixels * 0.92f)), (int) (dm.heightPixels * 0.92f), Gravity.CENTER);
        addView(sheet, lp);
        build();
    }

    int dp(float v) { return (int) (v * d); }

    TextView tv(String s, float sp, int color) {
        TextView t = new TextView(getContext()); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setTypeface(Ui.REG); return t;
    }

    void set(String k, Object v) { Prefs.put(k, v); act.apply(false); }
    void setHeavy(String k, Object v) { Prefs.put(k, v); act.apply(true); }

    LinearLayout card(String header) {
        if (header != null) { TextView t = tv(header, 12.5f, 0xFF8E8E93); t.setPadding(dp(16), dp(20), 0, dp(7)); col.addView(t); }
        else { View sp = new View(getContext()); col.addView(sp, new LinearLayout.LayoutParams(-1, dp(18))); }
        LinearLayout c = new LinearLayout(getContext()); c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable(); g.setColor(0xFF1C1C1E); g.setCornerRadius(dp(12)); c.setBackground(g);
        col.addView(c, new LinearLayout.LayoutParams(-1, -2));
        return c;
    }

    /** Adds a row to the card (icon tile + label) and returns its horizontal layout. */
    LinearLayout row(LinearLayout card, int icon, int tile, String label) {
        if (card.getChildCount() > 0) { View s = new View(getContext()); s.setBackgroundColor(0xFF2C2C2E); LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, 1); sl.leftMargin = dp(52); card.addView(s, sl); }
        LinearLayout box = new LinearLayout(getContext()); box.setOrientation(LinearLayout.VERTICAL); card.addView(box, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout r = new LinearLayout(getContext()); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(dp(12), 0, dp(14), 0);
        IconV ic = new IconV(getContext(), icon, 0xFFFFFFFF, tile);
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(dp(29), dp(29)); il.rightMargin = dp(12); r.addView(ic, il);
        TextView t = tv(label, 16, 0xFFFFFFFF); r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(r, new LinearLayout.LayoutParams(-1, dp(48)));
        return r;
    }

    void toggle(LinearLayout card, int icon, int tile, String label, boolean on, BoolCb cb) {
        LinearLayout r = row(card, icon, tile, label);
        Sw s = new Sw(getContext(), on); s.cb = cb; r.addView(s, new LinearLayout.LayoutParams(dp(51), dp(31)));
        r.setOnClickListener(v -> s.flip());
    }

    void slider(LinearLayout card, int icon, int tile, String label, float min, float max, float val, String unit, float unitMul, FloatCb cb) {
        LinearLayout r = row(card, icon, tile, label);
        TextView vt = tv(fmt(val * unitMul) + unit, 15, 0xFF8E8E93); r.addView(vt);
        SeekBar sb = new SeekBar(getContext()); sb.setMax(1000);
        sb.setProgress((int) ((val - min) / (max - min) * 1000));
        sb.setProgressTintList(ColorStateList.valueOf(Prefs.accent)); sb.setThumbTintList(ColorStateList.valueOf(0xFFFFFFFF));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF48484A));
        sb.setPadding(dp(30), 0, dp(30), 0);
        ((LinearLayout) r.getParent()).addView(sb, new LinearLayout.LayoutParams(-1, dp(32)));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { if (!user) return; float v = min + (max - min) * p / 1000f; vt.setText(fmt(v * unitMul) + unit); cb.on(v); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { act.apply(true); }
        });
    }

    static String fmt(float v) { return Math.abs(v - Math.round(v)) < 0.05f ? String.valueOf(Math.round(v)) : String.format(java.util.Locale.US, "%.1f", v); }

    void dropdown(LinearLayout card, int icon, int tile, String label, String[] opts, int[] icons, int sel, IntCb cb) {
        LinearLayout r = row(card, icon, tile, label);
        final int[] cur = {sel};
        TextView val = tv(opts[sel], 15, 0xFF8E8E93); r.addView(val);
        IconV chev = new IconV(getContext(), SvgIcons.CHEV, 0xFF8E8E93, 0); LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(dp(18), dp(18)); cl.leftMargin = dp(4); r.addView(chev, cl);
        r.setOnClickListener(v -> popup(r, opts, icons, cur[0], i -> { cur[0] = i; val.setText(opts[i]); cb.on(i); }));
    }

    /** Drop-down menu with SVG icons. */
    void popup(View anchor, String[] opts, int[] icons, int sel, IntCb cb) {
        LinearLayout list = new LinearLayout(getContext()); list.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable(); g.setColor(0xFF2C2C2E); g.setCornerRadius(dp(14)); list.setBackground(g);
        final PopupWindow pw = new PopupWindow(getContext());
        for (int i = 0; i < opts.length; i++) {
            final int idx = i;
            LinearLayout r = new LinearLayout(getContext()); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(dp(10), 0, dp(14), 0);
            IconV ck = new IconV(getContext(), SvgIcons.CHECK, Prefs.accent, 0); ck.setVisibility(i == sel ? View.VISIBLE : View.INVISIBLE); r.addView(ck, new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView t = tv(opts[i], 16, 0xFFFFFFFF); LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f); tl.leftMargin = dp(6); r.addView(t, tl);
            if (icons != null) r.addView(new IconV(getContext(), icons[i], 0xFFFFFFFF, 0), new LinearLayout.LayoutParams(dp(22), dp(22)));
            r.setOnClickListener(v -> { pw.dismiss(); cb.on(idx); });
            list.addView(r, new LinearLayout.LayoutParams(-1, dp(46)));
            if (i < opts.length - 1) { View s = new View(getContext()); s.setBackgroundColor(0xFF3A3A3C); list.addView(s, new LinearLayout.LayoutParams(-1, 1)); }
        }
        ScrollView sv = new ScrollView(getContext()); sv.addView(list);
        pw.setContentView(sv); pw.setWidth(dp(240)); pw.setHeight(Math.min(opts.length * dp(46), dp(340))); pw.setFocusable(true);
        pw.setBackgroundDrawable(new ColorDrawable(0)); pw.setElevation(dp(14));
        pw.showAsDropDown(anchor, anchor.getWidth() - dp(250), -dp(6));
    }

    void swatches(LinearLayout card, int icon, int tile, String label, int[] colors, int sel, IntCb cb) {
        LinearLayout r = row(card, icon, tile, label);
        final View[] dots = new View[colors.length]; final int[] cur = {sel};
        for (int i = 0; i < colors.length; i++) {
            final int idx = i; View v = new View(getContext()); dots[i] = v;
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dp(24), dp(24)); l.leftMargin = dp(8); r.addView(v, l);
            v.setOnClickListener(x -> { cur[0] = idx; paintDots(dots, colors, idx); cb.on(colors[idx]); });
        }
        paintDots(dots, colors, sel);
    }

    void paintDots(View[] dots, int[] colors, int sel) {
        for (int i = 0; i < dots.length; i++) { GradientDrawable g = new GradientDrawable(); g.setShape(GradientDrawable.OVAL); g.setColor(colors[i]); g.setStroke(dp(i == sel ? 3 : 1), i == sel ? 0xFF8E8E93 : 0x44FFFFFF); dots[i].setBackground(g); }
    }

    void action(LinearLayout card, int icon, int tile, String label, Runnable run) {
        LinearLayout r = row(card, icon, tile, label);
        r.addView(new IconV(getContext(), SvgIcons.CHEV, 0xFF8E8E93, 0), new LinearLayout.LayoutParams(dp(18), dp(18)));
        r.getChildAt(r.getChildCount() - 1).setRotation(-90);
        r.setOnClickListener(v -> run.run());
    }

    static String[] nums(int a, int b) { String[] s = new String[b - a + 1]; for (int i = 0; i < s.length; i++) s[i] = String.valueOf(a + i); return s; }
    static int idx(int[] a, int v) { for (int i = 0; i < a.length; i++) if (a[i] == v) return i; return 0; }

    void build() {
        final int[] accents = {0xFF0A84FF, 0xFF30D158, 0xFFFF9F0A, 0xFFFF375F, 0xFFBF5AF2, 0xFF64D2FF};
        final int[] labelCols = {0xFFFFFFFF, 0xFF000000, 0xFFFFD60A, 0xFF63E6BE};
        LinearLayout c;

        c = card("APPEARANCE");
        swatches(c, SvgIcons.SPARK, 0xFFBF5AF2, "Accent colour", accents, idx(accents, Prefs.accent), v -> set("accent", v));

        c = card("HOME SCREEN");
        dropdown(c, SvgIcons.GRID, 0xFF5E5CE6, "Columns", nums(4, 9), null, Prefs.cols - 4, i -> set("cols", i + 4));
        dropdown(c, SvgIcons.GRID, 0xFF5E5CE6, "Rows", nums(3, 6), null, Prefs.rows - 3, i -> set("rows", i + 3));
        slider(c, SvgIcons.GRID, 0xFF0A84FF, "Icon size", 0.6f, 1.25f, Prefs.iconScale, "%", 100, v -> set("iconScale", v));
        slider(c, SvgIcons.GRID, 0xFF0A84FF, "Icon corner radius", 0f, 50f, Prefs.corner, "%", 1, v -> set("corner", v));
        toggle(c, SvgIcons.PENCIL, 0xFF8E8E93, "Show labels", Prefs.labels, v -> set("labels", v));
        slider(c, SvgIcons.PENCIL, 0xFF8E8E93, "Label size", 9f, 15f, Prefs.labelSize, "", 1, v -> set("labelSize", v));
        swatches(c, SvgIcons.PENCIL, 0xFF8E8E93, "Label colour", labelCols, idx(labelCols, Prefs.labelColor), v -> set("labelColor", v));
        toggle(c, SvgIcons.IMAGE, 0xFFFF9F0A, "iOS-style icons for known apps", Prefs.ios, v -> set("ios", v));
        toggle(c, SvgIcons.WIDGET, 0xFF30D158, "Built-in widgets (needs 6+ columns)", Prefs.builtin, v -> set("builtin", v));
        dropdown(c, SvgIcons.ARROW_UR, 0xFF0A84FF, "Launch background", new String[]{"Light", "Dark", "Match app"}, new int[]{SvgIcons.SPARK, SvgIcons.CLOCK, SvgIcons.IMAGE}, Prefs.splash, i -> set("splash", i));
        action(c, SvgIcons.HIDE, 0xFF8E8E93, "Hidden apps", this::hiddenDialog);
        action(c, SvgIcons.REFRESH, 0xFFFF453A, "Reset layout", () -> { home.resetLayout(); Toast.makeText(act, "Layout reset", Toast.LENGTH_SHORT).show(); });

        c = card("DOCK");
        dropdown(c, SvgIcons.DOCK, 0xFF0A84FF, "Maximum apps", nums(3, 9), null, Prefs.dockMax - 3, i -> set("dockMax", i + 3));
        slider(c, SvgIcons.DOCK, 0xFF0A84FF, "Icon size", 0.7f, 1.3f, Prefs.dockScale, "%", 100, v -> set("dockScale", v));
        slider(c, SvgIcons.DOCK, 0xFF32ADE6, "Wallpaper blur", 0f, 5f, Prefs.dockBlur, "", 1, v -> { Prefs.put("dockBlur", Math.round(v)); });
        slider(c, SvgIcons.DOCK, 0xFF32ADE6, "Tint", 0f, 140f, Prefs.dockTint, "", 1, v -> set("dockTint", Math.round(v)));
        slider(c, SvgIcons.DOCK, 0xFF32ADE6, "Corner radius", 0f, 40f, Prefs.dockRadius, "", 1, v -> set("dockRadius", Math.round(v)));

        c = card("WALLPAPER");
        dropdown(c, SvgIcons.IMAGE, 0xFF32ADE6, "Source", new String[]{"System wallpaper", "Choose image\u2026", "Gradient"}, new int[]{SvgIcons.PHONE, SvgIcons.IMAGE, SvgIcons.SPARK}, Prefs.wpMode,
                i -> { if (i == 1) act.pickWallpaper(); else { Prefs.put("wpMode", i == 2 ? 2 : 0); if (i == 0 && !act.hasStorage()) act.askStorage(); act.apply(true); } });
        toggle(c, SvgIcons.IMAGE, 0xFF32ADE6, "Parallax", Prefs.parallax, v -> set("parallax", v));
        slider(c, SvgIcons.IMAGE, 0xFF32ADE6, "Dim", 0f, 150f, Prefs.wpDim, "", 1, v -> set("wpDim", Math.round(v)));
        slider(c, SvgIcons.IMAGE, 0xFF32ADE6, "Blur", 0f, 3f, Prefs.wpBlur, "", 1, v -> Prefs.put("wpBlur", Math.round(v)));

        c = card("ANIMATION & FEEL");
        slider(c, SvgIcons.BOLT, 0xFFFF9F0A, "Animation speed", 0.5f, 2f, Prefs.speed, "\u00D7", 1, v -> set("speed", v));
        toggle(c, SvgIcons.BOLT, 0xFFFF9F0A, "Haptic feedback", Prefs.haptics, v -> set("haptics", v));
        toggle(c, SvgIcons.BOLT, 0xFFFF9F0A, "Icon jiggle in edit mode", Prefs.jiggle, v -> set("jiggle", v));

        c = card("GESTURES");
        toggle(c, SvgIcons.SLIDERS, 0xFF8E8E93, "Control Center (swipe from top right)", Prefs.cc, v -> set("cc", v));
        dropdown(c, SvgIcons.BELL, 0xFFFF453A, "Swipe down at top left", new String[]{"Nothing", "Notifications"}, new int[]{SvgIcons.MINUS, SvgIcons.BELL}, Prefs.swipeLeft, i -> set("swipeLeft", i));
        toggle(c, SvgIcons.SEARCH, 0xFF8E8E93, "Pull down to search", Prefs.pull, v -> set("pull", v));

        c = card("SYSTEM");
        toggle(c, SvgIcons.PHONE, 0xFF0A84FF, "Show install, boot & lock screen on start", Prefs.intro, v -> set("intro", v));
        toggle(c, SvgIcons.BOLT, 0xFF5E5CE6, "Graphics Accelerator", Ui.gfx, v -> { Ui.gfx = v; home.nextFrame = 0; home.invalidate(); });
        action(c, SvgIcons.PHONE, 0xFF30D158, "Set as default launcher", () -> { try { Intent i = new Intent(Settings.ACTION_HOME_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); act.startActivity(i); } catch (Exception e) { Toast.makeText(act, "Open system Settings \u203A Apps \u203A Default apps", Toast.LENGTH_LONG).show(); } });
        action(c, SvgIcons.REFRESH, 0xFF8E8E93, "Reload apps", () -> home.reloadApps());
    }

    void hiddenDialog() {
        final ArrayList<HomeView.App> hs = home.hiddenApps();
        if (hs.isEmpty()) { Toast.makeText(act, "No hidden apps", Toast.LENGTH_SHORT).show(); return; }
        String[] n = new String[hs.size()]; final boolean[] chk = new boolean[hs.size()];
        for (int i = 0; i < n.length; i++) { n[i] = hs.get(i).name; chk[i] = true; }
        new AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert).setTitle("Hidden apps (untick to restore)")
                .setMultiChoiceItems(n, chk, (dlg, i, b) -> chk[i] = b)
                .setPositiveButton("Apply", (dlg, w) -> { for (int i = 0; i < chk.length; i++) if (!chk[i]) home.unhide(hs.get(i)); })
                .setNegativeButton("Cancel", null).show();
    }

    /** iOS-style animated switch. */
    static final class Sw extends View {
        boolean on; float t; BoolCb cb; ValueAnimator an; final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Sw(Context c, boolean on) { super(c); this.on = on; t = on ? 1f : 0f; }
        void flip() {
            on = !on; if (an != null) an.cancel();
            an = ValueAnimator.ofFloat(t, on ? 1f : 0f); an.setDuration(200); an.addUpdateListener(v -> { t = (float) v.getAnimatedValue(); invalidate(); }); an.start();
            if (cb != null) cb.on(on);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), k = h / 2 - Ui.dp(2);
            int a = Prefs.accent, off = 0xFF39393D;
            p.setColor(Color.rgb((int) Ui.lerp(Color.red(off), Color.red(a), t), (int) Ui.lerp(Color.green(off), Color.green(a), t), (int) Ui.lerp(Color.blue(off), Color.blue(a), t)));
            c.drawRoundRect(0, 0, w, h, h / 2, h / 2, p);
            p.setColor(0xFFFFFFFF); c.drawCircle(Ui.lerp(h / 2, w - h / 2, t), h / 2, k, p);
        }
    }
}
