package com.ipados.sim;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

/** In-app styled dialogs (replace the stock Android AlertDialogs). */
final class Dialogs {
    interface IntCb { void on(int i); }
    interface StrCb { void on(String s); }
    interface BoolsCb { void on(boolean[] b); }

    static int dp(float v) { return (int) Ui.dp(v); }

    static class MaxScroll extends ScrollView {
        final int max;
        MaxScroll(Context c, int max) { super(c); this.max = max; setOverScrollMode(OVER_SCROLL_NEVER); }
        @Override protected void onMeasure(int w, int h) { super.onMeasure(w, MeasureSpec.makeMeasureSpec(max, MeasureSpec.AT_MOST)); }
    }

    static class Sheet extends FrameLayout {
        final MainActivity act; final LinearLayout sheet, body; EditText input;
        Sheet(MainActivity a, String title) {
            super(a); act = a; setBackgroundColor(0x99000000); setClickable(true); setOnClickListener(v -> dismiss());
            DisplayMetrics dm = a.getResources().getDisplayMetrics();
            sheet = new LinearLayout(a); sheet.setOrientation(LinearLayout.VERTICAL); sheet.setClickable(true);
            GradientDrawable g = new GradientDrawable(); g.setColor(0xFF1C1C1E); g.setCornerRadius(dp(20)); sheet.setBackground(g);
            TextView t = new TextView(a); t.setText(title); t.setTextColor(0xFFFFFFFF); t.setTextSize(17); t.setTypeface(Ui.BOLD); t.setGravity(Gravity.CENTER);
            sheet.addView(t, new LinearLayout.LayoutParams(-1, dp(54)));
            body = new LinearLayout(a); body.setOrientation(LinearLayout.VERTICAL);
            MaxScroll sv = new MaxScroll(a, (int) (dm.heightPixels * 0.6f)); sv.addView(body);
            sheet.addView(sv, new LinearLayout.LayoutParams(-1, -2));
            addView(sheet, new LayoutParams(Math.min(dp(420), (int) (dm.widthPixels * 0.9f)), -2, Gravity.CENTER));
        }
        void dismiss() { act.closeDialog(this); }

        void buttons(String neg, String pos, Runnable onPos) {
            View line = new View(act); line.setBackgroundColor(0xFF2C2C2E); sheet.addView(line, new LinearLayout.LayoutParams(-1, 1));
            LinearLayout r = new LinearLayout(act);
            if (neg != null) { TextView n = btn(neg, false); n.setOnClickListener(v -> dismiss()); r.addView(n, new LinearLayout.LayoutParams(0, dp(50), 1f)); }
            if (pos != null) { TextView p = btn(pos, true); p.setOnClickListener(v -> { if (onPos != null) onPos.run(); dismiss(); }); r.addView(p, new LinearLayout.LayoutParams(0, dp(50), 1f)); }
            sheet.addView(r, new LinearLayout.LayoutParams(-1, -2));
        }

        TextView btn(String s, boolean bold) {
            TextView t = new TextView(act); t.setText(s); t.setTextSize(17); t.setGravity(Gravity.CENTER); t.setTextColor(Prefs.accent); t.setTypeface(bold ? Ui.BOLD : Ui.REG); t.setClickable(true);
            t.setBackground(pressBg()); return t;
        }
    }

    static StateListDrawable pressBg() {
        StateListDrawable sd = new StateListDrawable();
        sd.addState(new int[]{android.R.attr.state_pressed}, new ColorDrawable(0xFF2C2C2E));
        sd.addState(new int[]{}, new ColorDrawable(0));
        return sd;
    }

    /** One row: optional leading view, label, optional trailing view, optional divider. */
    static LinearLayout row(Context c, View lead, String text, View trail, boolean divider) {
        LinearLayout w = new LinearLayout(c); w.setOrientation(LinearLayout.VERTICAL); w.setClickable(true); w.setBackground(pressBg());
        LinearLayout r = new LinearLayout(c); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(dp(18), 0, dp(18), 0);
        if (lead != null) { LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dp(26), dp(26)); l.rightMargin = dp(14); r.addView(lead, l); }
        TextView t = new TextView(c); t.setText(text); t.setTextColor(0xFFFFFFFF); t.setTextSize(16); t.setTypeface(Ui.REG); t.setSingleLine(true);
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (trail != null) r.addView(trail);
        w.addView(r, new LinearLayout.LayoutParams(-1, dp(50)));
        if (divider) { View d = new View(c); d.setBackgroundColor(0xFF2C2C2E); LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, 1); dl.leftMargin = dp(18); w.addView(d, dl); }
        return w;
    }

    static void list(MainActivity a, String title, String[] items, int[] icons, IntCb cb) {
        final Sheet s = new Sheet(a, title);
        for (int i = 0; i < items.length; i++) {
            final int idx = i;
            View lead = icons != null ? new IconV(a, icons[i], 0xFFFFFFFF, 0xFF5E5CE6) : null;
            View r = row(a, lead, items[i], null, i < items.length - 1);
            r.setOnClickListener(v -> { s.dismiss(); cb.on(idx); });
            s.body.addView(r);
        }
        s.buttons("Close", null, null); a.showDialog(s);
    }

    static void colors(MainActivity a, String title, String[] names, int[] cols, IntCb cb) {
        final Sheet s = new Sheet(a, title);
        for (int i = 0; i < names.length; i++) {
            final int idx = i; View dot = new View(a); GradientDrawable g = new GradientDrawable(); g.setShape(GradientDrawable.OVAL);
            if (i < cols.length && cols[i] > 1) g.setColor(cols[i]); else g.setColor(0xFF48484A);
            g.setStroke(dp(1), 0x66FFFFFF); dot.setBackground(g);
            View r = row(a, dot, names[i], null, i < names.length - 1);
            r.setOnClickListener(v -> { s.dismiss(); cb.on(idx); });
            s.body.addView(r);
        }
        s.buttons("Close", null, null); a.showDialog(s);
    }

    static void multi(MainActivity a, String title, String[] items, boolean[] checked, String pos, BoolsCb cb) {
        final Sheet s = new Sheet(a, title);
        for (int i = 0; i < items.length; i++) {
            final int idx = i; final SettingsView.Sw sw = new SettingsView.Sw(a, checked[i]);
            sw.cb = on -> checked[idx] = on;
            View r = row(a, null, items[i], sw, i < items.length - 1);
            sw.setLayoutParams(new LinearLayout.LayoutParams(dp(51), dp(31)));
            r.setOnClickListener(v -> sw.flip());
            s.body.addView(r);
        }
        s.buttons("Cancel", pos, () -> cb.on(checked)); a.showDialog(s);
    }

    static void input(MainActivity a, String title, String hint, StrCb cb) {
        final Sheet s = new Sheet(a, title);
        final EditText et = new EditText(a); et.setHint(hint); et.setHintTextColor(0x88FFFFFF); et.setTextColor(0xFFFFFFFF); et.setTextSize(17); et.setSingleLine(true); et.setTypeface(Ui.REG);
        et.setPadding(dp(16), dp(12), dp(16), dp(12));
        GradientDrawable g = new GradientDrawable(); g.setColor(0xFF2C2C2E); g.setCornerRadius(dp(10)); et.setBackground(g);
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2); l.setMargins(dp(18), dp(4), dp(18), dp(18));
        s.body.addView(et, l); s.input = et;
        s.buttons("Cancel", "Set", () -> cb.on(et.getText().toString()));
        a.showDialog(s);
        et.postDelayed(() -> { et.requestFocus(); InputMethodManager im = (InputMethodManager) a.getSystemService(Context.INPUT_METHOD_SERVICE); if (im != null) im.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT); }, 200);
    }
}
