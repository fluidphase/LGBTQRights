package com.ipados.sim;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.View;

/** Tiny SVG-style path icons on a 24x24 grid. Commands: M L H V C Z (absolute) + O cx cy r (circle) + R x y w h rx (round rect). "~" prefix = filled. */
final class SvgIcons {
    static final int MINUS = 0, SHARE = 1, PHONE = 2, CAMERA = 3, SEARCH = 4, CHECKBOX = 5, PENCIL = 6, PLUS = 7, GEAR = 8, INFO = 9,
            ARROW_UR = 10, VIDEO = 11, MAIL = 12, CALL = 13, TABS = 14, PERSON = 15, PIN = 16, IMAGE = 17, WIDGET = 18, SLIDERS = 19,
            CHECK = 20, CHEV = 21, TRASH = 22, HIDE = 23, BELL = 24, GRID = 25, DOCK = 26, SPARK = 27, STATUS = 28, ARROW_DOWN = 29,
            BOLT = 30, CLOCK = 31, REFRESH = 32;

    static final String[] DATA = {
        /*0 MINUS*/ "O 12 12 9|M 8 12 H 16",
        /*1 SHARE*/ "M 12 3 V 15|M 8 7 L 12 3 L 16 7|M 8.5 10 H 6.5 C 5.1 10 4 11.1 4 12.5 V 18.5 C 4 19.9 5.1 21 6.5 21 H 17.5 C 18.9 21 20 19.9 20 18.5 V 12.5 C 20 11.1 18.9 10 17.5 10 H 15.5",
        /*2 PHONE*/ "R 6.5 2.5 11 19 2.4|M 10.5 18.5 H 13.5|~O 10.2 7.5 0.9|~O 13.8 7.5 0.9|~O 10.2 11 0.9|~O 13.8 11 0.9",
        /*3 CAMERA*/ "R 3 7 18 13 3|M 8.5 7 L 9.8 4.8 H 14.2 L 15.5 7|O 12 13.5 3.6",
        /*4 SEARCH*/ "O 11 11 6.5|M 16 16 L 20.5 20.5",
        /*5 CHECKBOX*/ "R 4 4 16 16 3.2|M 8.5 12 L 11 14.5 L 15.5 9.5",
        /*6 PENCIL*/ "M 4 20 L 5 15.5 L 16 4.5 C 16.8 3.7 18.2 3.7 19 4.5 L 19.5 5 C 20.3 5.8 20.3 7.2 19.5 8 L 8.5 19 Z|M 14 6.5 L 17.5 10",
        /*7 PLUS*/ "M 12 5 V 19|M 5 12 H 19",
        /*8 GEAR*/ "O 12 12 3|O 12 12 8|M 12 2 V 4|M 12 20 V 22|M 2 12 H 4|M 20 12 H 22",
        /*9 INFO*/ "O 12 12 9|M 12 11 V 16.5|~O 12 7.8 1",
        /*10 ARROW_UR*/ "M 7 17 L 17 7|M 8.5 7 H 17 V 15.5",
        /*11 VIDEO*/ "R 3 6 13 12 2.5|M 16 10.5 L 21 7.5 V 16.5 L 16 13.5 Z",
        /*12 MAIL*/ "R 3 5 18 14 2.5|M 4 7 L 12 13 L 20 7",
        /*13 CALL*/ "M 6 3 H 9 L 10.5 7.5 L 8.5 9 C 9.5 11.5 12.5 14.5 15 15.5 L 16.5 13.5 L 21 15 V 18 C 21 19.5 19.5 21 18 21 C 10 21 3 14 3 6 C 3 4.5 4.5 3 6 3 Z",
        /*14 TABS*/ "R 4 8 12 12 2|M 8 8 V 6 C 8 5 9 4 10 4 H 18 C 19 4 20 5 20 6 V 14 C 20 15 19 16 18 16 H 16",
        /*15 PERSON*/ "O 12 8 4|M 4 20 C 4 15.5 8 14 12 14 C 16 14 20 15.5 20 20",
        /*16 PIN*/ "M 12 21 C 12 21 5 14.5 5 9.5 C 5 5.6 8.1 3 12 3 C 15.9 3 19 5.6 19 9.5 C 19 14.5 12 21 12 21 Z|O 12 9.5 2.5",
        /*17 IMAGE*/ "R 3 4 18 16 3|O 8.5 9.5 1.8|M 4 18 L 9 13 L 13 17 L 15.5 14.5 L 20 19",
        /*18 WIDGET*/ "R 3 3 8 8 2|R 13 3 8 8 2|R 3 13 8 8 2|M 17 13 V 21|M 13 17 H 21",
        /*19 SLIDERS*/ "M 4 7 H 20|M 4 17 H 20|O 9 7 2.2|O 15 17 2.2",
        /*20 CHECK*/ "M 5 12.5 L 10 17 L 19 7.5",
        /*21 CHEV*/ "M 6 9 L 12 15 L 18 9",
        /*22 TRASH*/ "M 4 7 H 20|M 9 7 V 4.5 H 15 V 7|M 6 7 L 7 20 H 17 L 18 7|M 10 11 V 16|M 14 11 V 16",
        /*23 HIDE*/ "M 3 12 C 5 7.5 8.5 5.5 12 5.5 C 15.5 5.5 19 7.5 21 12 C 19 16.5 15.5 18.5 12 18.5 C 8.5 18.5 5 16.5 3 12 Z|O 12 12 3|M 4 4 L 20 20",
        /*24 BELL*/ "M 6 17 V 11 C 6 7.7 8.7 5 12 5 C 15.3 5 18 7.7 18 11 V 17 L 19.5 18.5 H 4.5 Z|M 10 21 H 14",
        /*25 GRID*/ "R 4 4 6 6 1.5|R 14 4 6 6 1.5|R 4 14 6 6 1.5|R 14 14 6 6 1.5",
        /*26 DOCK*/ "R 3 4 18 12 2.5|R 6 18 12 3 1.5",
        /*27 SPARK*/ "M 12 3 L 14 10 L 21 12 L 14 14 L 12 21 L 10 14 L 3 12 L 10 10 Z",
        /*28 STATUS*/ "R 3 4 18 16 2.5|M 3 8.5 H 21",
        /*29 ARROW_DOWN*/ "M 12 4 V 19|M 6 13 L 12 19 L 18 13",
        /*30 BOLT*/ "M 13 2 L 5 14 H 11 L 10 22 L 19 9 H 13 Z",
        /*31 CLOCK*/ "O 12 12 9|M 12 7 V 12 L 15.5 14",
        /*32 REFRESH*/ "M 20 12 C 20 16.4 16.4 20 12 20 C 7.6 20 4 16.4 4 12 C 4 7.6 7.6 4 12 4 C 14.5 4 16.7 5.1 18.2 7|M 18.5 3 V 7.5 H 14"
    };

    static Path[][] paths; static boolean[][] fills;
    static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);

    static void build() {
        if (paths != null) return;
        Path[][] pp = new Path[DATA.length][]; boolean[][] ff = new boolean[DATA.length][];
        for (int i = 0; i < DATA.length; i++) {
            String[] segs = DATA[i].split("\\|");
            pp[i] = new Path[segs.length]; ff[i] = new boolean[segs.length];
            for (int j = 0; j < segs.length; j++) {
                String s = segs[j].trim();
                if (s.startsWith("~")) { ff[i][j] = true; s = s.substring(1); }
                pp[i][j] = parse(s);
            }
        }
        fills = ff; paths = pp;
    }

    static float f(String s) { return Float.parseFloat(s); }

    static Path parse(String d) {
        Path p = new Path(); String[] t = d.trim().split("\\s+"); int i = 0; char cmd = 'M'; float cx = 0, cy = 0;
        while (i < t.length) {
            if (Character.isLetter(t[i].charAt(0))) { cmd = t[i].charAt(0); i++; if (cmd == 'Z') { p.close(); continue; } }
            switch (cmd) {
                case 'M': cx = f(t[i]); cy = f(t[i + 1]); p.moveTo(cx, cy); i += 2; cmd = 'L'; break;
                case 'L': cx = f(t[i]); cy = f(t[i + 1]); p.lineTo(cx, cy); i += 2; break;
                case 'H': cx = f(t[i]); p.lineTo(cx, cy); i += 1; break;
                case 'V': cy = f(t[i]); p.lineTo(cx, cy); i += 1; break;
                case 'C': p.cubicTo(f(t[i]), f(t[i + 1]), f(t[i + 2]), f(t[i + 3]), f(t[i + 4]), f(t[i + 5])); cx = f(t[i + 4]); cy = f(t[i + 5]); i += 6; break;
                case 'O': p.addCircle(f(t[i]), f(t[i + 1]), f(t[i + 2]), Path.Direction.CW); i += 3; break;
                case 'R': { float x = f(t[i]), y = f(t[i + 1]), w = f(t[i + 2]), h = f(t[i + 3]), r = f(t[i + 4]); p.addRoundRect(x, y, x + w, y + h, r, r, Path.Direction.CW); i += 5; break; }
                default: i++;
            }
        }
        return p;
    }

    static void draw(Canvas c, int id, float cx, float cy, float size, int col, float sw) {
        build();
        if (id < 0 || id >= DATA.length) return;
        c.save(); c.translate(cx - size / 2, cy - size / 2); c.scale(size / 24f, size / 24f);
        P.setShader(null); P.setColor(col); P.setStrokeCap(Paint.Cap.ROUND); P.setStrokeJoin(Paint.Join.ROUND); P.setStrokeWidth(sw);
        for (int j = 0; j < paths[id].length; j++) { P.setStyle(fills[id][j] ? Paint.Style.FILL : Paint.Style.STROKE); c.drawPath(paths[id][j], P); }
        c.restore();
    }
}

/** A View that draws one SvgIcons glyph, optionally on a coloured rounded tile. */
final class IconV extends View {
    int id, col; float sw = 1.8f; final boolean tile;
    IconV(Context c, int id, int col, int tileColor) {
        super(c); this.id = id; this.col = col; tile = tileColor != 0;
        if (tile) { GradientDrawable g = new GradientDrawable(); g.setColor(tileColor); g.setCornerRadius(Ui.dp(7)); setBackground(g); }
    }
    @Override protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight()) * (tile ? 0.66f : 1f);
        SvgIcons.draw(c, id, getWidth() / 2f, getHeight() / 2f, s, col, sw);
    }
}
